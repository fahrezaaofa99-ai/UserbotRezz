from PyroUbot import *
import random

__MODULE__ = "𝐆𝐮𝐞𝐬𝐬𝐖𝐨𝐫𝐝"
__HELP__ = """
<blockquote><b>📝 𝐆𝐮𝐞𝐬𝐬 𝐖𝐨𝐫𝐝</b>

 • <code>{0}guessword</code> - Mulai tebak kata</blockquote>
"""

WORDS = ['python', 'telegram', 'userbot', 'program', 'komputer', 'internet', 'server', 'database']
WORD_GAMES = {}

@PY.UBOT("guessword")
@PY.TOP_CMD
async def guess_word(client, message):
    chat_id = message.chat.id
    if chat_id in WORD_GAMES:
        return await message.reply("❌ Game sedang berjalan!")
    word = random.choice(WORDS)
    hint = word[0] + '*' * (len(word)-2) + word[-1] if len(word) > 2 else word
    msg = await message.reply(f"📝 **Tebak Kata!**\nPetunjuk: {hint}\nPanjang: {len(word)} huruf\nReply jawaban (30 detik)")
    WORD_GAMES[chat_id] = {"word": word, "msg_id": msg.id}
    await asyncio.sleep(30)
    if chat_id in WORD_GAMES:
        del WORD_GAMES[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {word}")

@PY.INLINE
async def check_word(client, message):
    chat_id = message.chat.id
    if chat_id not in WORD_GAMES:
        return
    if message.text.lower() == WORD_GAMES[chat_id]["word"]:
        await message.reply(f"✅ **BENAR!** Kata: {WORD_GAMES[chat_id]['word']}")
        del WORD_GAMES[chat_id]
    else:
        await message.reply("❌ **SALAH!** Coba lagi")
