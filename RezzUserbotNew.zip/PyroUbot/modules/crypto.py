from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐫𝐲𝐩𝐭𝐨"
__HELP__ = """
<blockquote><b>💰 𝐂𝐫𝐲𝐩𝐭𝐨</b>

 • <code>{0}btc</code> - Harga Bitcoin
 • <code>{0}eth</code> - Harga Ethereum</blockquote>
"""

@PY.UBOT("btc")
@PY.TOP_CMD
async def btc_price(client, message):
    msg = await message.reply("💰 Mengambil harga BTC...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,idr", timeout=10)
        if r.status_code == 200:
            data = r.json()
            usd = data['bitcoin']['usd']
            idr = data['bitcoin']['idr']
            await msg.edit(f"💰 **Bitcoin (BTC)**\n\n💵 USD: ${usd:,}\n🇮🇩 IDR: Rp{idr:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("eth")
@PY.TOP_CMD
async def eth_price(client, message):
    msg = await message.reply("💰 Mengambil harga ETH...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd,idr", timeout=10)
        if r.status_code == 200:
            data = r.json()
            usd = data['ethereum']['usd']
            idr = data['ethereum']['idr']
            await msg.edit(f"💰 **Ethereum (ETH)**\n\n💵 USD: ${usd:,}\n🇮🇩 IDR: Rp{idr:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
