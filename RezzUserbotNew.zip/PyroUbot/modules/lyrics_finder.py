from PyroUbot import *
import requests

__MODULE__ = "𝐋𝐲𝐫𝐢𝐜𝐬"
__HELP__ = """
<blockquote><b>🎵 𝐋𝐲𝐫𝐢𝐜𝐬 𝐅𝐢𝐧𝐝𝐞𝐫</b>

 • <code>{0}lyrics &lt;judul></code> - Cari lirik lagu</blockquote>
"""

@PY.UBOT("lyrics")
@PY.TOP_CMD
async def find_lyrics(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .lyrics <judul>")
    msg = await message.reply("🎵 Mencari lirik...")
    try:
        r = requests.get(f"https://api.lyrics.ovh/v1/{args[1].replace(' ', '%20')}")
        if r.status_code == 200:
            data = r.json()
            lyrics = data.get('lyrics', 'Tidak ditemukan')
            if len(lyrics) > 4000:
                lyrics = lyrics[:4000] + "\n\n... (terpotong)"
            await msg.edit(f"🎵 **LIRIK: {args[1]}**\n\n{lyrics}")
        else:
            await msg.edit("❌ Lirik tidak ditemukan!")
    except:
        await msg.edit("❌ Error")
