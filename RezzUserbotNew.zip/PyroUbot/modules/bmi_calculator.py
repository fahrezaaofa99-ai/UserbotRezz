from PyroUbot import *

__MODULE__ = "𝐁𝐌𝐈"
__HELP__ = """
<blockquote><b>⚕️ 𝐁𝐌𝐈 𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫</b>

 • <code>{0}bmi &lt;tinggi_cm> &lt;berat_kg></code> - Hitung BMI</blockquote>
"""

@PY.UBOT("bmi")
@PY.TOP_CMD
async def bmi_calc(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .bmi <tinggi_cm> <berat_kg>")
    tinggi = float(args[1]) / 100
    berat = float(args[2])
    bmi = berat / (tinggi * tinggi)
    
    if bmi < 18.5:
        status = "Kurus"
    elif bmi < 25:
        status = "Normal"
    elif bmi < 30:
        status = "Gemuk"
    else:
        status = "Obesitas"
    
    await message.reply(f"⚕️ **BMI CALCULATOR**\n\n📏 Tinggi: {args[1]} cm\n⚖️ Berat: {args[2]} kg\n📊 BMI: {bmi:.1f}\n✅ Status: {status}")
