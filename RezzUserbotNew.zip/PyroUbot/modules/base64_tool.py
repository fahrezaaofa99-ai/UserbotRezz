from PyroUbot import *
import base64

__MODULE__ = "𝐁𝐚𝐬𝐞𝟔𝟒𝐓𝐨𝐨𝐥"
__HELP__ = """
<blockquote><b>🔢 𝐁𝐚𝐬𝐞𝟔𝟒</b>

 • <code>{0}b64enc &lt;teks></code> - Encode Base64
 • <code>{0}b64dec &lt;teks></code> - Decode Base64</blockquote>
"""

@PY.UBOT("b64enc")
@PY.TOP_CMD
async def base64_encode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .b64enc <teks>")
    encoded = base64.b64encode(args[1].encode()).decode()
    await message.reply(f"🔐 **Base64:** `{encoded}`")

@PY.UBOT("b64dec")
@PY.TOP_CMD
async def base64_decode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .b64dec <teks>")
    try:
        decoded = base64.b64decode(args[1]).decode()
        await message.reply(f"📝 **Decoded:** `{decoded}`")
    except:
        await message.reply("❌ Gagal decode")
