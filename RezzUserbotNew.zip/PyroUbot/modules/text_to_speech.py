from PyroUbot import *
import requests

__MODULE__ = "𝐓𝐞𝐱𝐭 𝐓𝐨 𝐒𝐩𝐞𝐞𝐜𝐡"
__HELP__ = """
<blockquote><b>🔊 𝐓𝐞𝐱𝐭 𝐓𝐨 𝐒𝐩𝐞𝐞𝐜𝐡</b>

 • <code>{0}tts &lt;teks></code> - Ubah teks ke suara</blockquote>
"""

@PY.UBOT("tts")
@PY.TOP_CMD
async def text_to_speech(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tts <teks>")
    msg = await message.reply("🔊 Mengubah teks ke suara...")
    try:
        r = requests.post("https://api.voicerss.org/", data={
            "key": "YOUR_API_KEY",
            "hl": "id-id",
            "src": args[1],
            "f": "44khz_16bit_stereo"
        })
        if r.status_code == 200:
            with open(f"tts_{message.id}.mp3", "wb") as f:
                f.write(r.content)
            await client.send_audio(message.chat.id, f"tts_{message.id}.mp3")
            os.remove(f"tts_{message.id}.mp3")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
