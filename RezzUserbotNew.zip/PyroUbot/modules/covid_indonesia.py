from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐨𝐯𝐢𝐝𝐈𝐧𝐝𝐨"
__HELP__ = """
<blockquote><b>🇮🇩 𝐂𝐨𝐯𝐢𝐝 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚</b>

 • <code>{0}covidid</code> - Data Covid Indonesia</blockquote>
"""

@PY.UBOT("covidid")
@PY.TOP_CMD
async def covid_indonesia(client, message):
    msg = await message.reply("🦠 Mengambil data...")
    try:
        r = requests.get("https://disease.sh/v3/covid-19/countries/indonesia")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"🇮🇩 **COVID-19 INDONESIA**\n\n🟢 Kasus: {data['cases']:,}\n🔴 Meninggal: {data['deaths']:,}\n✅ Sembuh: {data['recovered']:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
