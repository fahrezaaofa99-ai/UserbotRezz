from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲"
__HELP__ = """
<blockquote><b>💱 𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲</b>

 • <code>{0}usd &lt;jumlah></code> - USD ke IDR
 • <code>{0}idr &lt;jumlah></code> - IDR ke USD</blockquote>
"""

@PY.UBOT("usd")
@PY.TOP_CMD
async def usd_to_idr(client, message):
    args = message.text.split()
    jumlah = float(args[1]) if len(args) > 1 else 1
    try:
        r = requests.get("https://api.exchangerate-api.com/v4/latest/USD")
        if r.status_code == 200:
            rate = r.json()['rates']['IDR']
            hasil = jumlah * rate
            await message.reply(f"💵 ${jumlah} USD = Rp{hasil:,.0f}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("idr")
@PY.TOP_CMD
async def idr_to_usd(client, message):
    args = message.text.split()
    jumlah = float(args[1]) if len(args) > 1 else 1
    try:
        r = requests.get("https://api.exchangerate-api.com/v4/latest/IDR")
        if r.status_code == 200:
            rate = r.json()['rates']['USD']
            hasil = jumlah * rate
            await message.reply(f"🇮🇩 Rp{jumlah:,.0f} = ${hasil:,.2f} USD")
    except:
        await message.reply("❌ Error")
