from PyroUbot import *
from googletrans import Translator

__MODULE__ = "𝐓𝐫𝐚𝐧𝐬𝐥𝐚𝐭𝐞"
__HELP__ = """
<blockquote><b>🌐 𝐓𝐫𝐚𝐧𝐬𝐥𝐚𝐭𝐞</b>

 • <code>{0}tr &lt;teks></code> - Translate ke Indonesia
 • <code>{0}tr_en &lt;teks></code> - Translate ke Inggris</blockquote>
"""

@PY.UBOT("tr")
@PY.TOP_CMD
async def translate_id(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tr <teks>")
    msg = await message.reply("🌐 Menerjemahkan...")
    try:
        trans = Translator()
        result = trans.translate(args[1], dest='id')
        await msg.edit(f"🌐 **Terjemahan:**\n\n{result.text}")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("tr_en")
@PY.TOP_CMD
async def translate_en(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tr_en <teks>")
    msg = await message.reply("🌐 Translating...")
    try:
        trans = Translator()
        result = trans.translate(args[1], dest='en')
        await msg.edit(f"🌐 **Translation:**\n\n{result.text}")
    except:
        await msg.edit("❌ Error")
