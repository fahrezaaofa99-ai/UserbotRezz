from PyroUbot import *
import random

__MODULE__ = "𝐑𝐢𝐝𝐝𝐥𝐞"
__HELP__ = """
<blockquote><b>🤔 𝐑𝐢𝐝𝐝𝐥𝐞 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}riddle</code> - Tebak-tebakan random</blockquote>
"""

RIDDLES = [
    ("Apa yang bisa naik tapi tidak bisa turun?", "Umur"),
    ("Apa yang semakin diisi semakin ringan?", "Balon"),
    ("Apa yang punya banyak kunci tapi tidak bisa membuka pintu?", "Piano"),
    ("Apa yang selalu di depanmu tapi tidak pernah bisa kau lihat?", "Masa depan"),
]

@PY.UBOT("riddle")
@PY.TOP_CMD
async def random_riddle(client, message):
    riddle, answer = random.choice(RIDDLES)
    await message.reply(f"🤔 **Tebak-tebakan:**\n\n{riddle}\n\nBalas dengan jawabanmu!")
    
    def check(m):
        return m.from_user.id == message.from_user.id
    
    try:
        reply = await client.wait_for_message(check, timeout=30)
        if reply.text.lower() == answer.lower():
            await message.reply(f"✅ **BENAR!** Jawabannya: {answer}")
        else:
            await message.reply(f"❌ **SALAH!** Jawabannya: {answer}")
    except:
        await message.reply(f"⏰ Waktu habis! Jawaban: {answer}")
