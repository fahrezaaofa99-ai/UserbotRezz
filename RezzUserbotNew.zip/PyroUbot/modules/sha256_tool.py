from PyroUbot import *
import hashlib

__MODULE__ = "𝐒𝐇𝐀𝟐𝟓𝟔"
__HELP__ = """
<blockquote><b>🔐 𝐒𝐇𝐀𝟐𝟓𝟔</b>

 • <code>{0}sha256 &lt;teks></code> - Hash SHA256</blockquote>
"""

@PY.UBOT("sha256")
@PY.TOP_CMD
async def sha256_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .sha256 <teks>")
    hasil = hashlib.sha256(args[1].encode()).hexdigest()
    await message.reply(f"🔐 **SHA256:** `{hasil}`")
