from PyroUbot import *
import os
from PIL import Image

__MODULE__ = "STICKER"
__HELP__ = """
<b>🎨 STICKER TOOLS</b>

• <code>{0}stiker</code> [reply ke gambar] - Bikin stiker dari gambar
• <code>{0}stickergif</code> [reply ke video/gif] - Bikin stiker gif
• <code>{0}kang</code> [reply ke stiker] - Clone stiker orang
• <code>{0}toimage</code> [reply ke stiker] - Stiker jadi gambar
"""

@PY.UBOT("stiker")
@PY.TOP_CMD
async def make_sticker(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("❌ Reply ke gambar!")
    
    msg = await message.reply("🔄 Membuat stiker...")
    
    try:
        file = await message.reply_to_message.download()
        await message.reply_sticker(file)
        os.remove(file)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("kang")
@PY.TOP_CMD
async def kang_sticker(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Reply ke stiker!")
    
    msg = await message.reply("🔄 Mengambil stiker...")
    
    try:
        file = await message.reply_to_message.download()
        await message.reply_sticker(file)
        os.remove(file)
        await msg.edit("✅ Stiker berhasil di-clone!")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("toimage")
@PY.TOP_CMD
async def sticker_to_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Reply ke stiker!")
    
    msg = await message.reply("🔄 Mengkonversi...")
    
    try:
        file = await message.reply_to_message.download()
        
        if file.endswith('.webp'):
            img = Image.open(file)
            png_file = file.replace('.webp', '.png')
            img.save(png_file, 'PNG')
            await message.reply_photo(png_file)
            os.remove(png_file)
        else:
            await message.reply_photo(file)
        
        os.remove(file)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")
