from PyroUbot import *
import requests
import random

__MODULE__ = "𝐉𝐨𝐤𝐞 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫"
__HELP__ = """
<blockquote><b>😂 𝐉𝐨𝐤𝐞 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}joke</code> - Joke random
 • <code>{0}dadjoke</code> - Joke bapak-bapak
 • <code>{0}darkjoke</code> - Dark joke
 • <code>{0}pun</code> - Pun joke
 • <code>{0}jokeindo</code> - Joke Indonesia</blockquote>
"""

jokes_indonesia = [
    "Kenapa ayam kalo berkokok sambil merem? Udah hafal teksnya!",
    "Kenapa air laut asin? Karena ikannya pada kencing",
    "Kenapa motor gak bisa mundur? Nanti ketabrak masa lalu",
    "Tahu kenapa lampu merah itu merah? Biar keliatan kalo mati",
    "Kenapa sapi produktif banget? Karena sapi perah",
]

@PY.UBOT("joke")
@PY.TOP_CMD
async def random_joke(client, message):
    try:
        r = requests.get("https://official-joke-api.appspot.com/random_joke")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"😂 **{data['setup']}**\n\n👉 {data['punchline']}")
        else:
            await message.reply(random.choice(jokes_indonesia))
    except:
        await message.reply(random.choice(jokes_indonesia))

@PY.UBOT("dadjoke")
@PY.TOP_CMD
async def dad_joke(client, message):
    try:
        r = requests.get("https://icanhazdadjoke.com/", headers={"Accept": "text/plain"})
        if r.status_code == 200:
            await message.reply(f"👨 **DAD JOKE:**\n\n{r.text}")
        else:
            await message.reply(random.choice(jokes_indonesia))
    except:
        await message.reply(random.choice(jokes_indonesia))

@PY.UBOT("darkjoke")
@PY.TOP_CMD
async def dark_joke(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Dark")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"🖤 **DARK JOKE:**\n\n{data['joke']}")
            else:
                await message.reply(f"🖤 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply(random.choice(jokes_indonesia))
    except:
        await message.reply(random.choice(jokes_indonesia))

@PY.UBOT("pun")
@PY.TOP_CMD
async def pun_joke(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Pun")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"😄 **PUN JOKE:**\n\n{data['joke']}")
            else:
                await message.reply(f"😄 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply(random.choice(jokes_indonesia))
    except:
        await message.reply(random.choice(jokes_indonesia))

@PY.UBOT("jokeindo")
@PY.TOP_CMD
async def indo_joke(client, message):
    joke = random.choice(jokes_indonesia)
    await message.reply(f"🇮🇩 **JOKE INDONESIA**\n\n{joke}")
