from PyroUbot import *
import time

__MODULE__ = "𝐁𝐨𝐭𝐒𝐭𝐚𝐭𝐬"
__HELP__ = """
<blockquote><b>📊 𝐁𝐨𝐭 𝐒𝐭𝐚𝐭𝐢𝐬𝐭𝐢𝐜𝐬</b>

 • <code>{0}stats</code> - Statistik bot</blockquote>
"""

START_TIME = time.time()

@PY.UBOT("stats")
@PY.TOP_CMD
async def bot_stats(client, message):
    uptime = int(time.time() - START_TIME)
    days = uptime // 86400
    hours = (uptime % 86400) // 3600
    minutes = (uptime % 3600) // 60
    seconds = uptime % 60
    
    modules = len([f for f in os.listdir('.') if f.endswith('.py')])
    
    text = f"""
╭──〔 📊 BOT STATISTICS 〕
│
│ ⏱️ **Uptime:** {days}d {hours}h {minutes}m {seconds}s
│ 📦 **Modules:** {modules}
│ 👤 **User ID:** {message.from_user.id}
│
╰── ✨ Bot Stats ✨"""
    await message.reply(text)
