from PyroUbot import *
import asyncio

__MODULE__ = "𝐒𝐢𝐦𝐩𝐥𝐞𝐓𝐢𝐦𝐞𝐫"
__HELP__ = """
<blockquote><b>⏱️ 𝐒𝐢𝐦𝐩𝐥𝐞 𝐓𝐢𝐦𝐞𝐫</b>

 • <code>{0}timer &lt;detik></code> - Timer sederhana</blockquote>
"""

@PY.UBOT("timer")
@PY.TOP_CMD
async def simple_timer(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .timer <detik>")
    detik = int(args[1])
    await message.reply(f"⏱️ Timer dimulai: {detik} detik")
    await asyncio.sleep(detik)
    await message.reply("🔔 **TIME'S UP!**")
