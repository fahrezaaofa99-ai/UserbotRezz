from PyroUbot import *
import asyncio

__MODULE__ = "𝐒𝐭𝐨𝐩𝐰𝐚𝐭𝐜𝐡"
__HELP__ = """
<blockquote><b>⏱️ 𝐒𝐭𝐨𝐩𝐰𝐚𝐭𝐜𝐡</b>

 • <code>{0}stopwatch</code> - Mulai stopwatch</blockquote>
"""

@PY.UBOT("stopwatch")
@PY.TOP_CMD
async def stopwatch_start(client, message):
    msg = await message.reply("⏱️ Stopwatch dimulai! Ketik .stop untuk berhenti")
    start_time = asyncio.get_event_loop().time()
    
    def check_stop(m):
        return m.from_user.id == message.from_user.id and m.text == ".stop"
    
    try:
        await client.wait_for_message(check_stop, timeout=3600)
        elapsed = int(asyncio.get_event_loop().time() - start_time)
        menit = elapsed // 60
        detik = elapsed % 60
        await message.reply(f"⏱️ **Stopwatch berhenti!**\n⏰ Waktu: {menit} menit {detik} detik")
        await msg.delete()
    except:
        await msg.edit("⏱️ Stopwatch timeout (1 jam)")
