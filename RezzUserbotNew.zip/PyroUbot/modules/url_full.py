from PyroUbot import *
from urllib.parse import quote, unquote

__MODULE__ = "𝐔𝐑𝐋𝐓𝐨𝐨𝐥"
__HELP__ = """
<blockquote><b>🔗 𝐔𝐑𝐋 𝐄𝐧𝐜𝐨𝐝𝐞/𝐃𝐞𝐜𝐨𝐝𝐞</b>

 • <code>{0}urlenc &lt;teks></code> - URL Encode
 • <code>{0}urldec &lt;teks></code> - URL Decode</blockquote>
"""

@PY.UBOT("urlenc")
@PY.TOP_CMD
async def url_encode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .urlenc <teks>")
    encoded = quote(args[1])
    await message.reply(f"🔗 **URL Encode:** `{encoded}`")

@PY.UBOT("urldec")
@PY.TOP_CMD
async def url_decode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .urldec <teks>")
    decoded = unquote(args[1])
    await message.reply(f"🔗 **URL Decode:** `{decoded}`")
