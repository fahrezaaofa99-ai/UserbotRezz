from PyroUbot import *
import requests
import json
import random
import string
import asyncio
from datetime import datetime

__MODULE__ = "PTERODACTYL"
__HELP__ = """
<blockquote><b>🦎 PTERODACTYL CONTROLLER</b>

<b>🔧 SETUP PANEL</b>
 • <code>{0}setptero</code> [url] [app_key] [client_key]
   Setting panel pterodactyl
   Contoh: <code>{0}setptero https://panel.com ptla_xxxxx ptlc_xxxxx</code>

<b>👤 USER MANAGEMENT</b>
 • <code>{0}createuser</code> [username] - Buat user biasa
 • <code>{0}createadmin</code> [username] - Buat admin
 • <code>{0}delusr</code> [user_id] - Hapus user by ID
 • <code>{0}cariuser</code> [username] - Cari user ID
 • <code>{0}listuser</code> - Lihat semua user

<b>🖥️ SERVER MANAGEMENT</b>
 • <code>{0}createserver</code> [username] - Buat server UNLIMITED
 • <code>{0}delsrv</code> [server_id] - Hapus server by ID
 • <code>{0}listserver</code> [username] - Lihat server user
 • <code>{0}serverinfo</code> [server_id] - Detail server
 • <code>{0}suspend</code> [server_id] - Suspend server
 • <code>{0}unsuspend</code> [server_id] - Unsuspend server
 • <code>{0}reinstall</code> [server_id] - Reinstall server

<b>⚡ POWER ACTIONS</b>
 • <code>{0}start</code> [server_id] - Start server
 • <code>{0}stop</code> [server_id] - Stop server
 • <code>{0}restart</code> [server_id] - Restart server
 • <code>{0}kill</code> [server_id] - Kill server
 • <code>{0}stopall</code> - Stop SEMUA server di panel
 • <code>{0}stopall</code> [username] - Stop semua server user
 • <code>{0}startall</code> - Start SEMUA server di panel
 • <code>{0}startall</code> [username] - Start semua server user

<b>📋 INFO</b>
 • <code>{0}listegg</code> - Lihat daftar egg
 • <code>{0}listnode</code> - Lihat daftar node
 • <code>{0}listloc</code> - Lihat daftar lokasi
 • <code>{0}status</code> - Cek status panel</blockquote>
"""

# Database
ptero_config = {}
user_cache = {}

# Default settings (EGG ID 15, LOCATION 1)
EGG_ID = "15"
LOCATION_ID = "1"
DOMAIN_EMAIL = "@userbot.rezz"

def generate_password(length=12):
    chars = string.ascii_letters + string.digits + "!@#$%"
    return ''.join(random.choice(chars) for _ in range(length))

def get_ptero_config(user_id):
    return ptero_config.get(str(user_id))

def ptero_request(method, url, api_key, endpoint, data=None, is_client=False):
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Accept': 'Application/vnd.pterodactyl.v1+json',
        'Content-Type': 'application/json'
    }
    
    if is_client:
        full_url = f"{url.rstrip('/')}/api/client/{endpoint.lstrip('/')}"
    else:
        full_url = f"{url.rstrip('/')}/api/application/{endpoint.lstrip('/')}"
    
    try:
        if method.upper() == 'GET':
            response = requests.get(full_url, headers=headers, timeout=15)
        elif method.upper() == 'POST':
            response = requests.post(full_url, headers=headers, json=data, timeout=15)
        elif method.upper() == 'DELETE':
            response = requests.delete(full_url, headers=headers, timeout=15)
        elif method.upper() == 'PATCH':
            response = requests.patch(full_url, headers=headers, json=data, timeout=15)
        else:
            return None, "Method not supported"
        
        if response.status_code in [200, 201, 204]:
            if response.status_code == 204:
                return {"success": True}, None
            return response.json(), None
        else:
            error_msg = f"Error {response.status_code}: {response.text}"
            return None, error_msg
            
    except Exception as e:
        return None, str(e)

def get_user_id_by_username(config, username):
    url, api_key = config['url'], config['app_api_key']
    
    cache_key = f"{url}_{username}"
    if cache_key in user_cache:
        return user_cache[cache_key], None
    
    result, error = ptero_request('GET', url, api_key, f'users?filter[username]={username}', is_client=False)
    
    if error:
        return None, error
    
    if result and result.get('data'):
        for user in result['data']:
            if user['attributes']['username'].lower() == username.lower():
                user_id = user['attributes']['id']
                user_cache[cache_key] = user_id
                return user_id, None
    
    return None, f"❌ User '{username}' tidak ditemukan"

def get_all_servers(config):
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'servers?per_page=100', is_client=False)
    if error:
        return [], error
    return result.get('data', []), None

def get_servers_by_user(config, user_id):
    servers, error = get_all_servers(config)
    if error:
        return [], error
    
    user_servers = []
    for server in servers:
        if server['attributes']['user'] == user_id:
            user_servers.append({
                'id': server['attributes']['id'],
                'identifier': server['attributes']['identifier'],
                'name': server['attributes']['name']
            })
    
    return user_servers, None

async def server_power_action(config, server_id, action):
    if not config.get('client_working') or not config.get('client_api_key'):
        return None, "❌ Client API Key tidak tersedia!"
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if error:
        return None, f"❌ Server tidak ditemukan: {error}"
    
    identifier = result['attributes']['identifier']
    signal_data = {'signal': action}
    
    result, error = ptero_request('POST', config['url'], config['client_api_key'], f'servers/{identifier}/power', signal_data, is_client=True)
    return result, error

# ==================== SETUP PANEL ====================

@PY.UBOT("setptero")
@PY.TOP_CMD
async def set_ptero(client, message):
    if len(message.command) < 3:
        return await message.reply(
            f"<b>📌 FORMAT SETPTERO</b>\n\n"
            f"<code>{message.text} url app_key client_key</code>\n\n"
            f"Contoh: <code>{message.text} https://panel.com ptla_xxxxx ptlc_xxxxx</code>"
        )
    
    panel_url = message.command[1]
    app_api_key = message.command[2]
    client_api_key = message.command[3] if len(message.command) >= 4 else None
    
    if not panel_url.startswith(('http://', 'https://')):
        panel_url = 'https://' + panel_url
    
    user_id = str(message.from_user.id)
    msg = await message.reply("<b>🔄 Testing koneksi ke panel...</b>")
    
    result, error = ptero_request('GET', panel_url, app_api_key, 'users', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal konek (App API):</b>\n<code>{error}</code>")
    
    client_working = False
    client_username = None
    if client_api_key:
        try:
            headers = {'Authorization': f'Bearer {client_api_key}', 'Accept': 'Application/vnd.pterodactyl.v1+json'}
            test_url = f"{panel_url.rstrip('/')}/api/client/account"
            response = requests.get(test_url, headers=headers, timeout=10)
            if response.status_code == 200:
                client_working = True
                data = response.json()
                client_username = data.get('attributes', {}).get('username', 'Unknown')
        except:
            pass
    
    ptero_config[user_id] = {
        'url': panel_url,
        'app_api_key': app_api_key,
        'client_api_key': client_api_key,
        'client_working': client_working,
        'client_username': client_username
    }
    
    status_client = "✅ Aktif" if client_working else "❌ Tidak diset"
    client_info = f" (sebagai @{client_username})" if client_working else ""
    
    await msg.edit(
        f"<b>✅ PANEL BERHASIL DIKONFIGURASI!</b>\n\n"
        f"📍 <b>URL:</b> <code>{panel_url}</code>\n"
        f"🔑 <b>App API:</b> <code>{app_api_key[:10]}...{app_api_key[-5:]}</code>\n"
        f"🔑 <b>Client API:</b> {status_client}{client_info}\n"
        f"⚙️ <b>Egg Default:</b> {EGG_ID} | <b>Location:</b> {LOCATION_ID}"
    )

# ==================== CREATE USER ====================

@PY.UBOT("createuser")
@PY.TOP_CMD
async def create_user(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} username</code>")
    
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi! Gunakan /setptero dulu.")
    
    username = message.command[1].lower()
    email = f"{username}{DOMAIN_EMAIL}"
    password = generate_password()
    
    msg = await message.reply(f"<b>🔄 Membuat user @{username}...</b>")
    
    user_data = {
        'username': username,
        'email': email,
        'first_name': username.capitalize(),
        'last_name': 'User',
        'password': password,
        'root_admin': False
    }
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], 'users', user_data, is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal create user:</b>\n<code>{error}</code>")
    
    user_attr = result['attributes']
    user_id_ptero = user_attr['id']
    
    cache_key = f"{config['url']}_{username}"
    user_cache[cache_key] = user_id_ptero
    
    private_msg = (
        f"<b>✅ USER PANEL CREATED!</b>\n\n"
        f"👤 <b>Username:</b> @{username}\n"
        f"📧 <b>Email:</b> <code>{email}</code>\n"
        f"🔑 <b>Password:</b> <code>{password}</code>\n"
        f"🆔 <b>ID:</b> <code>{user_id_ptero}</code>\n\n"
        f"📍 <b>Panel URL:</b> {config['url']}\n"
        f"<i>⚠️ Simpan data ini baik-baik!</i>"
    )
    
    try:
        await client.send_message(chat_id=message.from_user.id, text=private_msg)
        await msg.edit(f"<b>✅ User @{username} berhasil dibuat!</b>\n📨 Detail sudah dikirim ke private chat.\n🆔 User ID: <code>{user_id_ptero}</code>")
    except:
        await msg.edit(f"<b>✅ User @{username} berhasil dibuat!</b>\n\n🆔 User ID: <code>{user_id_ptero}</code>")

@PY.UBOT("createadmin")
@PY.TOP_CMD
async def create_admin(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} username</code>")
    
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    username = message.command[1].lower()
    email = f"{username}{DOMAIN_EMAIL}"
    password = generate_password()
    
    msg = await message.reply(f"<b>🔄 Membuat admin @{username}...</b>")
    
    admin_data = {
        'username': username,
        'email': email,
        'first_name': username.capitalize(),
        'last_name': 'Admin',
        'password': password,
        'root_admin': True
    }
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], 'users', admin_data, is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal create admin:</b>\n<code>{error}</code>")
    
    user_attr = result['attributes']
    user_id_ptero = user_attr['id']
    
    cache_key = f"{config['url']}_{username}"
    user_cache[cache_key] = user_id_ptero
    
    private_msg = (
        f"<b>👑 ADMIN PANEL CREATED!</b>\n\n"
        f"👤 <b>Username:</b> @{username}\n"
        f"📧 <b>Email:</b> <code>{email}</code>\n"
        f"🔑 <b>Password:</b> <code>{password}</code>\n"
        f"🆔 <b>ID:</b> <code>{user_id_ptero}</code>\n"
        f"⚡ <b>Role:</b> <code>ADMIN</code>\n\n"
        f"📍 <b>Panel URL:</b> {config['url']}\n"
        f"<i>⚠️ Simpan data ini baik-baik!</i>"
    )
    
    try:
        await client.send_message(chat_id=message.from_user.id, text=private_msg)
        await msg.edit(f"<b>✅ Admin @{username} berhasil dibuat!</b>\n📨 Detail sudah dikirim ke private chat.\n🆔 User ID: <code>{user_id_ptero}</code>")
    except:
        await msg.edit(f"<b>✅ Admin @{username} berhasil dibuat!</b>\n\n🆔 User ID: <code>{user_id_ptero}</code>")

# ==================== DELETE USER ====================

@PY.UBOT("delusr")
@PY.TOP_CMD
async def delete_user_by_id(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} user_id</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    user_id = message.command[1]
    msg = await message.reply(f"<b>🔄 Menghapus user ID {user_id}...</b>")
    
    check_result, check_error = ptero_request('GET', config['url'], config['app_api_key'], f'users/{user_id}', is_client=False)
    if check_error:
        return await msg.edit(f"❌ User ID {user_id} tidak ditemukan!")
    
    username = check_result['attributes']['username']
    
    result, error = ptero_request('DELETE', config['url'], config['app_api_key'], f'users/{user_id}', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal hapus user:</b>\n<code>{error}</code>")
    
    keys_to_remove = []
    for key, value in user_cache.items():
        if value == int(user_id):
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del user_cache[key]
    
    await msg.edit(f"<b>✅ USER BERHASIL DIHAPUS!</b>\n\n🆔 ID: {user_id}\n👤 Username: @{username}")

# ==================== LIST USER & SEARCH ====================

@PY.UBOT("listuser")
@PY.TOP_CMD
async def list_users(client, message):
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    msg = await message.reply("<b>🔄 Mengambil data users...</b>")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'users?per_page=50', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal:</b> {error}")
    
    users = result.get('data', [])
    if not users:
        return await msg.edit("<b>📭 Tidak ada user di panel</b>")
    
    text = "<b>📋 DAFTAR USER:</b>\n\n"
    for i, user in enumerate(users[:20], 1):
        attr = user['attributes']
        text += f"{i}. <b>ID {attr['id']}</b> | @{attr['username']}\n   📧 {attr['email']}\n   {'👑 ADMIN' if attr['root_admin'] else '👤 User'}\n\n"
    
    if len(users) > 20:
        text += f"<i>...dan {len(users)-20} user lainnya</i>"
    
    await msg.edit(text)

@PY.UBOT("cariuser")
@PY.TOP_CMD
async def cari_user(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>cariuser [username]</code>")
    
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    username = message.command[1].lower()
    msg = await message.reply(f"🔍 Mencari user @{username}...")
    
    user_id_ptero, error = get_user_id_by_username(config, username)
    if error:
        return await msg.edit(f"❌ {error}")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], f'users/{user_id_ptero}', is_client=False)
    if error:
        return await msg.edit(f"❌ Gagal ambil detail: {error}")
    
    user = result['attributes']
    await msg.edit(
        f"<b>✅ USER DITEMUKAN!</b>\n\n"
        f"🆔 ID: <code>{user['id']}</code>\n"
        f"👤 Username: @{user['username']}\n"
        f"📧 Email: {user['email']}\n"
        f"👑 Admin: {'Ya' if user['root_admin'] else 'Tidak'}"
    )

# ==================== CREATE SERVER ====================

@PY.UBOT("createserver")
@PY.TOP_CMD
async def create_server_unlimited(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} username</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    username = message.command[1].lower()
    server_name = f"{username}-server"
    
    msg = await message.reply(f"<b>🔄 Membuat server UNLIMITED untuk @{username}...</b>")
    
    user_id_ptero, error = get_user_id_by_username(config, username)
    if error:
        return await msg.edit(f"❌ {error}\n\nGunakan /createuser {username} dulu.")
    
    nodes_result, nodes_error = ptero_request('GET', config['url'], config['app_api_key'], 'nodes', is_client=False)
    if nodes_error or not nodes_result.get('data'):
        return await msg.edit("❌ Gagal mendapatkan node.")
    
    node_id = nodes_result['data'][0]['attributes']['id']
    
    alloc_result, alloc_error = ptero_request('GET', config['url'], config['app_api_key'], f'nodes/{node_id}/allocations', is_client=False)
    if alloc_error or not alloc_result.get('data'):
        return await msg.edit("❌ Gagal mendapatkan allocation.")
    
    allocation_id = None
    for alloc in alloc_result['data']:
        if not alloc['attributes']['assigned']:
            allocation_id = alloc['attributes']['id']
            break
    
    if not allocation_id:
        return await msg.edit("❌ Tidak ada allocation tersedia.")
    
    startup_cmd = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}'
    
    environment = {
        "INST": "npm",
        "USER_UPLOAD": "0",
        "AUTO_UPDATE": "0",
        "CMD_RUN": "npm start"
    }
    
    server_data = {
        'name': server_name,
        'user': int(user_id_ptero),
        'egg': int(EGG_ID),
        'docker_image': 'ghcr.io/parkervcp/yolks:nodejs_20',
        'startup': startup_cmd,
        'environment': environment,
        'limits': {
            'memory': 0, 'swap': 0, 'disk': 0, 'io': 500, 'cpu': 0
        },
        'feature_limits': {
            'databases': 5, 'backups': 5
        },
        'deploy': {
            'locations': [int(LOCATION_ID)],
            'dedicated_ip': False,
            'port_range': []
        },
        'allocation': {
            'default': allocation_id
        }
    }
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], 'servers', server_data, is_client=False)
    
    if error:
        return await msg.edit(f"<b>❌ Gagal create server:</b>\n<code>{error}</code>")
    
    server_attr = result['attributes']
    
    await msg.edit(
        f"<b>✅ SERVER UNLIMITED BERHASIL DIBUAT!</b>\n\n"
        f"👤 <b>User:</b> @{username} (ID: {user_id_ptero})\n"
        f"🆔 <b>Server ID:</b> <code>{server_attr['id']}</code>\n"
        f"📛 <b>Nama:</b> {server_name}\n"
        f"🔑 <b>Identifier:</b> <code>{server_attr['identifier']}</code>\n"
        f"🥚 <b>Egg:</b> {EGG_ID}\n"
        f"📍 <b>Location:</b> {LOCATION_ID}\n"
        f"💾 <b>RAM:</b> UNLIMITED\n"
        f"💽 <b>Disk:</b> UNLIMITED\n"
        f"⚙️ <b>CPU:</b> UNLIMITED"
    )

# ==================== DELETE SERVER ====================

@PY.UBOT("delsrv")
@PY.TOP_CMD
async def delete_server_by_id(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} server_id</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"<b>🔄 Menghapus server ID {server_id}...</b>")
    
    check_result, check_error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if check_error:
        return await msg.edit(f"❌ Server ID {server_id} tidak ditemukan!")
    
    server_name = check_result['attributes']['name']
    
    result, error = ptero_request('DELETE', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal hapus server:</b>\n<code>{error}</code>")
    
    await msg.edit(f"<b>✅ SERVER BERHASIL DIHAPUS!</b>\n\n🆔 ID: {server_id}\n📛 Nama: {server_name}")

# ==================== SUSPEND SERVER ====================

@PY.UBOT("suspend")
@PY.TOP_CMD
async def suspend_server(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} server_id</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"<b>🔄 Mensuspend server ID {server_id}...</b>")
    
    check_result, check_error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if check_error:
        return await msg.edit(f"❌ Server ID {server_id} tidak ditemukan!")
    
    server_name = check_result['attributes']['name']
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], f'servers/{server_id}/suspend', is_client=False)
    
    if error:
        return await msg.edit(f"<b>❌ Gagal suspend server:</b>\n<code>{error}</code>")
    
    await msg.edit(f"<b>✅ SERVER BERHASIL DISUSPEND!</b>\n\n🆔 ID: {server_id}\n📛 Nama: {server_name}\n⚠️ Server tidak dapat diakses sampai diunsuspend")

# ==================== UNSUSPEND SERVER ====================

@PY.UBOT("unsuspend")
@PY.TOP_CMD
async def unsuspend_server(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} server_id</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"<b>🔄 Mengunsuspend server ID {server_id}...</b>")
    
    check_result, check_error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if check_error:
        return await msg.edit(f"❌ Server ID {server_id} tidak ditemukan!")
    
    server_name = check_result['attributes']['name']
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], f'servers/{server_id}/unsuspend', is_client=False)
    
    if error:
        return await msg.edit(f"<b>❌ Gagal unsuspend server:</b>\n<code>{error}</code>")
    
    await msg.edit(f"<b>✅ SERVER BERHASIL DIUNSUSPEND!</b>\n\n🆔 ID: {server_id}\n📛 Nama: {server_name}\n✅ Server sudah bisa diakses kembali")

# ==================== REINSTALL SERVER ====================

@PY.UBOT("reinstall")
@PY.TOP_CMD
async def reinstall_server(client, message):
    if len(message.command) < 2:
        return await message.reply(f"<b>📌 FORMAT</b>\n\n<code>{message.text} server_id</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    
    confirm_msg = await message.reply(
        f"<b>⚠️ PERINGATAN!</b>\n\n"
        f"Server ID {server_id} akan DIREINSTALL.\n"
        f"SEMUA DATA akan HILANG dan tidak bisa dikembalikan!\n\n"
        f"Yakin? Balas dengan <code>y</code> dalam 30 detik"
    )
    
    try:
        response = await client.wait_for(
            'message',
            timeout=30,
            check=lambda m: m.from_user.id == message.from_user.id and 
                           m.chat.id == message.chat.id and
                           m.text.lower() == 'y'
        )
    except asyncio.TimeoutError:
        return await confirm_msg.edit("❌ Konfirmasi timeout, reinstall dibatalkan.")
    
    msg = await confirm_msg.edit(f"<b>🔄 Mereinstall server ID {server_id}...</b>")
    
    check_result, check_error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if check_error:
        return await msg.edit(f"❌ Server ID {server_id} tidak ditemukan!")
    
    server_name = check_result['attributes']['name']
    
    result, error = ptero_request('POST', config['url'], config['app_api_key'], f'servers/{server_id}/reinstall', is_client=False)
    
    if error:
        return await msg.edit(f"<b>❌ Gagal reinstall server:</b>\n<code>{error}</code>")
    
    await msg.edit(f"<b>✅ SERVER SEDANG DIREINSTALL!</b>\n\n🆔 ID: {server_id}\n📛 Nama: {server_name}\n⏳ Proses reinstall sedang berjalan...")

# ==================== LIST SERVER ====================

@PY.UBOT("listserver")
@PY.TOP_CMD
async def list_user_servers(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>listserver [username]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    username = message.command[1].lower()
    msg = await message.reply(f"🔍 Mencari server @{username}...")
    
    user_id, error = get_user_id_by_username(config, username)
    if error:
        return await msg.edit(f"❌ {error}")
    
    servers, error = get_servers_by_user(config, user_id)
    if error:
        return await msg.edit(f"❌ {error}")
    
    if not servers:
        return await msg.edit(f"📭 User @{username} tidak memiliki server")
    
    text = f"<b>🖥️ SERVER @{username}</b>\n\n"
    for i, s in enumerate(servers, 1):
        text += f"{i}. <b>{s['name']}</b>\n   🆔 ID: <code>{s['id']}</code>\n   🔑 Identifier: {s['identifier']}\n\n"
    
    await msg.edit(text)

@PY.UBOT("serverinfo")
@PY.TOP_CMD
async def server_detail(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>serverinfo [server_id]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"🔍 Mengambil info server {server_id}...")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], f'servers/{server_id}', is_client=False)
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    
    s = result['attributes']
    
    user_result, _ = ptero_request('GET', config['url'], config['app_api_key'], f'users/{s["user"]}', is_client=False)
    username = user_result['attributes']['username'] if user_result else "Unknown"
    
    ram_text = "UNLIMITED" if s['limits']['memory'] == 0 else f"{s['limits']['memory']} MB"
    disk_text = "UNLIMITED" if s['limits']['disk'] == 0 else f"{s['limits']['disk']} MB"
    cpu_text = "UNLIMITED" if s['limits']['cpu'] == 0 else f"{s['limits']['cpu']}%"
    
    await msg.edit(
        f"<b>🖥️ SERVER DETAIL</b>\n\n"
        f"🆔 ID: <code>{s['id']}</code>\n"
        f"📛 Nama: {s['name']}\n"
        f"👤 User: @{username} (ID: {s['user']})\n"
        f"🔑 Identifier: <code>{s['identifier']}</code>\n"
        f"📊 Status: {s['status'] or 'running'}\n\n"
        f"<b>⚙️ LIMITS:</b>\n"
        f"• RAM: {ram_text}\n"
        f"• Disk: {disk_text}\n"
        f"• CPU: {cpu_text}"
    )

# ==================== POWER ACTIONS ====================

@PY.UBOT("start")
@PY.TOP_CMD
async def start_server(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>start [server_id]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"🔄 Menjalankan server {server_id}...")
    
    result, error = await server_power_action(config, server_id, 'start')
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    await msg.edit(f"✅ Server {server_id} berhasil dijalankan!")

@PY.UBOT("stop")
@PY.TOP_CMD
async def stop_server(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>stop [server_id]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"🔄 Menghentikan server {server_id}...")
    
    result, error = await server_power_action(config, server_id, 'stop')
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    await msg.edit(f"✅ Server {server_id} berhasil dihentikan!")

@PY.UBOT("restart")
@PY.TOP_CMD
async def restart_server(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>restart [server_id]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"🔄 Merestart server {server_id}...")
    
    result, error = await server_power_action(config, server_id, 'restart')
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    await msg.edit(f"✅ Server {server_id} berhasil direstart!")

@PY.UBOT("kill")
@PY.TOP_CMD
async def kill_server(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>kill [server_id]</code>")
    
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    server_id = message.command[1]
    msg = await message.reply(f"🔄 Mematikan paksa server {server_id}...")
    
    result, error = await server_power_action(config, server_id, 'kill')
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    await msg.edit(f"✅ Server {server_id} berhasil dimatikan paksa!")

# ==================== STOPALL & STARTALL ====================

@PY.UBOT("stopall")
@PY.TOP_CMD
async def stop_all_handler(client, message):
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    if not config.get('client_working'):
        return await message.reply("❌ Client API Key tidak tersedia!")
    
    if len(message.command) > 1:
        username = message.command[1].lower()
        await stop_all_by_user(client, message, config, username)
    else:
        await stop_all_global(client, message, config)

async def stop_all_global(client, message, config):
    msg = await message.reply("🔄 Mengambil daftar semua server...")
    servers, error = get_all_servers(config)
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    if not servers:
        return await msg.edit("📭 Tidak ada server di panel")
    
    await msg.edit(f"🔄 Menghentikan {len(servers)} server...")
    success = 0
    failed = 0
    failed_list = []
    
    for server in servers:
        attr = server['attributes']
        result, error = await server_power_action(config, attr['id'], 'stop')
        if error:
            failed += 1
            failed_list.append(f"{attr['name']} (ID: {attr['id']})")
        else:
            success += 1
        await asyncio.sleep(0.3)
    
    if failed == 0:
        await msg.edit(f"<b>✅ SEMUA SERVER DIHENTIKAN!</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}")
    else:
        failed_text = "\n".join(failed_list[:5])
        await msg.edit(f"<b>⚠️ SEBAGIAN GAGAL</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}\n❌ Gagal: {failed}\n\n<b>Gagal:</b>\n{failed_text}")

async def stop_all_by_user(client, message, config, username):
    msg = await message.reply(f"🔄 Mencari server @{username}...")
    user_id, error = get_user_id_by_username(config, username)
    if error:
        return await msg.edit(f"❌ {error}")
    
    servers, error = get_servers_by_user(config, user_id)
    if error:
        return await msg.edit(f"❌ {error}")
    if not servers:
        return await msg.edit(f"📭 User @{username} tidak memiliki server")
    
    await msg.edit(f"🔄 Menghentikan {len(servers)} server milik @{username}...")
    success = 0
    failed = 0
    failed_list = []
    
    for server in servers:
        result, error = await server_power_action(config, server['id'], 'stop')
        if error:
            failed += 1
            failed_list.append(f"{server['name']} (ID: {server['id']})")
        else:
            success += 1
        await asyncio.sleep(0.3)
    
    if failed == 0:
        await msg.edit(f"<b>✅ SEMUA SERVER @{username} DIHENTIKAN!</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}")
    else:
        failed_text = "\n".join(failed_list[:5])
        await msg.edit(f"<b>⚠️ SEBAGIAN GAGAL</b>\n\n👤 User: @{username}\n📊 Total: {len(servers)}\n✅ Berhasil: {success}\n❌ Gagal: {failed}\n\n<b>Gagal:</b>\n{failed_text}")

@PY.UBOT("startall")
@PY.TOP_CMD
async def start_all_handler(client, message):
    owner_id = str(message.from_user.id)
    config = get_ptero_config(owner_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    if not config.get('client_working'):
        return await message.reply("❌ Client API Key tidak tersedia!")
    
    if len(message.command) > 1:
        username = message.command[1].lower()
        await start_all_by_user(client, message, config, username)
    else:
        await start_all_global(client, message, config)

async def start_all_global(client, message, config):
    msg = await message.reply("🔄 Mengambil daftar semua server...")
    servers, error = get_all_servers(config)
    if error:
        return await msg.edit(f"❌ Gagal: {error}")
    if not servers:
        return await msg.edit("📭 Tidak ada server di panel")
    
    await msg.edit(f"🔄 Menjalankan {len(servers)} server...")
    success = 0
    failed = 0
    failed_list = []
    
    for server in servers:
        attr = server['attributes']
        result, error = await server_power_action(config, attr['id'], 'start')
        if error:
            failed += 1
            failed_list.append(f"{attr['name']} (ID: {attr['id']})")
        else:
            success += 1
        await asyncio.sleep(0.3)
    
    if failed == 0:
        await msg.edit(f"<b>✅ SEMUA SERVER DIJALANKAN!</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}")
    else:
        failed_text = "\n".join(failed_list[:5])
        await msg.edit(f"<b>⚠️ SEBAGIAN GAGAL</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}\n❌ Gagal: {failed}\n\n<b>Gagal:</b>\n{failed_text}")

async def start_all_by_user(client, message, config, username):
    msg = await message.reply(f"🔄 Mencari server @{username}...")
    user_id, error = get_user_id_by_username(config, username)
    if error:
        return await msg.edit(f"❌ {error}")
    
    servers, error = get_servers_by_user(config, user_id)
    if error:
        return await msg.edit(f"❌ {error}")
    if not servers:
        return await msg.edit(f"📭 User @{username} tidak memiliki server")
    
    await msg.edit(f"🔄 Menjalankan {len(servers)} server milik @{username}...")
    success = 0
    failed = 0
    failed_list = []
    
    for server in servers:
        result, error = await server_power_action(config, server['id'], 'start')
        if error:
            failed += 1
            failed_list.append(f"{server['name']} (ID: {server['id']})")
        else:
            success += 1
        await asyncio.sleep(0.3)
    
    if failed == 0:
        await msg.edit(f"<b>✅ SEMUA SERVER @{username} DIJALANKAN!</b>\n\n📊 Total: {len(servers)}\n✅ Berhasil: {success}")
    else:
        failed_text = "\n".join(failed_list[:5])
        await msg.edit(f"<b>⚠️ SEBAGIAN GAGAL</b>\n\n👤 User: @{username}\n📊 Total: {len(servers)}\n✅ Berhasil: {success}\n❌ Gagal: {failed}\n\n<b>Gagal:</b>\n{failed_text}")

# ==================== INFO ====================

@PY.UBOT("listegg")
@PY.TOP_CMD
async def list_eggs(client, message):
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    msg = await message.reply("<b>🔄 Mengambil data eggs...</b>")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'nests', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal:</b> {error}")
    
    text = "<b>🥚 DAFTAR EGG:</b>\n\n"
    text += f"<i>Default Egg: {EGG_ID}</i>\n\n"
    
    for nest in result.get('data', [])[:3]:
        nest_attr = nest['attributes']
        text += f"📦 {nest_attr['name']} (ID: {nest_attr['id']})\n"
        
        eggs_result, _ = ptero_request('GET', config['url'], config['app_api_key'], f'nests/{nest_attr["id"]}/eggs', is_client=False)
        if eggs_result:
            for egg in eggs_result.get('data', [])[:3]:
                egg_attr = egg['attributes']
                text += f"  🥚 ID {egg_attr['id']} - {egg_attr['name']}\n"
        text += "\n"
    
    await msg.edit(text)

@PY.UBOT("listnode")
@PY.TOP_CMD
async def list_nodes(client, message):
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    msg = await message.reply("<b>🔄 Mengambil data nodes...</b>")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'nodes', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal:</b> {error}")
    
    nodes = result.get('data', [])
    if not nodes:
        return await msg.edit("<b>📭 Tidak ada node</b>")
    
    text = "<b>🖥️ DAFTAR NODE:</b>\n\n"
    for node in nodes[:10]:
        attr = node['attributes']
        text += f"🆔 {attr['id']} | {attr['name']}\n   🌐 {attr['fqdn']}\n\n"
    
    await msg.edit(text)

@PY.UBOT("listloc")
@PY.TOP_CMD
async def list_locations(client, message):
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    msg = await message.reply("<b>🔄 Mengambil data locations...</b>")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'locations', is_client=False)
    if error:
        return await msg.edit(f"<b>❌ Gagal:</b> {error}")
    
    locs = result.get('data', [])
    if not locs:
        return await msg.edit("<b>📭 Tidak ada lokasi</b>")
    
    text = "<b>📍 DAFTAR LOKASI:</b>\n\n"
    for loc in locs:
        attr = loc['attributes']
        text += f"🆔 {attr['id']} | {attr['short']} - {attr['long']}\n"
    
    text += f"\n<i>Default location: {LOCATION_ID}</i>"
    await msg.edit(text)

@PY.UBOT("status")
@PY.TOP_CMD
async def ptero_status(client, message):
    user_id = str(message.from_user.id)
    config = get_ptero_config(user_id)
    if not config:
        return await message.reply("❌ Panel belum dikonfigurasi!")
    
    result, error = ptero_request('GET', config['url'], config['app_api_key'], 'users', is_client=False)
    
    if error:
        status = "❌ Offline"
        detail = error
    else:
        users_count = len(result.get('data', []))
        status = "✅ Online"
        detail = f"Total users: {users_count}"
    
    client_status = "✅ Aktif" if config.get('client_working') else "❌ Tidak aktif"
    
    await message.reply(
        f"<b>🦎 PANEL STATUS</b>\n\n"
        f"📍 URL: <code>{config['url']}</code>\n"
        f"📊 Status: {status}\n"
        f"📈 {detail}\n"
        f"🔑 Client API: {client_status}\n"
        f"🥚 Default Egg: {EGG_ID}\n"
        f"📍 Default Location: {LOCATION_ID}"
    )