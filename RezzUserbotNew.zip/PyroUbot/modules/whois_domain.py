from PyroUbot import *
import whois

__MODULE__ = "𝐖𝐡𝐨𝐢𝐬"
__HELP__ = """
<blockquote><b>🌐 𝐖𝐡𝐨𝐢𝐬 𝐃𝐨𝐦𝐚𝐢𝐧</b>

 • <code>{0}whois &lt;domain></code> - Info domain</blockquote>
"""

@PY.UBOT("whois")
@PY.TOP_CMD
async def whois_domain(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .whois <domain>")
    msg = await message.reply("🌐 Mencari...")
    try:
        w = whois.whois(args[1])
        await msg.edit(f"🌐 **Domain:** {w.domain_name}\n📅 **Dibuat:** {w.creation_date}\n⏰ **Expired:** {w.expiration_date}")
    except:
        await msg.edit("❌ Gagal")
