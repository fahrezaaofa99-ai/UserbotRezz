from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐍𝐍𝐍𝐞𝐰𝐬"
__HELP__ = """
<blockquote><b>📰 𝐂𝐍𝐍 𝐍𝐞𝐰𝐬</b>

 • <code>{0}cnn</code> - Berita terbaru CNN</blockquote>
"""

@PY.UBOT("cnn")
@PY.TOP_CMD
async def cnn_news(client, message):
    msg = await message.reply("📰 Mengambil berita CNN...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/cnn/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **CNN INDONESIA**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
