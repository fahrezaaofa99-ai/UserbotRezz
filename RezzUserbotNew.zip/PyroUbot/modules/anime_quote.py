from PyroUbot import *
import requests

__MODULE__ = "𝐀𝐧𝐢𝐦𝐞𝐐𝐮𝐨𝐭𝐞"
__HELP__ = """
<blockquote><b>🎌 𝐀𝐧𝐢𝐦𝐞 𝐐𝐮𝐨𝐭𝐞</b>

 • <code>{0}animequote</code> - Quote anime random
 • <code>{0}quoteanime &lt;anime></code> - Quote dari anime tertentu</blockquote>
"""

@PY.UBOT("animequote")
@PY.TOP_CMD
async def anime_quote_random(client, message):
    try:
        r = requests.get("https://animechan.xyz/api/random")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"💬 **{data['quote']}**\n\n— {data['character']} ({data['anime']})")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("quoteanime")
@PY.TOP_CMD
async def quote_by_anime(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .quoteanime <nama anime>")
    try:
        r = requests.get(f"https://animechan.xyz/api/quotes/anime?title={args[1]}")
        if r.status_code == 200:
            data = r.json()
            if data:
                q = data[0]
                await message.reply(f"💬 **{q['quote']}**\n\n— {q['character']} ({q['anime']})")
            else:
                await message.reply("❌ Tidak ditemukan")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
