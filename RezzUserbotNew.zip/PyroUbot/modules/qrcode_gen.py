from PyroUbot import *
import qrcode
import os

__MODULE__ = "𝐐𝐑𝐂𝐨𝐝𝐞"
__HELP__ = """
<blockquote><b>📱 𝐐𝐑 𝐂𝐨𝐝𝐞</b>

 • <code>{0}qrcode &lt;teks></code> - Buat QR Code</blockquote>
"""

@PY.UBOT("qrcode")
@PY.TOP_CMD
async def qr_generate(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .qrcode <teks>")
    msg = await message.reply("📱 Membuat QR Code...")
    try:
        img = qrcode.make(args[1])
        path = f"qr_{message.id}.png"
        img.save(path)
        await message.reply_photo(path)
        os.remove(path)
        await msg.delete()
    except:
        await msg.edit("❌ Install qrcode: pip install qrcode")
