from PyroUbot import *
import random

__MODULE__ = "𝐐𝐮𝐨𝐭𝐞𝐈𝐃"
__HELP__ = """
<blockquote><b>💬 𝐐𝐮𝐨𝐭𝐞 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚</b>

 • <code>{0}quoteid</code> - Quote bijak Indonesia</blockquote>
"""

quotes_id = [
    "Hidup adalah perjuangan - Tan Malaka",
    "Jangan pernah menyerah sebelum mencoba - B.J. Habibie",
    "Berani bermimpi, berani mewujudkan - Soekarno",
    "Belajar dari masa lalu, hidup untuk masa kini, berharap untuk masa depan - Albert Einstein"
]

@PY.UBOT("quoteid")
@PY.TOP_CMD
async def quote_indonesia(client, message):
    await message.reply(f"💬 **Quote Hari Ini:**\n\n{random.choice(quotes_id)}")
