from PyroUbot import *
import random

__MODULE__ = "𝐏𝐈𝐍𝐆𝐞𝐧"
__HELP__ = """
<blockquote><b>🔢 𝐏𝐈𝐍 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}pin &lt;panjang></code> - Generate PIN numerik</blockquote>
"""

@PY.UBOT("pin")
@PY.TOP_CMD
async def pin_generator(client, message):
    args = message.text.split()
    length = int(args[1]) if len(args) > 1 else 6
    pin = ''.join(str(random.randint(0,9)) for _ in range(length))
    await message.reply(f"🔢 **PIN:** `{pin}`")
