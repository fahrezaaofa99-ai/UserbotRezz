from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐮𝐚𝐜𝐚"
__HELP__ = """
<blockquote><b>🌤️ 𝐂𝐮𝐚𝐜𝐚</b>

 • <code>{0}cuaca &lt;kota></code> - Cek cuaca</blockquote>
"""

@PY.UBOT("cuaca")
@PY.TOP_CMD
async def cek_cuaca(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .cuaca <kota>")
    msg = await message.reply(f"🌤️ Mencari cuaca di {args[1]}...")
    try:
        r = requests.get(f"https://wttr.in/{args[1]}?format=%C+%t+%w+%h")
        if r.status_code == 200:
            await msg.edit(f"🌤️ **Cuaca {args[1]}**\n\n{r.text}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
