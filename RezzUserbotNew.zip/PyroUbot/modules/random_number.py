from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐍𝐮𝐦"
__HELP__ = """
<blockquote><b>🎲 𝐑𝐚𝐧𝐝𝐨𝐦 𝐍𝐮𝐦𝐛𝐞𝐫</b>

 • <code>{0}random &lt;min> &lt;max></code> - Angka random</blockquote>
"""

@PY.UBOT("random")
@PY.TOP_CMD
async def random_num(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .random <min> <max>")
    try:
        min_val = int(args[1])
        max_val = int(args[2])
        hasil = random.randint(min_val, max_val)
        await message.reply(f"🎲 **Angka random:** {hasil}")
    except:
        await message.reply("❌ Error")
