from PyroUbot import *
import requests

__MODULE__ = "𝐌𝐨𝐭𝐢𝐯𝐚𝐬𝐢"
__HELP__ = """
<blockquote><b>💪 𝐌𝐨𝐭𝐢𝐯𝐚𝐬𝐢</b>

 • <code>{0}motivasi</code> - Kata motivasi</blockquote>
"""

@PY.UBOT("motivasi")
@PY.TOP_CMD
async def motivational_quote(client, message):
    try:
        r = requests.get("https://type.fit/api/quotes")
        if r.status_code == 200:
            quotes = r.json()
            import random
            q = random.choice(quotes)
            await message.reply(f"💪 **{q['text']}**\n\n— {q['author']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
