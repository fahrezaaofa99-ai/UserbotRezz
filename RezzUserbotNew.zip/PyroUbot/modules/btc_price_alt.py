from PyroUbot import *
import requests

__MODULE__ = "𝐁𝐓𝐂𝐏𝐫𝐢𝐜𝐞"
__HELP__ = """
<blockquote><b>💰 𝐁𝐢𝐭𝐜𝐨𝐢𝐧 𝐏𝐫𝐢𝐜𝐞</b>

 • <code>{0}btc</code> - Harga BTC terkini</blockquote>
"""

@PY.UBOT("btc")
@PY.TOP_CMD
async def btc_price_alt(client, message):
    msg = await message.reply("💰 Mengambil harga BTC...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,idr")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"💰 **Bitcoin (BTC)**\n\n💵 USD: ${data['bitcoin']['usd']:,.0f}\n🇮🇩 IDR: Rp{data['bitcoin']['idr']:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
