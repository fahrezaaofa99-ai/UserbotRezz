from PyroUbot import *

__MODULE__ = "𝐂𝐡𝐚𝐭𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>💬 𝐂𝐡𝐚𝐭 𝐈𝐧𝐟𝐨</b>

 • <code>{0}chatinfo</code> - Info chat saat ini</blockquote>
"""

@PY.UBOT("chatinfo")
@PY.TOP_CMD
async def chat_info(client, message):
    chat = message.chat
    text = f"""
╭──〔 💬 CHAT INFO 〕
│
│ 📌 **Nama:** {chat.title or 'Private Chat'}
│ 🆔 **ID:** `{chat.id}`
│ 👥 **Tipe:** {chat.type}
│ 📝 **Deskripsi:** {chat.description if chat.description else 'Tidak ada'}
│
╰── ✨ Chat Info ✨"""
    await message.reply(text)
