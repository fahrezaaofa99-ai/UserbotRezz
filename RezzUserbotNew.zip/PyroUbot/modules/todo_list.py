from PyroUbot import *
import json
import os

__MODULE__ = "𝐓𝐨𝐝𝐨"
__HELP__ = """
<blockquote><b>📋 𝐓𝐨𝐝𝐨 𝐋𝐢𝐬𝐭</b>

 • <code>{0}todo &lt;task></code> - Tambah task
 • <code>{0}todos</code> - Lihat semua task
 • <code>{0}done &lt;nomor></code> - Selesaikan task
 • <code>{0}cleartodo</code> - Hapus semua task</blockquote>
"""

TODO_FILE = "todo_list.json"

def load_todo():
    if os.path.exists(TODO_FILE):
        with open(TODO_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_todo(todo):
    with open(TODO_FILE, 'w') as f:
        json.dump(todo, f, indent=2)

@PY.UBOT("todo")
@PY.TOP_CMD
async def add_todo(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .todo <task>")
    todo = load_todo()
    user_id = str(message.from_user.id)
    if user_id not in todo:
        todo[user_id] = []
    todo[user_id].append(args[1])
    save_todo(todo)
    await message.reply(f"✅ Task ditambahkan: {args[1]}")

@PY.UBOT("todos")
@PY.TOP_CMD
async def list_todo(client, message):
    todo = load_todo()
    user_id = str(message.from_user.id)
    if user_id not in todo or not todo[user_id]:
        return await message.reply("📭 Belum ada task!")
    text = "📋 **TODO LIST**\n\n"
    for i, task in enumerate(todo[user_id], 1):
        text += f"{i}. {task}\n"
    await message.reply(text)

@PY.UBOT("done")
@PY.TOP_CMD
async def done_todo(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .done <nomor>")
    todo = load_todo()
    user_id = str(message.from_user.id)
    if user_id not in todo:
        return await message.reply("❌ Tidak ada task!")
    try:
        idx = int(args[1]) - 1
        if idx < 0 or idx >= len(todo[user_id]):
            return await message.reply("❌ Nomor tidak valid!")
        task = todo[user_id].pop(idx)
        save_todo(todo)
        await message.reply(f"✅ Task selesai: {task}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("cleartodo")
@PY.TOP_CMD
async def clear_todo(client, message):
    todo = load_todo()
    user_id = str(message.from_user.id)
    if user_id in todo:
        todo[user_id] = []
        save_todo(todo)
    await message.reply("✅ Semua task dihapus!")
