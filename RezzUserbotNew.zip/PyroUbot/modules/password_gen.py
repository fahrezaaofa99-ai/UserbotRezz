from PyroUbot import *
import random
import string

__MODULE__ = "𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 𝐆𝐞𝐧"
__HELP__ = """
<blockquote><b>🔐 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 𝐆𝐞𝐧</b>

 • <code>{0}passgen &lt;panjang></code> - Generate password</blockquote>
"""

@PY.UBOT("passgen")
@PY.TOP_CMD
async def password_gen(client, message):
    args = message.text.split()
    length = int(args[1]) if len(args) > 1 else 12
    chars = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(random.choice(chars) for _ in range(length))
    await message.reply(f"🔐 **Password:** `{password}`")
