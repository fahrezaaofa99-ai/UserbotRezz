# Nama file: /root/RezzUserbot/PyroUbot/modules/randomfacts.py
# Fitur: Random facts, quotes, trivia

from PyroUbot import *
import random
import requests
from datetime import datetime

__MODULE__ = "ʀᴀɴᴅᴏᴍꜰᴀᴄᴛꜱ"
__HELP__ = """
<blockquote><b>🎲 RANDOM & FUN FACTS</b>

• <code>{0}fact</code> - Random facts (english)
• <code>{0}fakta</code> - Fakta unik bahasa indonesia
• <code>{0}quote</code> - Random quotes
• <code>{0}trivia</code> - Random trivia questions
• <code>{0}joke</code> - Random jokes
• <code>{0}tebak</code> - Tebak-tebakan receh
• <code>{0}katabijak</code> - Kata bijak random
• <code>{0}pantun</code> - Pantun random
• <code>{0}horoskop</code> [zodiak] - Ramalan zodiak
• <code>{0}weton</code> [tanggal] - Cek weton jawa</blockquote>
"""

@PY.UBOT("fact")
@PY.TOP_CMD
async def random_fact(client, message):
    facts = [
        "Honey never spoils. Archaeologists found 3000-year-old honey in Egyptian tombs that's still edible!",
        "A day on Venus is longer than a year on Venus.",
        "Octopuses have three hearts and blue blood.",
        "Bananas are berries, but strawberries aren't.",
        "Wombat poop is cube-shaped to prevent it from rolling away.",
        "There's a species of jellyfish that's biologically immortal.",
        "The Eiffel Tower can be 15 cm taller during summer due to heat expansion.",
        "Cows have best friends and get stressed when separated."
    ]
    await message.reply(f"<b>📌 RANDOM FACT</b>\n\n{random.choice(facts)}")

@PY.UBOT("fakta")
@PY.TOP_CMD
async def fakta_unik(client, message):
    fakta = [
        "Kamu menghirup 0.00000000000000000000001% kentut Napoleon tiap bernapas",
        "Semut selalu jatuh ke kanan kalo dikasih alkohol",
        "Kucing bisa ngeluarin listrik 0.0000001 volt pas digelus",
        "Otak lu lebih aktif di malem hari daripada siang",
        "Bayi lahir dengan 300 tulang, orang dewasa cuma 206",
        "Gajah satu-satunya mamalia yang gabisa lompat",
        "Lidah lu punya sidik jari yang unik",
        "Mendengkur bisa mencapai 80 desibel, setara suara bor"
    ]
    await message.reply(f"<b>📌 FAKTA UNIK</b>\n\n{random.choice(fakta)}")

@PY.UBOT("quote")
@PY.TOP_CMD
async def random_quote(client, message):
    quotes = [
        {"q": "The only way to do great work is to love what you do.", "a": "Steve Jobs"},
        {"q": "Life is what happens when you're busy making other plans.", "a": "John Lennon"},
        {"q": "The future belongs to those who believe in the beauty of their dreams.", "a": "Eleanor Roosevelt"},
        {"q": "It does not matter how slowly you go as long as you do not stop.", "a": "Confucius"},
        {"q": "Everything you can imagine is real.", "a": "Pablo Picasso"},
    ]
    q = random.choice(quotes)
    await message.reply(f"<b>💬 RANDOM QUOTE</b>\n\n\"{q['q']}\"\n\n— {q['a']}")

@PY.UBOT("pantun")
@PY.TOP_CMD
async def pantun_random(client, message):
    pantun = [
        "Jalan-jalan ke kota Blitar\nJangan lupa beli sukun\nKalau kamu suka baca\nMending baca Al-Qur'an",
        "Pergi memancing ikan lele\nPulangnya beli sayur kangkung\nKalau kamu suka senyum-senyum\nMending jangan baca chat yang gantung",
        "Buah semangka buah kedondong\nJatuh satu ke dalam sumur\nKalau kamu lagi bengong\nMending mandi biar kagak kumur",
        "Naik becak ke pasar minggu\nPerginya sama si juleha\nKalau kamu ngerasa gitu\nMungkin kamu lagi butuh apa"
    ]
    await message.reply(f"<b>🎭 PANTUN</b>\n\n{random.choice(pantun)}")
