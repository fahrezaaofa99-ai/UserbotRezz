from PyroUbot import *
import requests

__MODULE__ = "𝐔𝐬𝐞𝐥𝐞𝐬𝐬"
__HELP__ = """
<blockquote><b>🤔 𝐔𝐬𝐞𝐥𝐞𝐬𝐬 𝐅𝐚𝐜𝐭</b>

 • <code>{0}uselessfact</code> - Fakta tidak berguna</blockquote>
"""

@PY.UBOT("uselessfact")
@PY.TOP_CMD
async def useless_fact(client, message):
    try:
        r = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
        if r.status_code == 200:
            await message.reply(f"🤔 **Useless Fact:**\n\n{r.json()['text']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
