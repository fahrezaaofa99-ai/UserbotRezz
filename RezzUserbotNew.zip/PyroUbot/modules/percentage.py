from PyroUbot import *

__MODULE__ = "𝐏𝐞𝐫𝐜𝐞𝐧𝐭𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>📊 𝐏𝐞𝐫𝐜𝐞𝐧𝐭𝐚𝐠𝐞</b>

 • <code>{0}persen &lt;total> &lt;persen></code> - Hitung persentase
 • <code>{0}diskon &lt;harga> &lt;diskon></code> - Hitung diskon
 • <code>{0}profit &lt;modal> &lt;jual></code> - Hitung profit</blockquote>
"""

@PY.UBOT("persen")
@PY.TOP_CMD
async def hitung_persen(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .persen <total> <persen>")
    total = float(args[1])
    persen = float(args[2])
    hasil = (persen / 100) * total
    await message.reply(f"📊 {persen}% dari {total} = {hasil}")

@PY.UBOT("diskon")
@PY.TOP_CMD
async def hitung_diskon(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .diskon <harga> <diskon%>")
    harga = float(args[1])
    diskon = float(args[2])
    potongan = (diskon / 100) * harga
    total = harga - potongan
    await message.reply(f"💰 Harga: {harga}\n💸 Diskon: {diskon}% ({potongan})\n✅ Total: {total}")

@PY.UBOT("profit")
@PY.TOP_CMD
async def hitung_profit(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .profit <modal> <jual>")
    modal = float(args[1])
    jual = float(args[2])
    profit = jual - modal
    persen = (profit / modal) * 100
    await message.reply(f"📈 Modal: {modal}\n💰 Jual: {jual}\n✅ Profit: {profit} ({persen:.1f}%)")
