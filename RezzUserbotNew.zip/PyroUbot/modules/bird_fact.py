from PyroUbot import *
import requests

__MODULE__ = "𝐁𝐢𝐫𝐝 𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🐦 𝐁𝐢𝐫𝐝 𝐅𝐚𝐜𝐭</b>

 • <code>{0}birdfact</code> - Fakta tentang burung
 • <code>{0}birdimg</code> - Gambar burung random</blockquote>
"""

@PY.UBOT("birdfact")
@PY.TOP_CMD
async def bird_fact(client, message):
    try:
        r = requests.get("https://some-random-api.com/facts/bird")
        if r.status_code == 200:
            fact = r.json()['fact']
            await message.reply(f"🐦 **Bird Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("birdimg")
@PY.TOP_CMD
async def bird_image(client, message):
    msg = await message.reply("🐦 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/bird")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
