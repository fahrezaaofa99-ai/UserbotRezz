from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐌𝐞𝐦𝐞"
__HELP__ = """
<blockquote><b>😂 𝐑𝐚𝐧𝐝𝐨𝐦 𝐌𝐞𝐦𝐞</b>

 • <code>{0}meme</code> - Meme random dari Reddit</blockquote>
"""

@PY.UBOT("meme")
@PY.TOP_CMD
async def random_meme(client, message):
    msg = await message.reply("😂 Mencari meme...")
    try:
        r = requests.get("https://meme-api.com/gimme")
        if r.status_code == 200:
            data = r.json()
            await message.reply_photo(data['url'], caption=f"😂 {data['title']}\n⬆️ {data['ups']} upvotes")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
