# Nama file: /root/RezzUserbot/PyroUbot/modules/gamesv2.py
# Fitur: Games versi 2 - Beda dari games.py

from PyroUbot import *
import random
import asyncio
from datetime import datetime

__MODULE__ = "ɢᴀᴍᴇsᴠ𝟸"
__HELP__ = """
<blockquote><b>🎮 GAMES V2 (BARU SEMUA!)</b>

<b>🧩 PUZZLE</b>
 • <code>{0}tebakgambar</code> - Tebak gambar (emoji)
 • <code>{0}tebaklirik</code> - Tebak lagu dari lirik
 • <code>{0}tebakfilm</code> - Tebak judul film
 • <code>{0}tebakaktor</code> - Tebak nama aktor
 • <code>{0}tebakkata</code> - Tebak kata (hangman style)

<b>🎯 ARCADE</b>
 • <code>{0}guntingbatukertas</code> - Gunting batu kertas
 • <code>{0}hompimpa</code> - Hompimpa ala anak SD
 • <code>{0}suitjepang</code> - Suit ala Jepang
 • <code>{0}aducepat</code> - Adu cepat ngetik

<b>🎲 KASINO</b>
 • <code>{0}blackjack2</code> - Blackjack versi simple
 • <code>{0}roulette2</code> - Roulette versi simple
 • <code>{0}dingdong</code> - Dingdong 12D
 • <code>{0}kocok</code> - Kocok dadu (3 dadu)

<b>🤔 KUIS</b>
 • <code>{0}kuispengetahuan</code> - Kuis pengetahuan umum
 • <code>{0}kuisipa</code> - Kuis IPA
 • <code>{0}kuisips</code> - Kuis IPS
 • <code>{0}kuismtk</code> - Kuis matematika
 • <code>{0}kuisindonesia</code> - Kuis tentang Indonesia

<b>⚔️ ADVENTURE</b>
 • <code>{0}petualangan</code> - Game petualangan text-based
 • <code>{0}labirin</code> - Game labirin sederhana
 • <code>{0}detektif</code> - Game detektif (tebak kasus)
 • <code>{0}zombie</code> - Game zombie survival</blockquote>
"""

# ==================== PUZZLE GAMES ====================

tebak_gambar_db = {
    '🐱➕📖': 'kucing baca',
    '🐶➕🏠': 'anjing rumah',
    '🍕➕👑': 'pizza raja',
    '🚗➕💨': 'mobil kencang',
    '🎸➕🔥': 'gitar panas',
    '🌊➕🏄': 'ombak selancar',
    '☕➕📰': 'kopi koran',
    '🍔➕🍟': 'burger kentang',
    '👻➕🏚️': 'hantu rumah',
    '🤖➕❤️': 'robot cinta'
}

tebak_lirik_db = [
    {"lirik": "Ku tak akan pernah berhenti, 'tuk menyayangimu", "judul": "Pupus - Dewa 19"},
    {"lirik": "Bersama Bintang, kau kan slalu dalam hati", "judul": "Bintang - Vidi Aldiano"},
    {"lirik": "Sampai nanti, sampai tua, kita kan bersama", "judul": "Sampai Nanti - Nidji"},
    {"lirik": "Katakanlah padaku, apa yang kau rasakan", "judul": "Katakanlah - Drive"},
    {"lirik": "Takkan terganti, sepanjang hidupku", "judul": "Takkan Terganti - Kahitna"}
]

tebak_film_db = [
    {"clue": "Film tentang bocah yang bisa terbang", "jawaban": "upin ipin"},
    {"clue": "Film animasi tentang mobil yang bisa bicara", "jawaban": "cars"},
    {"clue": "Film tentang putri yang suka makan apel", "jawaban": "snow white"},
    {"clue": "Film tentang singa yang jadi raja", "jawaban": "lion king"},
    {"clue": "Film tentang mainan yang hidup", "jawaban": "toy story"}
]

@PY.UBOT("tebakgambar")
@PY.TOP_CMD
async def tebak_gambar(client, message):
    emoji, jawaban = random.choice(list(tebak_gambar_db.items()))
    
    msg = await message.reply(
        f"<b>🎨 TEBAK GAMBAR</b>\n\n"
        f"Emoji: {emoji}\n\n"
        f"Ketik <code>jawab [jawabanmu]</code>"
    )
    
    # Simpan session
    game_sessions[f"gambar_{message.from_user.id}"] = {
        "jawaban": jawaban,
        "chat_id": message.chat.id
    }

@PY.UBOT("tebaklirik")
@PY.TOP_CMD
async def tebak_lirik(client, message):
    data = random.choice(tebak_lirik_db)
    
    msg = await message.reply(
        f"<b>🎵 TEBAK LIRIK</b>\n\n"
        f"Lirik: \"{data['lirik']}\"\n\n"
        f"Ketik <code>jawab [judul lagu]</code>"
    )
    
    game_sessions[f"lirik_{message.from_user.id}"] = {
        "jawaban": data['judul'].lower(),
        "chat_id": message.chat.id
    }

@PY.UBOT("tebakfilm")
@PY.TOP_CMD
async def tebak_film(client, message):
    data = random.choice(tebak_film_db)
    
    await message.reply(
        f"<b>🎬 TEBAK FILM</b>\n\n"
        f"Clue: {data['clue']}\n\n"
        f"Ketik <code>jawab [judul film]</code>"
    )
    
    game_sessions[f"film_{message.from_user.id}"] = {
        "jawaban": data['jawaban'],
        "chat_id": message.chat.id
    }

# ==================== ARCADE GAMES ====================

@PY.UBOT("guntingbatukertas")
@PY.TOP_CMD
async def gbk(client, message):
    if len(message.command) < 2:
        return await message.reply("Pilih: gunting/batu/kertas")
    
    user = message.command[1].lower()
    if user not in ['gunting', 'batu', 'kertas']:
        return await message.reply("Pilih: gunting/batu/kertas")
    
    bot = random.choice(['gunting', 'batu', 'kertas'])
    
    if user == bot:
        hasil = "🤝 SERI!"
    elif (user == 'gunting' and bot == 'kertas') or \
         (user == 'batu' and bot == 'gunting') or \
         (user == 'kertas' and bot == 'batu'):
        hasil = "✅ KAMU MENANG!"
    else:
        hasil = "❌ KAMU KALAH!"
    
    await message.reply(
        f"<b>✂️ GUNTING BATU KERTAS</b>\n\n"
        f"Kamu: {user}\n"
        f"Bot: {bot}\n"
        f"Hasil: {hasil}"
    )

@PY.UBOT("hompimpa")
@PY.TOP_CMD
async def hompimpa(client, message):
    hasil = random.choice(['hitam', 'putih'])
    lawan = 'putih' if hasil == 'hitam' else 'hitam'
    
    await message.reply(
        f"<b>🎭 HOMPIMPA</b>\n\n"
        f"Hompimpa alaium gambreng!\n\n"
        f"Kamu dapat: <b>{hasil}</b>\n"
        f"Lawan dapat: {lawan}\n\n"
        f"{'✅ MENANG' if hasil == 'hitam' else '❌ KALAH'}"
    )

@PY.UBOT("suitjepang")
@PY.TOP_CMD
async def suit_jepang(client, message):
    pilihan = ['saru', 'kitsune', 'tanuki']
    arti = {'saru': '🐒 monyet', 'kitsune': '🦊 rubah', 'tanuki': '🦝 rakun'}
    
    if len(message.command) < 2:
        return await message.reply(f"Pilih: {', '.join(pilihan)}")
    
    user = message.command[1].lower()
    if user not in pilihan:
        return await message.reply(f"Pilih: {', '.join(pilihan)}")
    
    bot = random.choice(pilihan)
    
    # Rules suit Jepang: saru > kitsune > tanuki > saru
    if user == bot:
        hasil = "🤝 SERI!"
    elif (user == 'saru' and bot == 'kitsune') or \
         (user == 'kitsune' and bot == 'tanuki') or \
         (user == 'tanuki' and bot == 'saru'):
        hasil = "✅ MENANG!"
    else:
        hasil = "❌ KALAH!"
    
    await message.reply(
        f"<b>🎌 SUIT JEPANG</b>\n\n"
        f"Kamu: {arti[user]}\n"
        f"Bot: {arti[bot]}\n"
        f"Hasil: {hasil}"
    )

@PY.UBOT("aducepat")
@PY.TOP_CMD
async def adu_cepat(client, message):
    kata = ['saya', 'kamu', 'mereka', 'kita', 'dia', 'ini', 'itu', 'disini', 'disana', 'cepat']
    target = random.choice(kata)
    
    msg = await message.reply(
        f"<b>⚡ ADU CEPAT NGETIK</b>\n\n"
        f"Ketik kata: <b>{target}</b>\n\n"
        f"Kamu punya 5 detik!"
    )
    
    start = datetime.now()
    
    try:
        resp = await client.wait_for('message', timeout=5, check=lambda m: m.from_user.id == message.from_user.id and m.chat.id == message.chat.id)
        end = datetime.now()
        
        waktu = (end - start).total_seconds()
        
        if resp.text.lower() == target:
            await message.reply(f"✅ BENAR! Waktu: {waktu:.2f} detik")
        else:
            await message.reply(f"❌ SALAH! Kata yang benar: {target}")
    except asyncio.TimeoutError:
        await message.reply(f"⏰ WAKTU HABIS! Kata yang benar: {target}")

# ==================== KASINO ====================

@PY.UBOT("blackjack2")
@PY.TOP_CMD
async def blackjack_simple(client, message):
    kartu = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    
    player = random.choices(kartu, k=2)
    dealer = random.choices(kartu, k=2)
    
    def hitung(kartu_list):
        total = 0
        for k in kartu_list:
            if k in ['J','Q','K']:
                total += 10
            elif k == 'A':
                total += 11 if total <= 10 else 1
            else:
                total += int(k)
        return total
    
    player_total = hitung(player)
    dealer_total = hitung(dealer)
    
    if player_total > 21:
        hasil = "❌ KALAH (BUST)"
    elif dealer_total > 21:
        asil = "✅ MENANG (DEALER BUST)"
    elif player_total > dealer_total:
        hasil = "✅ MENANG"
    elif player_total < dealer_total:
        hasil = "❌ KALAH"
    else:
        hasil = "🤝 SERI"
    
    await message.reply(
        f"<b>♠️ BLACKJACK SIMPLE</b>\n\n"
        f"Kartu kamu: {', '.join(player)} (Total: {player_total})\n"
        f"Kartu dealer: {', '.join(dealer)} (Total: {dealer_total})\n\n"
        f"Hasil: {hasil}"
    )

@PY.UBOT("roulette2")
@PY.TOP_CMD
async def roulette_simple(client, message):
    if len(message.command) < 2:
        return await message.reply("Pilih: merah/hitam/hijau atau angka 0-36")
    
    pilihan = message.command[1].lower()
    
    merah = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]
    hitam = [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35]
    
    result = random.randint(0, 36)
    
    if result == 0:
        warna = 'hijau'
    elif result in merah:
        warna = 'merah'
    else:
        warna = 'hitam'
    
    if pilihan == warna or pilihan == str(result):
        hasil = "✅ MENANG!"
    elif pilihan in ['merah','hitam','hijau'] and pilihan == warna:
        hasil = "✅ MENANG!"
    else:
        hasil = "❌ KALAH!"
    
    await message.reply(
        f"<b>🎡 ROULETTE</b>\n\n"
        f"Hasil: {result} ({warna})\n"
        f"Pilihanmu: {pilihan}\n"
        f"Hasil: {hasil}"
    )

@PY.UBOT("dingdong")
@PY.TOP_CMD
async def dingdong(client, message):
    dadu = [random.randint(1, 6) for _ in range(3)]
    total = sum(dadu)
    
    hasil = "MENANG" if total > 10 else "KALAH"
    
    await message.reply(
        f"<b>🎲 DINGDONG 12D</b>\n\n"
        f"Dadu: {dadu[0]} | {dadu[1]} | {dadu[2]}\n"
        f"Total: {total}\n\n"
        f"{'✅ ' + hasil if hasil == 'MENANG' else '❌ ' + hasil}"
    )

@PY.UBOT("kocok")
@PY.TOP_CMD
async def kocok_dadu(client, message):
    dadu = [random.randint(1, 6) for _ in range(3)]
    
    emoji = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
    
    await message.reply(
        f"<b>🎲 KOCOK DADU</b>\n\n"
        f"{emoji[dadu[0]-1]} {dadu[0]}  |  {emoji[dadu[1]-1]} {dadu[1]}  |  {emoji[dadu[2]-1]} {dadu[2]}\n\n"
        f"Total: {sum(dadu)}"
    )

# ==================== KUIS ====================

kuis_pengetahuan = [
    {"soal": "Apa ibu kota Indonesia?", "jawaban": "jakarta"},
    {"soal": "Berapa jumlah provinsi di Indonesia?", "jawaban": "38"},
    {"soal": "Siapa presiden pertama Indonesia?", "jawaban": "soekarno"},
    {"soal": "Apa nama gunung tertinggi di Jawa?", "jawaban": "semeru"},
    {"soal": "Apa nama danau terbesar di Indonesia?", "jawaban": "toba"}
]

kuis_ipa = [
    {"soal": "Apa planet terbesar di tata surya?", "jawaban": "jupiter"},
    {"soal": "Hewan apa yang bisa hidup di air dan darat?", "jawaban": "amfibi"},
    {"soal": "Apa gas yang paling banyak di udara?", "jawaban": "nitrogen"},
    {"soal": "Apa nama proses tumbuhan membuat makanan?", "jawaban": "fotosintesis"},
    {"soal": "Berapa jumlah tulang manusia dewasa?", "jawaban": "206"}
]

@PY.UBOT("kuispengetahuan")
@PY.TOP_CMD
async def kuis_pengetahuan_umum(client, message):
    data = random.choice(kuis_pengetahuan)
    
    await message.reply(
        f"<b>📚 KUIS PENGETAHUAN UMUM</b>\n\n"
        f"Soal: {data['soal']}\n\n"
        f"Ketik <code>jawab [jawabanmu]</code>"
    )
    
    game_sessions[f"kuis_{message.from_user.id}"] = {
        "jawaban": data['jawaban'],
        "chat_id": message.chat.id
    }

@PY.UBOT("kuisipa")
@PY.TOP_CMD
async def kuis_ipa_func(client, message):
    data = random.choice(kuis_ipa)
    
    await message.reply(
        f"<b>🔬 KUIS IPA</b>\n\n"
        f"Soal: {data['soal']}\n\n"
        f"Ketik <code>jawab [jawabanmu]</code>"
    )
    
    game_sessions[f"kuis_{message.from_user.id}"] = {
        "jawaban": data['jawaban'],
        "chat_id": message.chat.id
    }

@PY.UBOT("kuismtk")
@PY.TOP_CMD
async def kuis_mtk(client, message):
    a = random.randint(1, 10)
    b = random.randint(1, 10)
    op = random.choice(['+', '-', '×'])
    
    if op == '+':
        jawaban = a + b
    elif op == '-':
        jawaban = a - b
    else:  # ×
        jawaban = a * b
    
    await message.reply(
        f"<b>🧮 KUIS MATEMATIKA</b>\n\n"
        f"Soal: {a} {op} {b} = ?\n\n"
        f"Ketik <code>jawab [angka]</code>"
    )
    
    game_sessions[f"mtk_{message.from_user.id}"] = {
        "jawaban": str(jawaban),
        "chat_id": message.chat.id
    }

@PY.UBOT("kuisindonesia")
@PY.TOP_CMD
async def kuis_indonesia(client, message):
    soal = [
        {"soal": "Siapa pahlawan dari Surabaya?", "jawaban": "sutomo"},
        {"soal": "Apa nama tarian dari Aceh?", "jawaban": "saman"},
        {"soal": "Apa nama rumah adat Sumatera Barat?", "jawaban": "gadang"},
        {"soal": "Siapa penulis lagu Indonesia Raya?", "jawaban": "wr supratman"},
        {"soal": "Apa nama candi di Magelang?", "jawaban": "borobudur"}
    ]
    
    data = random.choice(soal)
    
    await message.reply(
        f"<b>🇮🇩 KUIS INDONESIA</b>\n\n"
        f"Soal: {data['soal']}\n\n"
        f"Ketik <code>jawab [jawabanmu]</code>"
    )
    
    game_sessions[f"kuis_{message.from_user.id}"] = {
        "jawaban": data['jawaban'],
        "chat_id": message.chat.id
    }

# ==================== ADVENTURE ====================

@PY.UBOT("petualangan")
@PY.TOP_CMD
async def petualangan(client, message):
    petualangan_text = """
🏰 <b>PETUALANGAN DIMULAI</b>

Kamu berada di pintu masuk hutan terlarang.
Ada dua jalan: kiri dan kanan.

Pilih: <code>kiri</code> atau <code>kanan</code>
    """
    
    msg = await message.reply(petualangan_text)
    
    game_sessions[f"petualangan_{message.from_user.id}"] = {
        "step": 1,
        "chat_id": message.chat.id
    }

@PY.UBOT("labirin")
@PY.TOP_CMD
async def labirin(client, message):
    labirin_text = """
🧩 <b>LABIRIN</b>

Kamu tersesat di labirin.
Ada 3 pintu: merah, biru, hijau.

Hanya satu pintu yang benar.
Pilih: <code>merah</code> / <code>biru</code> / <code>hijau</code>
    """
    
    benar = random.choice(['merah', 'biru', 'hijau'])
    
    msg = await message.reply(labirin_text)
    
    game_sessions[f"labirin_{message.from_user.id}"] = {
        "benar": benar,
        "chat_id": message.chat.id
    }

# ==================== HANDLER JAWAB ====================

game_sessions = {}

@PY.UBOT("jawab")
async def jawab_game(client, message):
    if len(message.command) < 2:
        return
    
    user_id = message.from_user.id
    
    # Cek session games
    found = None
    session_key = None
    
    for key in list(game_sessions.keys()):
        if key.endswith(str(user_id)):
            if game_sessions[key].get('chat_id') == message.chat.id:
                found = game_sessions[key]
                session_key = key
                break
    
    if not found:
        return
    
    jawaban_user = ' '.join(message.command[1:]).lower().strip()
    
    if 'gambar' in session_key:
        if jawaban_user == found['jawaban']:
            await message.reply("✅ BENAR! Kamu hebat!")
        else:
            await message.reply(f"❌ SALAH! Jawabannya: {found['jawaban']}")
    
    elif 'lirik' in session_key:
        if jawaban_user in found['jawaban'] or found['jawaban'] in jawaban_user:
            await message.reply("✅ BENAR! Kamu tahu lagunya!")
        else:
            await message.reply(f"❌ SALAH! Judulnya: {found['jawaban']}")
    
    elif 'film' in session_key:
        if jawaban_user == found['jawaban']:
            await message.reply("✅ BENAR! Jagoan film!")
        else:
            await message.reply(f"❌ SALAH! Judulnya: {found['jawaban']}")
    
    elif 'kuis' in session_key or 'mtk' in session_key:
        if jawaban_user == found['jawaban']:
            await message.reply("✅ BENAR! Jawaban tepat!")
        else:
            await message.reply(f"❌ SALAH! Jawabannya: {found['jawaban']}")
    
    elif 'labirin' in session_key:
        if jawaban_user == found['benar']:
            await message.reply("✅ SELAMAT! Kamu berhasil keluar dari labirin!")
        else:
            await message.reply(f"❌ Kamu terssat! Coba pintu lain...")
            return  # Jangan hapus session
    
    elif 'petualangan' in session_key:
        if found['step'] == 1:
            if jawaban_user == 'kiri':
                await message.reply("Kamu bertemu monster! Game over.")
            else:
                await message.reply("Kamu menemukan harta karun! SELAMAT!")
        # Hapus session setelah selesai
    
    # Hapus session kalo game selesai
    if session_key:
        del game_sessions[session_key]
