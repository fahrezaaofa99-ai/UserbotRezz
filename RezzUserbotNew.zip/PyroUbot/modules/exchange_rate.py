from PyroUbot import *
import requests

__MODULE__ = "𝐄𝐱𝐜𝐡𝐚𝐧𝐠𝐞"
__HELP__ = """
<blockquote><b>💱 𝐄𝐱𝐜𝐡𝐚𝐧𝐠𝐞 𝐑𝐚𝐭𝐞</b>

 • <code>{0}rate</code> - Kurs USD/IDR terkini</bloquote>
"""

@PY.UBOT("rate")
@PY.TOP_CMD
async def exchange_rate(client, message):
    msg = await message.reply("💱 Mengambil kurs...")
    try:
        r = requests.get("https://api.exchangerate-api.com/v4/latest/USD")
        if r.status_code == 200:
            idr = r.json()['rates']['IDR']
            await msg.edit(f"💱 **Kurs USD/IDR**\n\n1 USD = Rp{idr:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
