from PyroUbot import *
import random

__MODULE__ = "𝐏𝐢𝐜𝐤𝐮𝐩𝐥𝐢𝐧𝐞"
__HELP__ = """
<blockquote><b>💘 𝐏𝐢𝐜𝐤𝐮𝐩 𝐋𝐢𝐧𝐞</b>

 • <code>{0}pedekate</code> - Kata gombal random</blockquote>
"""

pickup = [
    "Kamu tau gak bedanya aku sama kamu? Aku ada di sini, kamu ada di hati aku",
    "Kamu kayak Indomie, aku suka kalo kamu udah mateng",
    "Aku bukan pelukis, tapi aku bisa gambar senyuman di wajah kamu",
    "Kamu kayak kopi, bikin aku melek setiap malem",
    "Boleh minta tolong? Tolong jangan pergi dari hidup aku"
]

@PY.UBOT("pedekate")
@PY.TOP_CMD
async def pickup_line(client, message):
    await message.reply(f"💘 **Gombal:**\n\n{random.choice(pickup)}")
