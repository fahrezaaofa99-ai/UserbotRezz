# Nama file: /root/RezzUserbot/PyroUbot/modules/indonesia.py
# Fitur: Khusus Indonesia

from PyroUbot import *
import random
from datetime import datetime

__MODULE__ = "ɪɴᴅᴏɴᴇꜱɪᴀ"
__HELP__ = """
<blockquote><b>🇮🇩 INDONESIA SPECIFIC</b>

• <code>{0}libur</code> - Cek tanggal merah/libur nasional
• <code>{0}tanggalmerah</code> - Daftar libur tahun ini
• <code>{0}hariini</code> - Info hari ini (tanggal, pasaran, libur)
• <code>{0}weton</code> [tanggal] - Cek weton jawa
• <code>{0}primbon</code> [tanggal lahir] - Ramalan primbon
• <code>{0}jokowi</code> - Quotes Bapak Presiden
• <code>{0}daerah</code> [provinsi] - Info provinsi Indonesia
• <code>{0}kodebank</code> [bank] - Kode transfer bank
• <code>{0}kodepos</code> [kota] - Kode pos daerah
• <code>{0}pulsa</code> [provider] - Kode isi pulsa</blockquote>
"""

LIBUR_2026 = [
    {"tanggal": "2026-01-01", "nama": "Tahun Baru 2026 Masehi"},
    {"tanggal": "2026-03-29", "nama": "Hari Raya Nyepi"},
    {"tanggal": "2026-03-31", "nama": "Wafat Isa Almasih"},
    {"tanggal": "2026-05-01", "nama": "Hari Buruh Internasional"},
    {"tanggal": "2026-05-14", "nama": "Kenaikan Isa Almasih"},
    {"tanggal": "2026-05-27", "nama": "Hari Raya Waisak"},
    {"tanggal": "2026-06-01", "nama": "Hari Lahir Pancasila"},
    {"tanggal": "2026-06-27", "nama": "Idul Adha"},
    {"tanggal": "2026-07-18", "nama": "Tahun Baru Islam"},
    {"tanggal": "2026-08-17", "nama": "Hari Kemerdekaan RI"},
    {"tanggal": "2026-09-26", "nama": "Maulid Nabi Muhammad"},
    {"tanggal": "2026-12-25", "nama": "Hari Raya Natal"}
]

PROVINSI = {
    "aceh": {"ibukota": "Banda Aceh", "pulau": "Sumatera", "populasi": "5.3 juta"},
    "sumut": {"ibukota": "Medan", "pulau": "Sumatera", "populasi": "15 juta"},
    "sumbar": {"ibukota": "Padang", "pulau": "Sumatera", "populasi": "5.6 juta"},
    "riau": {"ibukota": "Pekanbaru", "pulau": "Sumatera", "populasi": "6.5 juta"},
    "jambi": {"ibukota": "Jambi", "pulau": "Sumatera", "populasi": "3.6 juta"},
    "sumsel": {"ibukota": "Palembang", "pulau": "Sumatera", "populasi": "8.5 juta"},
    "bengkulu": {"ibukota": "Bengkulu", "pulau": "Sumatera", "populasi": "2 juta"},
    "lampung": {"ibukota": "Bandar Lampung", "pulau": "Sumatera", "populasi": "8.5 juta"},
    "babel": {"ibukota": "Pangkal Pinang", "pulau": "Sumatera", "populasi": "1.5 juta"},
    "kepri": {"ibukota": "Tanjung Pinang", "pulau": "Sumatera", "populasi": "2.1 juta"},
    "jakarta": {"ibukota": "Jakarta", "pulau": "Jawa", "populasi": "10.6 juta"},
    "jabar": {"ibukota": "Bandung", "pulau": "Jawa", "populasi": "48.2 juta"},
    "jateng": {"ibukota": "Semarang", "pulau": "Jawa", "populasi": "36.5 juta"},
    "jogja": {"ibukota": "Yogyakarta", "pulau": "Jawa", "populasi": "3.6 juta"},
    "jatim": {"ibukota": "Surabaya", "pulau": "Jawa", "populasi": "40.7 juta"},
    "banten": {"ibukota": "Serang", "pulau": "Jawa", "populasi": "12 juta"},
    "bali": {"ibukota": "Denpasar", "pulau": "Bali", "populasi": "4.3 juta"},
    "ntb": {"ibukota": "Mataram", "pulau": "Nusa Tenggara", "populasi": "5.3 juta"},
    "ntt": {"ibukota": "Kupang", "pulau": "Nusa Tenggara", "populasi": "5.5 juta"},
    "kalbar": {"ibukota": "Pontianak", "pulau": "Kalimantan", "populasi": "5.4 juta"},
    "kalteng": {"ibukota": "Palangkaraya", "pulau": "Kalimantan", "populasi": "2.7 juta"},
    "kalsel": {"ibukota": "Banjarmasin", "pulau": "Kalimantan", "populasi": "4.1 juta"},
    "kaltim": {"ibukota": "Samarinda", "pulau": "Kalimantan", "populasi": "3.7 juta"},
    "kaltara": {"ibukota": "Tanjung Selor", "pulau": "Kalimantan", "populasi": "0.7 juta"},
    "sulut": {"ibukota": "Manado", "pulau": "Sulawesi", "populasi": "2.6 juta"},
    "sulteng": {"ibukota": "Palu", "pulau": "Sulawesi", "populasi": "3 juta"},
    "sulsel": {"ibukota": "Makassar", "pulau": "Sulawesi", "populasi": "9.1 juta"},
    "sultra": {"ibukota": "Kendari", "pulau": "Sulawesi", "populasi": "2.7 juta"},
    "gorontalo": {"ibukota": "Gorontalo", "pulau": "Sulawesi", "populasi": "1.2 juta"},
    "sulbar": {"ibukota": "Mamuju", "pulau": "Sulawesi", "populasi": "1.4 juta"},
    "maluku": {"ibukota": "Ambon", "pulau": "Maluku", "populasi": "1.8 juta"},
    "malut": {"ibukota": "Sofifi", "pulau": "Maluku", "populasi": "1.3 juta"},
    "papua": {"ibukota": "Jayapura", "pulau": "Papua", "populasi": "3.4 juta"},
    "pabar": {"ibukota": "Manokwari", "pulau": "Papua", "populasi": "1.1 juta"}
}

@PY.UBOT("libur")
@PY.TOP_CMD
async def cek_libur(client, message):
    """Cek apakah hari ini libur"""
    today = datetime.now().strftime("%Y-%m-%d")
    
    for libur in LIBUR_2026:
        if libur["tanggal"] == today:
            return await message.reply(f"<b>📅 HARI INI LIBUR!</b>\n\n{libur['nama']}")
    
    await message.reply("<b>📅 Hari ini BUKAN tanggal merah.</b>")

@PY.UBOT("tanggalmerah")
@PY.TOP_CMD
async def daftar_libur(client, message):
    """Daftar libur nasional 2026"""
    text = "<b>📅 TANGGAL MERAH 2026</b>\n\n"
    for libur in LIBUR_2026:
        text += f"• {libur['tanggal']} : {libur['nama']}\n"
    await message.reply(text)

@PY.UBOT("hariini")
@PY.TOP_CMD
async def info_hari_ini(client, message):
    """Info hari ini"""
    now = datetime.now()
    tanggal = now.strftime("%d %B %Y")
    hari = now.strftime("%A")
    
    # Konversi hari ke Indonesia
    hari_ind = {
        "Monday": "Senin", "Tuesday": "Selasa", "Wednesday": "Rabu",
        "Thursday": "Kamis", "Friday": "Jumat", "Saturday": "Sabtu",
        "Sunday": "Minggu"
    }
    hari_id = hari_ind.get(hari, hari)
    
    # Cek libur
    today = now.strftime("%Y-%m-%d")
    libur = "Tidak"
    for l in LIBUR_2026:
        if l["tanggal"] == today:
            libur = f"Ya, {l['nama']}"
            break
    
    # Pasaran Jawa (simulasi)
    pasaran = ["Legi", "Pahing", "Pon", "Wage", "Kliwon"]
    pasar = pasaran[now.day % 5]
    
    await message.reply(
        f"<b>📌 INFO HARI INI</b>\n\n"
        f"📅 Tanggal: {tanggal}\n"
        f"🗓️ Hari: {hari_id}\n"
        f"📆 Pasaran: {pasar}\n"
        f"📌 Libur: {libur}"
    )

@PY.UBOT("daerah")
@PY.TOP_CMD
async def info_provinsi(client, message):
    """Info provinsi Indonesia"""
    if len(message.command) < 2:
        prov_list = ", ".join(list(PROVINSI.keys())[:10])
        return await message.reply(f"Masukkan nama provinsi!\nContoh: {PROVINSI.keys()}")
    
    prov = message.command[1].lower()
    
    if prov in PROVINSI:
        data = PROVINSI[prov]
        await message.reply(
            f"<b>📍 INFO PROVINSI {prov.upper()}</b>\n\n"
            f"🏛️ Ibukota: {data['ibukota']}\n"
            f"🗺️ Pulau: {data['pulau']}\n"
            f"👥 Populasi: {data['populasi']} jiwa"
        )
    else:
        await message.reply(f"Provinsi '{prov}' tidak ditemukan")
