from PyroUbot import *
import wikipedia

__MODULE__ = "𝐖𝐢𝐤𝐢 𝐒𝐮𝐦𝐦𝐚𝐫𝐲"
__HELP__ = """
<blockquote><b>📚 𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚</b>

 • <code>{0}wiki &lt;keyword></code> - Ringkasan Wikipedia
 • <code>{0}wikisearch &lt;keyword></code> - Cari artikel</blockquote>
"""

@PY.UBOT("wiki")
@PY.TOP_CMD
async def wiki_summary(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .wiki <keyword>")
    msg = await message.reply("🔍 Mencari...")
    try:
        wikipedia.set_lang("id")
        summary = wikipedia.summary(args[1], sentences=5)
        await msg.edit(f"📚 **{args[1].title()}**\n\n{summary}")
    except wikipedia.exceptions.DisambiguationError as e:
        await msg.edit(f"❌ Banyak arti: {', '.join(e.options[:5])}")
    except:
        await msg.edit("❌ Tidak ditemukan")

@PY.UBOT("wikisearch")
@PY.TOP_CMD
async def wiki_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .wikisearch <keyword>")
    msg = await message.reply("🔍 Mencari...")
    try:
        wikipedia.set_lang("id")
        results = wikipedia.search(args[1], results=5)
        text = "📚 **HASIL PENCARIAN**\n\n" + "\n".join([f"• {r}" for r in results])
        await msg.edit(text)
    except:
        await msg.edit("❌ Error")
