from PyroUbot import *

__MODULE__ = "𝐍𝐮𝐦𝐛𝐞𝐫𝐓𝐨𝐖𝐨𝐫𝐝𝐬"
__HELP__ = """
<blockquote><b>🔢 𝐍𝐮𝐦𝐛𝐞𝐫 𝐓𝐨 𝐖𝐨𝐫𝐝𝐬</b>

 • <code>{0}numwords &lt;angka></code> - Angka ke kata</blockquote>
"""

def number_to_words(n):
    angka = ["", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan"]
    if n < 10:
        return angka[n]
    elif n < 20:
        return ["sepuluh", "sebelas", "dua belas", "tiga belas", "empat belas", "lima belas", "enam belas", "tujuh belas", "delapan belas", "sembilan belas"][n-10]
    elif n < 100:
        return angka[n//10] + " puluh " + angka[n%10]
    elif n < 200:
        return "seratus " + number_to_words(n-100)
    elif n < 1000:
        return angka[n//100] + " ratus " + number_to_words(n%100)
    return "Angka terlalu besar"

@PY.UBOT("numwords")
@PY.TOP_CMD
async def num_to_words(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .numwords <angka>")
    try:
        angka = int(args[1])
        if angka > 999:
            return await message.reply("❌ Maksimal 999")
        kata = number_to_words(angka)
        await message.reply(f"🔢 {angka} = {kata}")
    except:
        await message.reply("❌ Masukkan angka valid")
