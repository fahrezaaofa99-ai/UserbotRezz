from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐄𝐦𝐨𝐣𝐢"
__HELP__ = """
<blockquote><b>😀 𝐑𝐚𝐧𝐝𝐨𝐦 𝐄𝐦𝐨𝐣𝐢</b>

 • <code>{0}emoji</code> - Random emoji</blockquote>
"""

emojis = ["😀", "😂", "🥰", "😍", "🤣", "😊", "😎", "🤔", "😭", "😱", "🥳", "🤯"]

@PY.UBOT("emoji")
@PY.TOP_CMD
async def random_emoji_gen(client, message):
    await message.reply(f"🔀 **Random Emoji:** {random.choice(emojis)}")
