from PyroUbot import *
import requests

__MODULE__ = "𝐏𝐚𝐧𝐝𝐚 𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🐼 𝐏𝐚𝐧𝐝𝐚 𝐅𝐚𝐜𝐭</b>

 • <code>{0}pandafact</code> - Fakta tentang panda
 • <code>{0}pandaimg</code> - Gambar panda random</blockquote>
"""

@PY.UBOT("pandafact")
@PY.TOP_CMD
async def panda_fact(client, message):
    try:
        r = requests.get("https://some-random-api.com/facts/panda")
        if r.status_code == 200:
            fact = r.json()['fact']
            await message.reply(f"🐼 **Panda Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("pandaimg")
@PY.TOP_CMD
async def panda_image(client, message):
    msg = await message.reply("🐼 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/panda")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
