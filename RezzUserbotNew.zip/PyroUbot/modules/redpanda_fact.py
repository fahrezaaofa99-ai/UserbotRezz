from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐞𝐝 𝐏𝐚𝐧𝐝𝐚"
__HELP__ = """
<blockquote><b>🦝 𝐑𝐞𝐝 𝐏𝐚𝐧𝐝𝐚 𝐅𝐚𝐜𝐭</b>

 • <code>{0}redpanda</code> - Fakta red panda
 • <code>{0}redpandaimg</code> - Gambar red panda</blockquote>
"""

@PY.UBOT("redpanda")
@PY.TOP_CMD
async def redpanda_fact(client, message):
    try:
        r = requests.get("https://some-random-api.com/facts/redpanda")
        if r.status_code == 200:
            fact = r.json()['fact']
            await message.reply(f"🦝 **Red Panda Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("redpandaimg")
@PY.TOP_CMD
async def redpanda_image(client, message):
    msg = await message.reply("🦝 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/redpanda")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
