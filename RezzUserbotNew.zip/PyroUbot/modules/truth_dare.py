from PyroUbot import *
import random

__MODULE__ = "𝐓𝐫𝐮𝐭𝐡𝐃𝐚𝐫𝐞"
__HELP__ = """
<blockquote><b>🎲 𝐓𝐫𝐮𝐭𝐡 𝐨𝐫 𝐃𝐚𝐫𝐞</b>

 • <code>{0}truth</code> - Pertanyaan truth random
 • <code>{0}dare</code> - Tantangan dare random</blockquote>
"""

truths = [
    "Pernah suka sama siapa?",
    "Pengalaman paling memalukan?",
    "Rahasia terbesarmu?",
    "Pernah bohong ke orang tua?",
    "Siapa yang paling kamu benci?"
]

dares = [
    "Kirim stiker lucu ke 3 chat",
    "Ucapin 'I love you' ke random contact",
    "Share lagu yang kamu denger sekarang",
    "Kasih compliment ke 1 orang di grup",
    "Ceritain hari kamu dengan gaya alay"
]

@PY.UBOT("truth")
@PY.TOP_CMD
async def truth_game(client, message):
    await message.reply(f"📖 **Truth:**\n\n{random.choice(truths)}")

@PY.UBOT("dare")
@PY.TOP_CMD
async def dare_game(client, message):
    await message.reply(f"⚡ **Dare:**\n\n{random.choice(dares)}")
