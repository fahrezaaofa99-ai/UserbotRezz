from PyroUbot import *
import uuid

__MODULE__ = "𝐔𝐔𝐈𝐃"
__HELP__ = """
<blockquote><b>🆔 𝐔𝐔𝐈𝐃 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}uuid</code> - Generate UUID random</blockquote>
"""

@PY.UBOT("uuid")
@PY.TOP_CMD
async def generate_uuid(client, message):
    uid = uuid.uuid4()
    await message.reply(f"🆔 **UUID:** `{uid}`")
