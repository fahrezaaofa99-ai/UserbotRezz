# Nama file: /root/RezzUserbot/PyroUbot/modules/imagetools.py
# Fitur: Tools untuk gambar

from PyroUbot import *
import os
import requests
from PIL import Image, ImageFilter, ImageEnhance

__MODULE__ = "ɪᴍᴀɢᴇᴛᴏᴏʟs"
__HELP__ = """
<blockquote><b>🖼️ IMAGE TOOLS</b>

<b>EFFECTS</b>
 • <code>{0}blur</code> [reply gambar] - Buram
 • <code>{0}bright</code> [reply] - Cerah
 • <code>{0}dark</code> [reply] - Gelap
 • <code>{0}contrast</code> [reply] - Kontras
 • <code>{0}sharpen</code> [reply] - Tajam
 • <code>{0}smooth</code> [reply] - Halus
 • <code>{0}edge</code> [reply] - Deteksi tepi
 • <code>{0}emboss</code> [reply] - Efek timbul
 • <code>{0}sepia</code> [reply] - Efek jadul
 • <code>{0}sketsa</code> [reply] - Efek pensil

<b>RESIZE</b>
 • <code>{0}resize</code> [width] [height] [reply] - Ubah ukuran
 • <code>{0}square</code> [reply] - Jadi kotak (1:1)
 • <code>{0}compress</code> [reply] - Kompres gambar

<b>CONVERT</b>
 • <code>{0}png</code> [reply] - Konversi ke PNG
 • <code>{0}jpg</code> [reply] - Konversi ke JPG
 • <code>{0}webp</code> [reply] - Konversi ke WEBP
 • <code>{0}ico</code> [reply] - Konversi ke ICO

<b>INFO</b>
 • <code>{0}imageinfo</code> [reply] - Info gambar
 • <code>{0}exif</code> [reply] - Lihat metadata EXIF</blockquote>
"""

@PY.UBOT("blur")
@PY.TOP_CMD
async def blur_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Memproses...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            img_blur = img.filter(ImageFilter.GaussianBlur(radius=5))
            output = "blur.jpg"
            img_blur.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("bright")
@PY.TOP_CMD
async def bright_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Memproses...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            enhancer = ImageEnhance.Brightness(img)
            img_bright = enhancer.enhance(1.5)
            output = "bright.jpg"
            img_bright.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("contrast")
@PY.TOP_CMD
async def contrast_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Memproses...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            enhancer = ImageEnhance.Contrast(img)
            img_contrast = enhancer.enhance(2.0)
            output = "contrast.jpg"
            img_contrast.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("sharpen")
@PY.TOP_CMD
async def sharpen_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Memproses...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            img_sharpen = img.filter(ImageFilter.SHARPEN)
            output = "sharpen.jpg"
            img_sharpen.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("sepia")
@PY.TOP_CMD
async def sepia_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Memproses...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Effect sepia
            width, height = img.size
            pixels = img.load()
            
            for py in range(height):
                for px in range(width):
                    r, g, b = img.getpixel((px, py))
                    tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                    tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                    tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                    
                    if tr > 255:
                        tr = 255
                    if tg > 255:
                        tg = 255
                    if tb > 255:
                        tb = 255
                    
                    pixels[px, py] = (tr, tg, tb)
            
            output = "sepia.jpg"
            img.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("resize")
@PY.TOP_CMD
async def resize_image(client, message):
    if len(message.command) < 3:
        return await message.reply("Format: <code>resize 500 500</code> [reply gambar]")
    
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    try:
        width = int(message.command[1])
        height = int(message.command[2])
    except:
        return await message.reply("Width & height harus angka!")
    
    msg = await message.reply("🔄 Meresize...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            img_resized = img.resize((width, height))
            output = "resized.jpg"
            img_resized.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("square")
@PY.TOP_CMD
async def square_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Membuat kotak...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            size = max(img.size)
            img_square = Image.new('RGB', (size, size), (255, 255, 255))
            img_square.paste(img, ((size - img.width)//2, (size - img.height)//2))
            output = "square.jpg"
            img_square.save(output)
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("imageinfo")
@PY.TOP_CMD
async def image_info(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            info = f"""
<b>🖼️ INFO GAMBAR</b>

📏 Size: {img.size[0]} x {img.size[1]} px
📊 Format: {img.format}
🎨 Mode: {img.mode}
📁 File: {os.path.basename(file)}
💾 Ukuran file: {os.path.getsize(file) / 1024:.1f} KB
"""
            await message.reply(info)
        
        os.remove(file)
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("png")
@PY.TOP_CMD
async def to_png(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Mengkonversi...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            output = "image.png"
            img.save(output, 'PNG')
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("jpg")
@PY.TOP_CMD
async def to_jpg(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("Reply ke gambar dulu!")
    
    msg = await message.reply("🔄 Mengkonversi...")
    file = await message.reply_to_message.download()
    
    try:
        with Image.open(file) as img:
            if img.mode in ('RGBA', 'P'):
                img = img.convert('RGB')
            output = "image.jpg"
            img.save(output, 'JPEG')
        
        await client.send_photo(message.chat.id, output, reply_to_message_id=message.id)
        os.remove(file)
        os.remove(output)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")
