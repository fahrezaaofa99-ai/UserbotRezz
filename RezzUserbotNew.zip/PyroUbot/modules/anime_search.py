from PyroUbot import *
import requests

__MODULE__ = "𝐀𝐧𝐢𝐦𝐞 𝐒𝐞𝐚𝐫𝐜𝐡"
__HELP__ = """
<blockquote><b>🎌 𝐀𝐧𝐢𝐦𝐞 𝐒𝐞𝐚𝐫𝐜𝐡</b>

 • <code>{0}anime &lt;judul></code> - Cari info anime
 • <code>{0}manga &lt;judul></code> - Cari info manga
 • <code>{0}character &lt;nama></code> - Cari karakter
 • <code>{0}animequote</code> - Quote anime random
 • <code>{0}animerand</code> - Anime random
 • <code>{0}topanime</code> - Top anime terbaik
 • <code>{0}ongoing</code> - Anime ongoing</blockquote>
"""

@PY.UBOT("anime")
@PY.TOP_CMD
async def anime_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .anime <judul>")
    msg = await message.reply("🔍 Searching...")
    try:
        r = requests.get(f"https://api.jikan.moe/v4/anime?q={args[1]}&limit=1")
        if r.status_code == 200:
            data = r.json()
            if data['data']:
                a = data['data'][0]
                text = f"""
╭──〔 🎌 INFO ANIME 〕
│
│ 📌 {a['title']}
│ 📅 {a.get('year', '?')}
│ ⭐ {a.get('score', '?')}/10
│ 📝 {a.get('synopsis', '')[:200]}...
│
╰── ✨ Anime Search ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Tidak ditemukan")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("manga")
@PY.TOP_CMD
async def manga_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .manga <judul>")
    msg = await message.reply("🔍 Searching...")
    try:
        r = requests.get(f"https://api.jikan.moe/v4/manga?q={args[1]}&limit=1")
        if r.status_code == 200:
            data = r.json()
            if data['data']:
                m = data['data'][0]
                text = f"""
╭──〔 📖 INFO MANGA 〕
│
│ 📌 {m['title']}
│ 📅 {m.get('published', {}).get('prop', {}).get('from', {}).get('year', '?')}
│ ⭐ {m.get('score', '?')}/10
│ 📝 {m.get('synopsis', '')[:200]}...
│
╰── ✨ Manga Search ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Tidak ditemukan")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("character")
@PY.TOP_CMD
async def character_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .character <nama>")
    msg = await message.reply("🔍 Searching...")
    try:
        r = requests.get(f"https://api.jikan.moe/v4/characters?q={args[1]}&limit=1")
        if r.status_code == 200:
            data = r.json()
            if data['data']:
                c = data['data'][0]
                text = f"""
╭──〔 👤 INFO KARAKTER 〕
│
│ 📌 {c['name']}
│ 🎭 {c.get('name_kanji', '?')}
│ 📝 {c.get('about', '')[:200]}...
│
╰── ✨ Character Search ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Tidak ditemukan")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("animequote")
@PY.TOP_CMD
async def anime_quote(client, message):
    try:
        r = requests.get("https://animechan.xyz/api/random")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"💬 **{data['quote']}**\n\n— {data['character']} ({data['anime']})")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("animerand")
@PY.TOP_CMD
async def anime_random(client, message):
    try:
        r = requests.get("https://api.jikan.moe/v4/random/anime")
        if r.status_code == 200:
            a = r.json()['data']
            await message.reply(f"🎲 **ANIME RANDOM:** {a['title']}\n⭐ Score: {a.get('score', '?')}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("topanime")
@PY.TOP_CMD
async def top_anime(client, message):
    msg = await message.reply("🔍 Mengambil top anime...")
    try:
        r = requests.get("https://api.jikan.moe/v4/top/anime?limit=10")
        if r.status_code == 200:
            text = "🏆 **TOP 10 ANIME TERBAIK**\n\n"
            for i, a in enumerate(r.json()['data'][:10], 1):
                text += f"{i}. {a['title']} - ⭐ {a['score']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("ongoing")
@PY.TOP_CMD
async def anime_ongoing(client, message):
    msg = await message.reply("🔍 Mencari anime ongoing...")
    try:
        r = requests.get("https://api.jikan.moe/v4/seasons/now?limit=10")
        if r.status_code == 200:
            text = "📺 **ANIME ONGOING**\n\n"
            for i, a in enumerate(r.json()['data'][:10], 1):
                text += f"{i}. {a['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
