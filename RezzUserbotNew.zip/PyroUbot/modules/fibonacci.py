from PyroUbot import *

__MODULE__ = "𝐅𝐢𝐛𝐨𝐧𝐚𝐜𝐜𝐢"
__HELP__ = """
<blockquote><b>🔢 𝐅𝐢𝐛𝐨𝐧𝐚𝐜𝐜𝐢</b>

 • <code>{0}fib &lt;n></code> - Deret Fibonacci ke-n</blockquote>
"""

@PY.UBOT("fib")
@PY.TOP_CMD
async def fibonacci(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .fib <n>")
    try:
        n = int(args[1])
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        await message.reply(f"🔢 Fibonacci ke-{n} = {a}")
    except:
        await message.reply("❌ Error")
