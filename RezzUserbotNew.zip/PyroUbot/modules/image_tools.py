from PyroUbot import *
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

__MODULE__ = "𝐈𝐦𝐚𝐠𝐞 𝐓𝐨𝐨𝐥𝐬"
__HELP__ = """
<blockquote><b>🖼️ 𝐈𝐦𝐚𝐠𝐞 𝐓𝐨𝐨𝐥𝐬</b>

 • <code>{0}resize &lt;w> &lt;h></code> - Resize
 • <code>{0}rotate &lt;derajat></code> - Rotate
 • <code>{0}flip</code> - Flip horizontal
 • <code>{0}blur</code> - Efek blur
 • <code>{0}grayscale</code> - Hitam putih
 • <code>{0}sepia</code> - Efek sepia
 • <code>{0}invert</code> - Warna invert
 • <code>{0}brightness &lt;1-2></code> - Kecerahan
 • <code>{0}contrast &lt;1-2></code> - Kontras
 • <code>{0}watermark &lt;teks></code> - Watermark
 • <code>{0}tojpg</code> - Convert ke JPG
 • <code>{0}topng</code> - Convert ke PNG
 • <code>{0}circle</code> - Gambar lingkaran</blockquote>
"""

if not os.path.exists("image_temp"):
    os.makedirs("image_temp")

def download_img(msg):
    if msg.reply_to_message and msg.reply_to_message.photo:
        return msg.reply_to_message.download()
    return None

@PY.UBOT("resize")
@PY.TOP_CMD
async def resize_img(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .resize <width> <height>")
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).resize((int(args[1]), int(args[2])))
    out = f"image_temp/resize_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("rotate")
@PY.TOP_CMD
async def rotate_img(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .rotate <derajat>")
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).rotate(int(args[1]), expand=True)
    out = f"image_temp/rotate_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("flip")
@PY.TOP_CMD
async def flip_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).transpose(Image.FLIP_LEFT_RIGHT)
    out = f"image_temp/flip_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("blur")
@PY.TOP_CMD
async def blur_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).filter(ImageFilter.BLUR)
    out = f"image_temp/blur_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("grayscale")
@PY.TOP_CMD
async def gray_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).convert('L')
    out = f"image_temp/gray_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("sepia")
@PY.TOP_CMD
async def sepia_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).convert('RGB')
    w, h = img.size
    pixels = img.load()
    for y in range(h):
        for x in range(w):
            r, g, b = img.getpixel((x, y))
            tr = min(255, int(0.393*r + 0.769*g + 0.189*b))
            tg = min(255, int(0.349*r + 0.686*g + 0.168*b))
            tb = min(255, int(0.272*r + 0.534*g + 0.131*b))
            pixels[x, y] = (tr, tg, tb)
    out = f"image_temp/sepia_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("invert")
@PY.TOP_CMD
async def invert_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).convert('RGB')
    img = Image.eval(img, lambda x: 255 - x)
    out = f"image_temp/invert_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("brightness")
@PY.TOP_CMD
async def bright_img(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .brightness <1-2>")
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = ImageEnhance.Brightness(Image.open(f)).enhance(float(args[1]))
    out = f"image_temp/bright_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("contrast")
@PY.TOP_CMD
async def contrast_img(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .contrast <1-2>")
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = ImageEnhance.Contrast(Image.open(f)).enhance(float(args[1]))
    out = f"image_temp/contrast_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("watermark")
@PY.TOP_CMD
async def watermark_img(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .watermark <teks>")
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).convert('RGBA')
    wm = Image.new('RGBA', img.size, (0,0,0,0))
    draw = ImageDraw.Draw(wm)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 30)
    except:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0,0), args[1], font=font)
    x = (img.size[0] - (bbox[2]-bbox[0])) // 2
    y = img.size[1] - 50
    draw.text((x, y), args[1], font=font, fill=(255,255,255,128))
    img = Image.alpha_composite(img, wm)
    out = f"image_temp/wm_{message.id}.png"
    img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("tojpg")
@PY.TOP_CMD
async def tojpg(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Converting...")
    img = Image.open(f).convert('RGB')
    out = f"image_temp/conv_{message.id}.jpg"
    img.save(out, 'JPEG')
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("topng")
@PY.TOP_CMD
async def topng(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Converting...")
    img = Image.open(f)
    out = f"image_temp/conv_{message.id}.png"
    img.save(out, 'PNG')
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()

@PY.UBOT("circle")
@PY.TOP_CMD
async def circle_img(client, message):
    f = download_img(message)
    if not f: return await message.reply("❌ Balas ke gambar!")
    msg = await message.reply("🔄 Processing...")
    img = Image.open(f).convert('RGBA').resize((500,500))
    mask = Image.new('L', (500,500), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0,0,500,500), fill=255)
    out_img = Image.new('RGBA', (500,500))
    out_img.paste(img, (0,0), mask)
    out = f"image_temp/circle_{message.id}.png"
    out_img.save(out)
    await message.reply_photo(out)
    os.remove(f); os.remove(out); await msg.delete()
