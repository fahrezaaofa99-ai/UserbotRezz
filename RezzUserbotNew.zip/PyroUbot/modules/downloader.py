from PyroUbot import *
import yt_dlp
import os

__MODULE__ = "DOWNLOADER"
__HELP__ = """
<b>📥 DOWNLOADER</b>

• <code>{0}ytmp3</code> [url] - Download audio YouTube
• <code>{0}ytmp4</code> [url] - Download video YouTube
• <code>{0}tiktok</code> [url] - Download TikTok
• <code>{0}ig</code> [url] - Download Instagram
• <code>{0}fb</code> [url] - Download Facebook
"""

@PY.UBOT("ytmp3")
@PY.TOP_CMD
async def yt_mp3(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>ytmp3 [url]</code>")
    
    url = message.command[1]
    msg = await message.reply("🔄 Mendownload audio...")
    
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
        }],
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info).replace('.webm', '.mp3')
            
        await message.reply_audio(filename, caption=f"🎵 {info['title']}")
        os.remove(filename)
        await msg.delete()
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")
