from PyroUbot import *
import requests

__MODULE__ = "𝐃𝐨𝐠𝐅𝐚𝐜𝐭𝐬"
__HELP__ = """
<blockquote><b>🐕 𝐃𝐨𝐠 𝐅𝐚𝐜𝐭𝐬</b>

 • <code>{0}dogfact</code> - Fakta anjing random</blockquote>
"""

@PY.UBOT("dogfact")
@PY.TOP_CMD
async def dog_facts(client, message):
    try:
        r = requests.get("https://dogapi.dog/api/v2/facts")
        if r.status_code == 200:
            await message.reply(f"🐕 **Dog Fact:**\n\n{r.json()['data'][0]['attributes']['body']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
