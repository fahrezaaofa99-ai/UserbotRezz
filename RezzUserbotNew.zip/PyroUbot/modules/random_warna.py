from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐖𝐚𝐫𝐧𝐚"
__HELP__ = """
<blockquote><b>🎨 𝐑𝐚𝐧𝐝𝐨𝐦 𝐖𝐚𝐫𝐧𝐚</b>

 • <code>{0}warna</code> - Random warna hex</blockquote>
"""

@PY.UBOT("warna")
@PY.TOP_CMD
async def random_color_hex(client, message):
    hex_color = "#" + ''.join([random.choice('0123456789ABCDEF') for _ in range(6)])
    await message.reply(f"🎨 **Random Color:** {hex_color}")
