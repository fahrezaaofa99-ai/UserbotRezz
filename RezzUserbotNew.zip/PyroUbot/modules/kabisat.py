from PyroUbot import *

__MODULE__ = "𝐊𝐚𝐛𝐢𝐬𝐚𝐭"
__HELP__ = """
<blockquote><b>📅 𝐂𝐞𝐤 𝐓𝐚𝐡𝐮𝐧 𝐊𝐚𝐛𝐢𝐬𝐚𝐭</b>

 • <code>{0}kabisat &lt;tahun></code> - Cek tahun kabisat</blockquote>
"""

@PY.UBOT("kabisat")
@PY.TOP_CMD
async def cek_kabisat(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .kabisat <tahun>")
    tahun = int(args[1])
    if (tahun % 400 == 0) or (tahun % 4 == 0 and tahun % 100 != 0):
        await message.reply(f"📅 {tahun} adalah **TAHUN KABISAT**")
    else:
        await message.reply(f"📅 {tahun} **BUKAN** tahun kabisat")
