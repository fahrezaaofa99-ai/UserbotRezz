from PyroUbot import *
import random

__MODULE__ = "𝐋𝐮𝐜𝐤𝐲"
__HELP__ = """
<blockquote><b>🍀 𝐋𝐮𝐜𝐤𝐲 𝐍𝐮𝐦𝐛𝐞𝐫</b>

 • <code>{0}lucky</code> - Angka keberuntungan</blockquote>
"""

@PY.UBOT("lucky")
@PY.TOP_CMD
async def lucky_number(client, message):
    angka = random.randint(1, 100)
    await message.reply(f"🍀 **Angka keberuntungan kamu:** {angka}")
