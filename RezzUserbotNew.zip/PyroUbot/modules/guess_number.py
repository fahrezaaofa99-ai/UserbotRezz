from PyroUbot import *
import random

__MODULE__ = "𝐆𝐮𝐞𝐬𝐬𝐍𝐮𝐦"
__HELP__ = """
<blockquote><b>🎲 𝐆𝐮𝐞𝐬𝐬 𝐍𝐮𝐦𝐛𝐞𝐫</b>

 • <code>{0}guess</code> - Mulai tebak angka</blockquote>
"""

GUESS_GAMES = {}

@PY.UBOT("guess")
@PY.TOP_CMD
async def guess_number(client, message):
    chat_id = message.chat.id
    if chat_id in GUESS_GAMES:
        return await message.reply("❌ Game sedang berjalan!")
    number = random.randint(1, 100)
    msg = await message.reply("🎲 **Tebak Angka 1-100!**\nReply angka (30 detik)")
    GUESS_GAMES[chat_id] = {"number": number, "msg_id": msg.id}
    await asyncio.sleep(30)
    if chat_id in GUESS_GAMES:
        del GUESS_GAMES[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {number}")

@PY.INLINE
async def check_guess(client, message):
    chat_id = message.chat.id
    if chat_id not in GUESS_GAMES:
        return
    if not message.text or not message.text.isdigit():
        return
    guess = int(message.text)
    game = GUESS_GAMES[chat_id]
    if guess == game["number"]:
        await message.reply(f"✅ **BENAR!** Angkanya {game['number']}")
        del GUESS_GAMES[chat_id]
    elif guess < game["number"]:
        await message.reply("📈 **Terlalu kecil!** Coba lagi")
    else:
        await message.reply("📉 **Terlalu besar!** Coba lagi")
