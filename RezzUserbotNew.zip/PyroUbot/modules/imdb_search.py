from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐌𝐃𝐛"
__HELP__ = """
<blockquote><b>🎬 𝐈𝐌𝐃𝐛 𝐌𝐨𝐯𝐢𝐞</b>

 • <code>{0}imdb &lt;judul></code> - Cari film di IMDb</blockquote>
"""

@PY.UBOT("imdb")
@PY.TOP_CMD
async def imdb_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .imdb <judul>")
    msg = await message.reply("🎬 Mencari...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?t={args[1]}&apikey=trilogy")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                await msg.edit(f"🎬 **{data['Title']}** ({data['Year']})\n⭐ {data['imdbRating']}/10\n🎭 {data['Genre']}\n📝 {data['Plot'][:200]}...")
            else:
                await msg.edit("❌ Tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
