from PyroUbot import *
import requests

__MODULE__ = "𝐏𝐚𝐧𝐝𝐚𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🐼 𝐏𝐚𝐧𝐝𝐚 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}panda</code> - Gambar panda random</blockquote>
"""

@PY.UBOT("panda")
@PY.TOP_CMD
async def panda_image(client, message):
    msg = await message.reply("🐼 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/panda")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
