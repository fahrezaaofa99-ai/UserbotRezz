from PyroUbot import *
import os
from PIL import Image, ImageDraw, ImageFont

__MODULE__ = "𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐌𝐚𝐤𝐞𝐫"
__HELP__ = """
<blockquote><b>🎨 𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐌𝐚𝐤𝐞𝐫</b>

 • <code>{0}stext &lt;teks></code> - Stiker teks
 • <code>{0}srainbow &lt;teks></code> - Teks pelangi
 • <code>{0}s3d &lt;teks></code> - Teks 3D
 • <code>{0}sblur &lt;reply stiker></code> - Efek blur
 • <code>{0}sblack &lt;reply stiker></code> - Hitam putih
 • <code>{0}sround &lt;reply stiker></code> - Stiker bulat
 • <code>{0}skang &lt;reply stiker></code> - Ambil stiker</blockquote>
"""

if not os.path.exists("sticker_temp"):
    os.makedirs("sticker_temp")

@PY.UBOT("stext")
@PY.TOP_CMD
async def stext(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .stext <teks>")
    msg = await message.reply("🔄 Making...")
    img = Image.new('RGBA', (512,512), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
    except:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0,0), args[1], font=font)
    x = (512 - (bbox[2]-bbox[0])) // 2
    y = (512 - (bbox[3]-bbox[1])) // 2
    draw.text((x, y), args[1], font=font, fill=(255,0,0))
    path = f"sticker_temp/sticker_{message.id}.png"
    img.save(path)
    await message.reply_sticker(path)
    os.remove(path)
    await msg.delete()

@PY.UBOT("srainbow")
@PY.TOP_CMD
async def srainbow(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .srainbow <teks>")
    msg = await message.reply("🔄 Making...")
    img = Image.new('RGBA', (512,512), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 60)
    except:
        font = ImageFont.load_default()
    rainbow = [(255,0,0),(255,127,0),(255,255,0),(0,255,0),(0,0,255),(75,0,130),(148,0,211)]
    x = 50
    y = 256
    for i, char in enumerate(args[1]):
        draw.text((x, y), char, font=font, fill=rainbow[i % len(rainbow)])
        bbox = draw.textbbox((0,0), char, font=font)
        x += (bbox[2]-bbox[0]) + 5
    path = f"sticker_temp/rainbow_{message.id}.png"
    img.save(path)
    await message.reply_sticker(path)
    os.remove(path)
    await msg.delete()

@PY.UBOT("s3d")
@PY.TOP_CMD
async def s3d(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .s3d <teks>")
    msg = await message.reply("🔄 Making...")
    img = Image.new('RGB', (512,512), (255,255,255))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 70)
    except:
        font = ImageFont.load_default()
    bbox = draw.textbbox((0,0), args[1], font=font)
    x = (512 - (bbox[2]-bbox[0])) // 2
    y = (512 - (bbox[3]-bbox[1])) // 2
    for offset in range(5,0,-1):
        draw.text((x+offset, y+offset), args[1], font=font, fill=(100,100,100))
    draw.text((x, y), args[1], font=font, fill=(255,0,0))
    path = f"sticker_temp/3d_{message.id}.png"
    img.save(path)
    await message.reply_sticker(path)
    os.remove(path)
    await msg.delete()

@PY.UBOT("sblur")
@PY.TOP_CMD
async def sblur(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Balas ke stiker!")
    msg = await message.reply("🔄 Processing...")
    file = await message.reply_to_message.download()
    img = Image.open(file).resize((512,512))
    img = img.filter(ImageFilter.BLUR)
    path = f"sticker_temp/blur_{message.id}.png"
    img.save(path)
    await message.reply_sticker(path)
    os.remove(file); os.remove(path); await msg.delete()

@PY.UBOT("sblack")
@PY.TOP_CMD
async def sblack(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Balas ke stiker!")
    msg = await message.reply("🔄 Processing...")
    file = await message.reply_to_message.download()
    img = Image.open(file).convert('L').resize((512,512))
    path = f"sticker_temp/black_{message.id}.png"
    img.save(path)
    await message.reply_sticker(path)
    os.remove(file); os.remove(path); await msg.delete()

@PY.UBOT("sround")
@PY.TOP_CMD
async def sround(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Balas ke stiker!")
    msg = await message.reply("🔄 Processing...")
    file = await message.reply_to_message.download()
    img = Image.open(file).convert('RGBA').resize((512,512))
    mask = Image.new('L', (512,512), 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0,0,512,512), fill=255)
    out = Image.new('RGBA', (512,512))
    out.paste(img, (0,0), mask)
    path = f"sticker_temp/round_{message.id}.png"
    out.save(path)
    await message.reply_sticker(path)
    os.remove(file); os.remove(path); await msg.delete()

@PY.UBOT("skang")
@PY.TOP_CMD
async def skang(client, message):
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Balas ke stiker!")
    msg = await message.reply("🔄 Saving...")
    file = await message.reply_to_message.download()
    await client.send_document("me", file)
    os.remove(file)
    await msg.edit("✅ Stiker tersimpan di Saved Messages!")
