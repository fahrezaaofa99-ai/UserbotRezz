from PyroUbot import *

__MODULE__ = "𝐃𝐞𝐥𝐞𝐭𝐞"
__HELP__ = """
<blockquote><b>🗑️ 𝐃𝐞𝐥𝐞𝐭𝐞</b>

 • <code>{0}del</code> - Hapus pesan yang di-reply</blockquote>
"""

@PY.UBOT("del")
@PY.TOP_CMD
async def delete_msg(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    if not message.reply_to_message:
        return await message.reply("❌ Balas ke pesan!")
    await message.reply_to_message.delete()
    await message.delete()
