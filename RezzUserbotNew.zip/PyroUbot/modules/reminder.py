from PyroUbot import *
import asyncio

__MODULE__ = "𝐑𝐞𝐦𝐢𝐧𝐝𝐞𝐫"
__HELP__ = """
<blockquote><b>🔔 𝐑𝐞𝐦𝐢𝐧𝐝𝐞𝐫</b>

 • <code>{0}remind &lt;menit> &lt;pesan></code> - Buat pengingat</blockquote>
"""

@PY.UBOT("remind")
@PY.TOP_CMD
async def reminder_set(client, message):
    args = message.text.split(maxsplit=2)
    if len(args) < 3:
        return await message.reply("❌ .remind <menit> <pesan>")
    try:
        menit = int(args[1])
        pesan = args[2]
        await message.reply(f"🔔 Pengingat akan berbunyi dalam {menit} menit")
        await asyncio.sleep(menit * 60)
        await message.reply(f"🔔 **REMINDER!**\n\n{pesan}")
    except:
        await message.reply("❌ Error")
