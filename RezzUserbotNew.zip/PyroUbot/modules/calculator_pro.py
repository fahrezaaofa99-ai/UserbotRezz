from PyroUbot import *
import math

__MODULE__ = "𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫 𝐏𝐫𝐨"
__HELP__ = """
<blockquote><b>🧮 𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫 𝐏𝐫𝐨</b>

 • <code>{0}calc &lt;a> &lt;+-> &lt;b></code> - Kalkulator
 • <code>{0}sqrt &lt;angka></code> - Akar kuadrat
 • <code>{0}kuadrat &lt;angka></code> - Kuadrat
 • <code>{0}pangkat &lt;a> &lt;b></code> - Pangkat
 • <code>{0}faktorial &lt;angka></code> - Faktorial
 • <code>{0}persen &lt;a> &lt;b></code> - Persentase
 • <code>{0}random &lt;min> &lt;max></code> - Random
 • <code>{0}flipcoin</code> - Lempar koin
 • <code>{0}dadu</code> - Lempar dadu
 • <code>{0}celcius_f &lt;c></code> - Celcius ke F
 • <code>{0}f_celcius &lt;f></code> - F ke Celcius</blockquote>
"""

@PY.UBOT("calc")
@PY.TOP_CMD
async def calc(client, message):
    args = message.text.split()
    if len(args) < 4:
        return await message.reply("❌ .calc 10 + 5")
    try:
        a, op, b = float(args[1]), args[2], float(args[3])
        if op == '+': hasil = a + b
        elif op == '-': hasil = a - b
        elif op == '*': hasil = a * b
        elif op == '/': hasil = a / b if b != 0 else None
        elif op == '^': hasil = a ** b
        else: return await message.reply("❌ Operator salah")
        await message.reply(f"📝 {a} {op} {b} = {hasil}")
    except:
        await message.reply("❌ Input salah")

@PY.UBOT("sqrt")
@PY.TOP_CMD
async def akar(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .sqrt <angka>")
    try:
        hasil = math.sqrt(float(args[1]))
        await message.reply(f"√{args[1]} = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("kuadrat")
@PY.TOP_CMD
async def kuadrat(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .kuadrat <angka>")
    try:
        hasil = float(args[1]) ** 2
        await message.reply(f"{args[1]}² = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("pangkat")
@PY.TOP_CMD
async def pangkat(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .pangkat <angka> <pangkat>")
    try:
        hasil = float(args[1]) ** float(args[2])
        await message.reply(f"{args[1]}^{args[2]} = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("faktorial")
@PY.TOP_CMD
async def faktorial(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .faktorial <angka>")
    try:
        hasil = math.factorial(int(args[1]))
        await message.reply(f"{args[1]}! = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("persen")
@PY.TOP_CMD
async def persen(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .persen <angka> <persen>")
    try:
        hasil = (float(args[2]) / 100) * float(args[1])
        await message.reply(f"{args[2]}% dari {args[1]} = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("random")
@PY.TOP_CMD
async def random_angka(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .random <min> <max>")
    try:
        hasil = random.randint(int(args[1]), int(args[2]))
        await message.reply(f"🎲 Random: {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("flipcoin")
@PY.TOP_CMD
async def flipcoin(client, message):
    hasil = random.choice(["HEADS 🪙", "TAILS 🪙"])
    await message.reply(f"🪙 {hasil}")

@PY.UBOT("dadu")
@PY.TOP_CMD
async def dadu(client, message):
    hasil = random.randint(1, 6)
    dadu_gambar = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
    await message.reply(f"🎲 {hasil} {dadu_gambar[hasil-1]}")

@PY.UBOT("celcius_f")
@PY.TOP_CMD
async def celcius_f(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .celcius_f <celcius>")
    try:
        f = (float(args[1]) * 9/5) + 32
        await message.reply(f"{args[1]}°C = {f}°F")
    except:
        await message.reply("❌ Error")

@PY.UBOT("f_celcius")
@PY.TOP_CMD
async def f_celcius(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .f_celcius <fahrenheit>")
    try:
        c = (float(args[1]) - 32) * 5/9
        await message.reply(f"{args[1]}°F = {c}°C")
    except:
        await message.reply("❌ Error")
