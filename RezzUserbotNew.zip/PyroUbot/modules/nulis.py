from PyroUbot import *
from PIL import Image, ImageDraw, ImageFont
import os

__MODULE__ = "𝐍𝐮𝐥𝐢𝐬"
__HELP__ = """
<blockquote><b>✍️ 𝐍𝐮𝐥𝐢𝐬</b>

 • <code>{0}nulis &lt;teks></code> - Tulis di kertas</blockquote>
"""

@PY.UBOT("nulis")
@PY.TOP_CMD
async def nulis(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .nulis <teks>")
    msg = await message.reply("✍️ Menulis...")
    img = Image.new('RGB', (800, 600), color='white')
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
    except:
        font = ImageFont.load_default()
    y = 50
    for line in args[1].split('\n'):
        draw.text((50, y), line, font=font, fill='black')
        y += 30
    path = f"nulis_{message.id}.png"
    img.save(path)
    await message.reply_photo(path)
    os.remove(path)
    await msg.delete()
