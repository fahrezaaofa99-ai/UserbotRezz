from PyroUbot import *
from datetime import datetime

__MODULE__ = "𝐀𝐠𝐞𝐂𝐚𝐥𝐜"
__HELP__ = """
<blockquote><b>📅 𝐀𝐠𝐞 𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫</b>

 • <code>{0}age &lt;DD-MM-YYYY></code> - Hitung umur</blockquote>
"""

@PY.UBOT("age")
@PY.TOP_CMD
async def age_calc(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .age DD-MM-YYYY")
    try:
        lahir = datetime.strptime(args[1], "%d-%m-%Y")
        today = datetime.now()
        umur = today.year - lahir.year - ((today.month, today.day) < (lahir.month, lahir.day))
        await message.reply(f"📅 **Umur:** {umur} tahun")
    except:
        await message.reply("❌ Format salah! Contoh: 15-08-2000")
