from PyroUbot import *
from datetime import datetime

__MODULE__ = "𝐒𝐞𝐥𝐢𝐬𝐢𝐡𝐓𝐠𝐥"
__HELP__ = """
<blockquote><b>📅 𝐒𝐞𝐥𝐢𝐬𝐢𝐡 𝐓𝐚𝐧𝐠𝐠𝐚𝐥</b>

 • <code>{0}selisih &lt;tgl1> &lt;tgl2></code> - Hitung selisih (DD-MM-YYYY)</blockquote>
"""

@PY.UBOT("selisih")
@PY.TOP_CMD
async def selisih_tanggal(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .selisih <DD-MM-YYYY> <DD-MM-YYYY>")
    try:
        tgl1 = datetime.strptime(args[1], "%d-%m-%Y")
        tgl2 = datetime.strptime(args[2], "%d-%m-%Y")
        selisih = abs((tgl2 - tgl1).days)
        await message.reply(f"📅 Selisih: **{selisih} hari**")
    except:
        await message.reply("❌ Format salah! Contoh: 01-01-2024")
