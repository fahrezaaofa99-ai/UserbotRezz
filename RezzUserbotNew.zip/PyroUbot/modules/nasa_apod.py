from PyroUbot import *
import requests

__MODULE__ = "𝐍𝐀𝐒𝐀"
__HELP__ = """
<blockquote><b>🚀 𝐍𝐀𝐒𝐀 𝐀𝐏𝐎𝐃</b>

 • <code>{0}nasa</code> - Astronomy Picture of the Day</blockquote>
"""

@PY.UBOT("nasa")
@PY.TOP_CMD
async def nasa_apod(client, message):
    msg = await message.reply("🚀 Mengambil gambar NASA...")
    try:
        r = requests.get("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY")
        if r.status_code == 200:
            data = r.json()
            title = data.get('title', 'NASA APOD')
            explanation = data.get('explanation', '')[:300]
            url = data.get('url', '')
            await message.reply_photo(url, caption=f"🚀 **{title}**\n\n{explanation}...")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
