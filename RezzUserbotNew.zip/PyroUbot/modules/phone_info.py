from PyroUbot import *
import phonenumbers
from phonenumbers import carrier, geocoder

__MODULE__ = "𝐏𝐡𝐨𝐧𝐞𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>📞 𝐏𝐡𝐨𝐧𝐞 𝐈𝐧𝐟𝐨</b>

 • <code>{0}phone &lt;nomor></code> - Info nomor telepon</blockquote>
"""

@PY.UBOT("phone")
@PY.TOP_CMD
async def phone_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .phone <nomor>")
    msg = await message.reply("📞 Mencari...")
    try:
        num = phonenumbers.parse(args[1])
        if phonenumbers.is_valid_number(num):
            country = geocoder.description_for_number(num, 'id')
            operator = carrier.name_for_number(num, 'id')
            await msg.edit(f"📞 **INFO NOMOR**\n\n📍 Negara: {country}\n📡 Operator: {operator}")
        else:
            await msg.edit("❌ Nomor tidak valid")
    except:
        await msg.edit("❌ Error")
