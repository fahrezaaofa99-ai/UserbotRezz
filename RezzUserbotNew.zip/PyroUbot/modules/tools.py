# Nama file: /root/RezzUserbot/PyroUbot/modules/tools.py
# FULL VERSION - LENGKAP DENGAN SEMUA FITUR

from PyroUbot import *
import requests
import json
import hashlib
import base64
import socket
import whois
from datetime import datetime
import random
import string
import subprocess
import platform
import time
import os
import sys

__MODULE__ = "ᴛᴏᴏʟs"
__HELP__ = """
<blockquote><b>🔧 TOOLS COLLECTION</b>

<b>🌐 NETWORK TOOLS</b>
 • <code>{0}ipinfo</code> [ip_address] - Cek informasi IP
   Contoh: <code>{0}ipinfo 8.8.8.8</code>

 • <code>{0}dns</code> [domain] - Cek DNS record
   Contoh: <code>{0}dns google.com</code>

 • <code>{0}portscan</code> [ip/host] - Scan port umum
   Contoh: <code>{0}portscan 8.8.8.8</code>

 • <code>{0}ping2</code> [host] - Ping ke server (versi 2)
   Contoh: <code>{0}ping2 google.com</code>

 • <code>{0}traceroute</code> [host] - Lacak rute jaringan
   Contoh: <code>{0}traceroute google.com</code>

 • <code>{0}whois</code> [domain] - Cek whois domain
   Contoh: <code>{0}whois google.com</code>

<b>🔐 ENCRYPTION</b>
 • <code>{0}md5</code> [teks] - Hash MD5
 • <code>{0}sha1</code> [teks] - Hash SHA1
 • <code>{0}sha256</code> [teks] - Hash SHA256
 • <code>{0}sha512</code> [teks] - Hash SHA512
 • <code>{0}base64</code> [encode/decode] [teks] - Base64
 • <code>{0}rot13</code> [teks] - Enkripsi ROT13
 • <code>{0}atbash</code> [teks] - Enkripsi Atbash
 • <code>{0}morse</code> [encode/decode] [teks] - Morse code
 • <code>{0}binary</code> [encode/decode] [teks] - Binary
 • <code>{0}hex</code> [encode/decode] [teks] - Hexadecimal

<b>📁 FILE INFO</b>
 • <code>{0}listext</code> - Daftar ekstensi file populer
 • <code>{0}mime</code> [ekstensi] - Cek MIME type
   Contoh: <code>{0}mime .pdf</code>
 • <code>{0}magic</code> [ekstensi] - Cek magic number file
 • <code>{0}size</code> [ukuran] [dari/ke] - Konversi ukuran file
   Contoh: <code>{0}size 1 GB MB</code>

<b>🧮 CALCULATOR</b>
 • <code>{0}calc</code> [rumus] - Kalkulator sederhana
   Contoh: <code>{0}calc 2+2*5</code>
 • <code>{0}math</code> [operasi] [angka1] [angka2] - Operasi matematika
   Contoh: <code>{0}math tambah 10 5</code>
 • <code>{0}konversi</code> [nilai] [dari] [ke] - Konversi satuan
   Support: cm, m, km, inch, foot, yard, mile, gram, kg, ton, liter, ml

<b>📊 TEXT TOOLS</b>
 • <code>{0}reverse</code> [teks] - Balikkan teks
 • <code>{0}count</code> [teks] - Hitung karakter & kata
 • <code>{0}upper</code> [teks] - Ubah ke huruf besar
 • <code>{0}lower</code> [teks] - Ubah ke huruf kecil
 • <code>{0}capitalize</code> [teks] - Kapitalisasi tiap kata
 • <code>{0}swapcase</code> [teks] - Balik huruf besar/kecil
 • <code>{0}title</code> [teks] - Format judul
 • <code>{0}strip</code> [teks] - Hapus spasi berlebih

<b>⏰ TIME TOOLS</b>
 • <code>{0}timestamp</code> - Dapatkan timestamp sekarang
 • <code>{0}epoch</code> [timestamp] - Konversi epoch ke tanggal
 • <code>{0}timezone</code> [kota] - Waktu di berbagai kota
   Contoh: <code>{0}timezone jakarta</code>
 • <code>{0}countdown</code> [tanggal] - Hitung mundur
   Contoh: <code>{0}countdown 2025-01-01</code>

<b>🔢 NUMBER TOOLS</b>
 • <code>{0}random</code> [min] [max] - Generate angka random
 • <code>{0}prime</code> [angka] - Cek bilangan prima
 • <code>{0}fibonacci</code> [n] - Deret Fibonacci ke-n
 • <code>{0}faktorial</code> [angka] - Hitung faktorial
 • <code>{0}biner</code> [angka] - Konversi ke biner
 • <code>{0}hexa</code> [angka] - Konversi ke heksadesimal
 • <code>{0}oktal</code> [angka] - Konversi ke oktal
 • <code>{0}romawi</code> [angka] - Konversi ke angka romawi

<b>🌍 WEB TOOLS</b>
 • <code>{0}short</code> [url] - Short link (tinyurl)
 • <code>{0}source</code> [url] - Lihat source code website
 • <code>{0}headers</code> [url] - Lihat HTTP headers
 • <code>{0}status</code> [url] - Cek status website
 • <code>{0}screenshot</code> [url] - Screenshot website

<b>📱 GENERATOR</b>
 • <code>{0}pass</code> [panjang] - Generate random password
 • <code>{0}uuid</code> - Generate UUID random
 • <code>{0}hash</code> [teks] - Generate hash (all in one)
 • <code>{0}token</code> [panjang] - Generate token random

<b>🔍 VALIDATOR</b>
 • <code>{0}email</code> [email] - Validasi email
 • <code>{0}url</code> [url] - Validasi URL
 • <code>{0}ip</code> [ip] - Validasi IP address
 • <code>{0}phone</code> [nomor] - Validasi nomor HP</blockquote>
"""

# ==================== HELPER FUNCTIONS ====================

def validate_ip(ip):
    """Validasi IP address"""
    try:
        socket.inet_aton(ip)
        return True
    except socket.error:
        return False

def validate_email(email):
    """Validasi email sederhana"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_url(url):
    """Validasi URL"""
    import re
    pattern = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+'
    return re.match(pattern, url) is not None

# ==================== NETWORK TOOLS ====================

@PY.UBOT("ipinfo")
@PY.TOP_CMD
async def ip_info(client, message):
    """Cek informasi IP address"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>ipinfo [ip_address]</code>")
    
    ip = message.command[1]
    
    if not validate_ip(ip):
        return await message.reply("❌ Format IP tidak valid!")
    
    msg = await message.reply(f"🔍 Mencari info IP {ip}...")
    
    try:
        # Cek pake ipapi.co
        response = requests.get(f"https://ipapi.co/{ip}/json/", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get('error'):
                # Fallback ke ip-api.com
                response = requests.get(f"http://ip-api.com/json/{ip}", timeout=10)
                data = response.json()
                
                if data.get('status') == 'fail':
                    return await msg.edit(f"❌ IP tidak valid: {ip}")
                
                text = f"<b>🌐 IP INFORMATION</b>\n\n"
                text += f"📍 <b>IP:</b> {data.get('query')}\n"
                text += f"🏙️ <b>Kota:</b> {data.get('city', 'N/A')}\n"
                text += f"🗺️ <b>Region:</b> {data.get('regionName', 'N/A')}\n"
                text += f"🇮🇩 <b>Negara:</b> {data.get('country', 'N/A')}\n"
                text += f"📮 <b>Kode Pos:</b> {data.get('zip', 'N/A')}\n"
                text += f"📡 <b>ISP:</b> {data.get('isp', 'N/A')}\n"
                text += f"🌎 <b>Lat/Lon:</b> {data.get('lat', 'N/A')}, {data.get('lon', 'N/A')}"
                
                await msg.edit(text)
            else:
                text = f"<b>🌐 IP INFORMATION</b>\n\n"
                text += f"📍 <b>IP:</b> {data.get('ip')}\n"
                text += f"🏙️ <b>Kota:</b> {data.get('city', 'N/A')}\n"
                text += f"🗺️ <b>Region:</b> {data.get('region', 'N/A')}\n"
                text += f"🇮🇩 <b>Negara:</b> {data.get('country_name', 'N/A')}\n"
                text += f"📮 <b>Kode Pos:</b> {data.get('postal', 'N/A')}\n"
                text += f"📡 <b>ISP:</b> {data.get('org', 'N/A')}\n"
                text += f"🌎 <b>Lat/Lon:</b> {data.get('latitude', 'N/A')}, {data.get('longitude', 'N/A')}\n"
                text += f"📱 <b>Mobile:</b> {'Ya' if data.get('mobile') else 'Tidak'}\n"
                text += f"🏢 <b>Hosting:</b> {'Ya' if data.get('hosting') else 'Tidak'}"
                
                await msg.edit(text)
        else:
            await msg.edit("❌ Gagal mengambil data IP")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("dns")
@PY.TOP_CMD
async def dns_lookup(client, message):
    """Cek DNS record domain"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>dns [domain]</code>")
    
    domain = message.command[1]
    msg = await message.reply(f"🔍 Mencari DNS record untuk {domain}...")
    
    try:
        # A record (IPv4)
        ipv4 = socket.gethostbyname(domain)
        
        text = f"<b>📋 DNS RECORD: {domain}</b>\n\n"
        text += f"📍 <b>A (IPv4):</b> {ipv4}\n"
        
        # Coba cek AAAA (IPv6)
        try:
            ipv6 = socket.getaddrinfo(domain, None, socket.AF_INET6)[0][4][0]
            text += f"📍 <b>AAAA (IPv6):</b> {ipv6}\n"
        except:
            text += f"📍 <b>AAAA (IPv6):</b> Tidak tersedia\n"
        
        await msg.edit(text)
        
    except socket.gaierror:
        await msg.edit(f"❌ Domain {domain} tidak ditemukan")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("portscan")
@PY.TOP_CMD
async def port_scan(client, message):
    """Scan port umum pada host"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>portscan [ip/host]</code>")
    
    host = message.command[1]
    msg = await message.reply(f"🔍 Scanning port umum di {host}...\nIni bisa makan waktu 10-20 detik")
    
    common_ports = {
        20: "FTP-DATA", 21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP",
        53: "DNS", 80: "HTTP", 110: "POP3", 111: "RPC", 135: "RPC",
        139: "NetBIOS", 143: "IMAP", 443: "HTTPS", 445: "SMB", 993: "IMAPS",
        995: "POP3S", 1723: "PPTP", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
        5900: "VNC", 6379: "Redis", 8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB"
    }
    
    try:
        # Resolve host ke IP
        ip = socket.gethostbyname(host)
        text = f"<b>🔌 PORT SCAN: {host} ({ip})</b>\n\n"
        text += f"⏱️ Timeout: 2 detik per port\n"
        text += f"📊 Scanning {len(common_ports)} port umum...\n\n"
        
        open_ports = []
        
        for port, service in common_ports.items():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((ip, port))
                if result == 0:
                    open_ports.append(f"   • {port} - {service} (OPEN)")
                sock.close()
            except:
                pass
        
        if open_ports:
            text += "<b>✅ PORT TERBUKA:</b>\n" + "\n".join(open_ports)
        else:
            text += "❌ Tidak ada port umum yang terbuka"
        
        await msg.edit(text)
        
    except socket.gaierror:
        await msg.edit(f"❌ Host {host} tidak ditemukan")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("ping2")
@PY.TOP_CMD
async def ping_version2(client, message):
    """Ping ke host (versi 2)"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>ping2 [host]</code>")
    
    host = message.command[1]
    msg = await message.reply(f"🏓 Pinging {host}...")
    
    try:
        # Resolve host
        ip = socket.gethostbyname(host)
        
        # Parameter ping
        param = '-n' if platform.system().lower() == 'windows' else '-c'
        count = '4'
        
        # Eksekusi ping
        start_time = time.time()
        result = subprocess.run(
            ['ping', param, count, host],
            capture_output=True,
            text=True,
            timeout=10
        )
        end_time = time.time()
        
        if result.returncode == 0:
            # Parse hasil ping
            output = result.stdout
            
            # Cari packet loss
            loss = "0%"
            for line in output.split('\n'):
                if 'loss' in line.lower() or 'hilang' in line.lower():
                    parts = line.split(',')
                    for part in parts:
                        if '%' in part:
                            loss = part.strip()
                            break
                    break
            
            # Cari rata-rata waktu
            avg_time = "N/A"
            for line in output.split('\n'):
                if 'avg' in line.lower() or 'rata-rata' in line.lower() or 'average' in line.lower():
                    parts = line.split('=')
                    if len(parts) > 1:
                        avg_time = parts[1].strip().split()[0]
                    break
            
            text = f"<b>🏓 PING RESULT: {host}</b>\n\n"
            text += f"📍 <b>IP:</b> {ip}\n"
            text += f"⏱️ <b>Waktu total:</b> {(end_time - start_time)*1000:.2f} ms\n"
            text += f"📊 <b>Packet loss:</b> {loss}\n"
            text += f"📈 <b>Rata-rata:</b> {avg_time} ms\n\n"
            text += f"<code>{output[:500]}</code>"
            
            await msg.edit(text)
        else:
            await msg.edit(f"❌ Host {host} tidak merespon")
            
    except socket.gaierror:
        await msg.edit(f"❌ Host {host} tidak ditemukan")
    except subprocess.TimeoutExpired:
        await msg.edit(f"❌ Timeout: {host} lambat merespon")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("traceroute")
@PY.TOP_CMD
async def trace_route(client, message):
    """Lacak rute jaringan ke host"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>traceroute [host]</code>")
    
    host = message.command[1]
    msg = await message.reply(f"🔄 Tracing route to {host}...\n\nIni bisa makan waktu 30-60 detik")
    
    try:
        # Parameter traceroute
        if platform.system().lower() == 'windows':
            cmd = ['tracert', '-h', '15', host]  # Maks 15 hops
        else:
            cmd = ['traceroute', '-m', '15', host]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=45
        )
        
        if result.returncode == 0:
            output = result.stdout
            text = f"<b>🔄 TRACEROUTE: {host}</b>\n\n"
            
            if len(output) > 1000:
                text += f"<code>{output[:1000]}</code>"
                text += "\n\n<i>...output terpotong (terlalu panjang)</i>"
            else:
                text += f"<code>{output}</code>"
            
            await msg.edit(text)
        else:
            await msg.edit(f"❌ Gagal traceroute ke {host}")
            
    except subprocess.TimeoutExpired:
        await msg.edit("❌ Timeout: Traceroute terlalu lama")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("whois")
@PY.TOP_CMD
async def whois_domain(client, message):
    """Cek whois domain"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>whois [domain]</code>")
    
    domain = message.command[1]
    msg = await message.reply(f"🔍 Mencari whois untuk {domain}...")
    
    try:
        # Pake whois api
        response = requests.get(f"https://api.domainsdb.info/v1/domains/search?domain={domain}", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if data.get('domains'):
                domain_data = data['domains'][0]
                
                text = f"<b>📋 WHOIS: {domain}</b>\n\n"
                text += f"🌐 <b>Domain:</b> {domain_data.get('domain', 'N/A')}\n"
                text += f"🏢 <b>Registrar:</b> {domain_data.get('registrar', 'N/A')}\n"
                text += f"📅 <b>Create Date:</b> {domain_data.get('create_date', 'N/A')}\n"
                text += f"📅 <b>Update Date:</b> {domain_data.get('update_date', 'N/A')}\n"
                text += f"📅 <b>Expiry Date:</b> {domain_data.get('expiry_date', 'N/A')}\n"
                
                await msg.edit(text)
            else:
                await msg.edit(f"❌ Domain {domain} tidak ditemukan")
        else:
            await msg.edit("❌ Gagal mengambil data whois")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== ENCRYPTION TOOLS ====================

@PY.UBOT("md5")
@PY.TOP_CMD
async def hash_md5(client, message):
    """Generate MD5 hash"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>md5 [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    hash_result = hashlib.md5(text.encode()).hexdigest()
    
    await message.reply(
        f"<b>🔐 MD5 HASH</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔑 <b>Hash:</b> <code>{hash_result}</code>\n"
        f"📊 <b>Panjang:</b> {len(hash_result)} karakter"
    )

@PY.UBOT("sha1")
@PY.TOP_CMD
async def hash_sha1(client, message):
    """Generate SHA1 hash"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>sha1 [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    hash_result = hashlib.sha1(text.encode()).hexdigest()
    
    await message.reply(
        f"<b>🔐 SHA1 HASH</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔑 <b>Hash:</b> <code>{hash_result}</code>\n"
        f"📊 <b>Panjang:</b> {len(hash_result)} karakter"
    )

@PY.UBOT("sha256")
@PY.TOP_CMD
async def hash_sha256(client, message):
    """Generate SHA256 hash"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>sha256 [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    hash_result = hashlib.sha256(text.encode()).hexdigest()
    
    await message.reply(
        f"<b>🔐 SHA256 HASH</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔑 <b>Hash:</b> <code>{hash_result}</code>\n"
        f"📊 <b>Panjang:</b> {len(hash_result)} karakter"
    )

@PY.UBOT("sha512")
@PY.TOP_CMD
async def hash_sha512(client, message):
    """Generate SHA512 hash"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>sha512 [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    hash_result = hashlib.sha512(text.encode()).hexdigest()
    
    await message.reply(
        f"<b>🔐 SHA512 HASH</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔑 <b>Hash:</b> <code>{hash_result[:100]}...</code>\n"
        f"📊 <b>Panjang:</b> {len(hash_result)} karakter"
    )

@PY.UBOT("base64")
@PY.TOP_CMD
async def base64_tool(client, message):
    """Base64 encode/decode"""
    if len(message.command) < 3:
        return await message.reply("Format: <code>base64 [encode/decode] [teks]</code>")
    
    mode = message.command[1].lower()
    text = ' '.join(message.command[2:])
    
    try:
        if mode == 'encode':
            encoded = base64.b64encode(text.encode()).decode()
            await message.reply(
                f"<b>🔐 BASE64 ENCODE</b>\n\n"
                f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Hasil:</b> <code>{encoded[:100]}{'...' if len(encoded) > 100 else ''}</code>"
            )
        elif mode == 'decode':
            decoded = base64.b64decode(text.encode()).decode()
            await message.reply(
                f"<b>🔓 BASE64 DECODE</b>\n\n"
                f"📝 <b>Base64:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Hasil:</b> {decoded[:100]}{'...' if len(decoded) > 100 else ''}"
            )
        else:
            await message.reply("Mode harus 'encode' atau 'decode'")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("rot13")
@PY.TOP_CMD
async def cipher_rot13(client, message):
    """Enkripsi ROT13"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>rot13 [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    
    # ROT13 implementation
    result = ""
    for char in text:
        if 'a' <= char <= 'z':
            result += chr((ord(char) - ord('a') + 13) % 26 + ord('a'))
        elif 'A' <= char <= 'Z':
            result += chr((ord(char) - ord('A') + 13) % 26 + ord('A'))
        else:
            result += char
    
    await message.reply(
        f"<b>🔄 ROT13 CIPHER</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔐 <b>Hasil:</b> {result[:50]}{'...' if len(result) > 50 else ''}"
    )

@PY.UBOT("atbash")
@PY.TOP_CMD
async def cipher_atbash(client, message):
    """Enkripsi Atbash (A↔Z, B↔Y, dst)"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>atbash [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    
    # Atbash cipher
    result = ""
    for char in text:
        if 'a' <= char <= 'z':
            result += chr(ord('z') - (ord(char) - ord('a')))
        elif 'A' <= char <= 'Z':
            result += chr(ord('Z') - (ord(char) - ord('A')))
        else:
            result += char
    
    await message.reply(
        f"<b>🔄 ATBASH CIPHER</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔐 <b>Hasil:</b> {result[:50]}{'...' if len(result) > 50 else ''}"
    )

@PY.UBOT("morse")
@PY.TOP_CMD
async def morse_code(client, message):
    """Encode/decode morse code"""
    if len(message.command) < 3:
        return await message.reply("Format: <code>morse [encode/decode] [teks]</code>")
    
    mode = message.command[1].lower()
    text = ' '.join(message.command[2:])
    
    # Morse code dictionary - FIXED VERSION
    morse_dict = {
        'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
        'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
        'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
        'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
        'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
        '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
        '8': '---..', '9': '----.', '.': '.-.-.-', ',': '--..--', '?': '..--..',
        '!': '-.-.--', '/': '-..-.', '(': '-.--.', ')': '-.--.-', '&': '.-...',
        ':': '---...', ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-',
        '_': '..--.-', '"': '.-..-.', '$': '...-..-', '@': '.--.-.'
    }
    
    # Reverse dictionary for decode
    reverse_morse = {v: k for k, v in morse_dict.items()}
    
    try:
        if mode == 'encode':
            result = []
            for char in text.upper():
                if char == ' ':
                    result.append('/')
                elif char in morse_dict:
                    result.append(morse_dict[char])
                else:
                    result.append(char)
            
            encoded = ' '.join(result)
            await message.reply(
                f"<b>📡 MORSE ENCODE</b>\n\n"
                f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔐 <b>Morse:</b> <code>{encoded[:200]}{'...' if len(encoded) > 200 else ''}</code>"
            )
            
        elif mode == 'decode':
            result = []
            words = text.split('/')
            for word in words:
                for code in word.strip().split():
                    if code in reverse_morse:
                        result.append(reverse_morse[code])
                result.append(' ')
            
            decoded = ''.join(result).strip()
            await message.reply(
                f"<b>📡 MORSE DECODE</b>\n\n"
                f"📝 <b>Morse:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔓 <b>Teks:</b> {decoded[:50]}{'...' if len(decoded) > 50 else ''}"
            )
        else:
            await message.reply("Mode harus 'encode' atau 'decode'")
            
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("binary")
@PY.TOP_CMD
async def binary_tool(client, message):
    """Binary encode/decode"""
    if len(message.command) < 3:
        return await message.reply("Format: <code>binary [encode/decode] [teks]</code>")
    
    mode = message.command[1].lower()
    text = ' '.join(message.command[2:])
    
    try:
        if mode == 'encode':
            binary = ' '.join(format(ord(c), '08b') for c in text)
            await message.reply(
                f"<b>🔢 BINARY ENCODE</b>\n\n"
                f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Binary:</b> <code>{binary[:200]}{'...' if len(binary) > 200 else ''}</code>"
            )
        elif mode == 'decode':
            binary_values = text.split()
            ascii_string = ''.join(chr(int(b, 2)) for b in binary_values)
            await message.reply(
                f"<b>🔓 BINARY DECODE</b>\n\n"
                f"📝 <b>Binary:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Teks:</b> {ascii_string[:100]}{'...' if len(ascii_string) > 100 else ''}"
            )
        else:
            await message.reply("Mode harus 'encode' atau 'decode'")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("hex")
@PY.TOP_CMD
async def hex_tool(client, message):
    """Hexadecimal encode/decode"""
    if len(message.command) < 3:
        return await message.reply("Format: <code>hex [encode/decode] [teks]</code>")
    
    mode = message.command[1].lower()
    text = ' '.join(message.command[2:])
    
    try:
        if mode == 'encode':
            hex_str = text.encode().hex()
            await message.reply(
                f"<b>🔢 HEX ENCODE</b>\n\n"
                f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Hex:</b> <code>{hex_str[:200]}{'...' if len(hex_str) > 200 else ''}</code>"
            )
        elif mode == 'decode':
            bytes_str = bytes.fromhex(text.replace(' ', ''))
            decoded = bytes_str.decode('utf-8', errors='ignore')
            await message.reply(
                f"<b>🔓 HEX DECODE</b>\n\n"
                f"📝 <b>Hex:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
                f"🔑 <b>Teks:</b> {decoded[:100]}{'...' if len(decoded) > 100 else ''}"
            )
        else:
            await message.reply("Mode harus 'encode' atau 'decode'")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

# ==================== FILE INFO ====================

@PY.UBOT("listext")
@PY.TOP_CMD
async def list_extensions(client, message):
    """Daftar ekstensi file populer"""
    ext_list = {
        "📄 Dokumen": ".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .txt, .rtf, .odt, .ods, .odp",
        "🖼️ Gambar": ".jpg, .jpeg, .png, .gif, .bmp, .svg, .webp, .ico, .tiff, .psd, .ai",
        "🎵 Audio": ".mp3, .wav, .flac, .aac, .ogg, .m4a, .wma, .opus, .midi",
        "🎬 Video": ".mp4, .avi, .mkv, .mov, .wmv, .flv, .webm, .m4v, .3gp, .mpeg",
        "🗜️ Arsip": ".zip, .rar, .7z, .tar, .gz, .bz2, .xz, .iso, .cab, .dmg",
        "💻 Kode": ".py, .js, .html, .css, .php, .java, .cpp, .c, .rb, .go, .rs, .swift, .kt",
        "⚙️ Executable": ".exe, .msi, .apk, .deb, .rpm, .bin, .sh, .bat, .jar",
        "📊 Database": ".sql, .db, .sqlite, .mdb, .accdb, .dbf, .csv",
        "🌐 Web": ".html, .htm, .xml, .json, .yml, .yaml, .toml, .ini, .cfg",
        "🎨 Design": ".psd, .ai, .eps, .indd, .cdr, .sketch, .fig"
    }
    
    text = "<b>📁 EKSTENSI FILE POPULER</b>\n\n"
    for category, exts in ext_list.items():
        text += f"{category}\n{exts}\n\n"
    
    await message.reply(text)

@PY.UBOT("mime")
@PY.TOP_CMD
async def mime_type(client, message):
    """Cek MIME type dari ekstensi"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>mime [ekstensi]</code>\nContoh: <code>mime .pdf</code>")
    
    ext = message.command[1].lower()
    if not ext.startswith('.'):
        ext = '.' + ext
    
    # MIME types dictionary - FIXED VERSION
    mime_types = {
        '.pdf': 'application/pdf',
        '.doc': 'application/msword',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.xls': 'application/vnd.ms-excel',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.ppt': 'application/vnd.ms-powerpoint',
        '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        '.txt': 'text/plain',
        '.rtf': 'application/rtf',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif',
        '.bmp': 'image/bmp',
        '.svg': 'image/svg+xml',
        '.webp': 'image/webp',
        '.ico': 'image/x-icon',
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
        '.flac': 'audio/flac',
        '.aac': 'audio/aac',
        '.ogg': 'audio/ogg',
        '.mp4': 'video/mp4',
        '.avi': 'video/x-msvideo',
        '.mkv': 'video/x-matroska',
        '.mov': 'video/quicktime',
        '.webm': 'video/webm',
        '.zip': 'application/zip',
        '.rar': 'application/x-rar-compressed',
        '.7z': 'application/x-7z-compressed',
        '.tar': 'application/x-tar',
        '.gz': 'application/gzip',
        '.py': 'text/x-python',
        '.js': 'text/javascript',
        '.html': 'text/html',
        '.css': 'text/css',
        '.php': 'application/x-httpd-php',
        '.java': 'text/x-java-source',
        '.json': 'application/json',
        '.xml': 'application/xml',
        '.exe': 'application/x-msdownload',
        '.apk': 'application/vnd.android.package-archive',
        '.deb': 'application/x-debian-package',
        '.rpm': 'application/x-rpm',
        '.sh': 'application/x-sh',
        '.sql': 'application/sql',
        '.db': 'application/x-sqlite3'
    }
    
    mime = mime_types.get(ext, 'Unknown/not found')
    description = "File " + ext[1:].upper() if mime != 'Unknown/not found' else "Unknown file type"
    
    await message.reply(
        f"<b>📁 MIME TYPE</b>\n\n"
        f"📌 <b>Ekstensi:</b> {ext}\n"
        f"📋 <b>MIME:</b> <code>{mime}</code>\n"
        f"ℹ️ <b>Deskripsi:</b> {description}"
    )

@PY.UBOT("magic")
@PY.TOP_CMD
async def magic_number(client, message):
    """Cek magic number file dari ekstensi"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>magic [ekstensi]</code>\nContoh: <code>magic .pdf</code>")
    
    ext = message.command[1].lower()
    if not ext.startswith('.'):
        ext = '.' + ext
    
    # Magic numbers (file signatures)
    magic_numbers = {
        '.pdf': '25 50 44 46 (PDF)',
        '.jpg': 'FF D8 FF (JPEG)',
        '.jpeg': 'FF D8 FF (JPEG)',
        '.png': '89 50 4E 47 (PNG)',
        '.gif': '47 49 46 38 (GIF)',
        '.bmp': '42 4D (BMP)',
        '.zip': '50 4B 03 04 (ZIP)',
        '.rar': '52 61 72 21 (RAR)',
        '.7z': '37 7A BC AF (7Z)',
        '.mp3': '49 44 33 (MP3 with ID3) or FF FB (MP3 without ID3)',
        '.mp4': '00 00 00 18 66 74 79 70 (MP4)',
        '.avi': '52 49 46 46 (AVI)',
        '.mkv': '1A 45 DF A3 (MKV)',
        '.exe': '4D 5A (MZ - EXE)',
        '.elf': '7F 45 4C 46 (ELF)',
        '.pyc': '03 F3 0D 0A (Python compiled)',
        '.class': 'CA FE BA BE (Java class)',
        '.ttf': '00 01 00 00 (TrueType Font)',
        '.wav': '52 49 46 46 (WAV)',
        '.flac': '66 4C 61 43 (FLAC)',
        '.iso': '43 44 30 30 31 (ISO)',
        '.dmg': '78 01 73 0D 62 62 60 (DMG)',
        '.psd': '38 42 50 53 (PSD)',
        '.pdf': '25 50 44 46 (PDF)'
    }
    
    magic = magic_numbers.get(ext, 'Unknown/not found')
    
    await message.reply(
        f"<b>🔮 MAGIC NUMBER</b>\n\n"
        f"📌 <b>Ekstensi:</b> {ext}\n"
        f"✨ <b>Magic Number:</b> <code>{magic}</code>\n\n"
        f"<i>Magic number adalah signature unik di awal file\n"
        f"Gunakan untuk identifikasi file tanpa ekstensi</i>"
    )

@PY.UBOT("size")
@PY.TOP_CMD
async def convert_size(client, message):
    """Konversi ukuran file"""
    if len(message.command) < 4:
        return await message.reply(
            "Format: <code>size [ukuran] [dari] [ke]</code>\n"
            "Contoh: <code>size 1 GB MB</code>\n\n"
            "Satuan: B, KB, MB, GB, TB, PB"
        )
    
    try:
        size = float(message.command[1])
        dari = message.command[2].upper()
        ke = message.command[3].upper()
    except ValueError:
        return await message.reply("Ukuran harus angka!")
    
    units = {'B': 1, 'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4, 'PB': 1024**5}
    
    if dari not in units or ke not in units:
        return await message.reply("Satuan tidak dikenal! Gunakan: B, KB, MB, GB, TB, PB")
    
    # Konversi ke bytes dulu
    bytes_size = size * units[dari]
    hasil = bytes_size / units[ke]
    
    await message.reply(
        f"<b>💾 KONVERSI UKURAN</b>\n\n"
        f"📊 <b>{size} {dari}</b>\n"
        f"   = <b>{hasil:,.2f} {ke}</b>\n"
        f"   = <b>{bytes_size:,.0f} Bytes</b>"
    )

# ==================== CALCULATOR ====================

@PY.UBOT("calc")
@PY.TOP_CMD
async def calculator(client, message):
    """Kalkulator sederhana"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>calc [rumus]</code>\nContoh: <code>calc 2+2*5</code>")
    
    expr = ' '.join(message.command[1:])
    
    # Bersihin ekspresi dari karakter berbahaya
    allowed = set('0123456789+-*/.() ')
    if any(c not in allowed for c in expr):
        return await message.reply("❌ Ekspresi mengandung karakter tidak valid")
    
    try:
        # Evaluasi dengan aman
        result = eval(expr, {"__builtins__": {}}, {})
        
        await message.reply(
            f"<b>🧮 CALCULATOR</b>\n\n"
            f"📝 <b>Rumus:</b> {expr}\n"
            f"📊 <b>Hasil:</b> {result:,}"
        )
    except ZeroDivisionError:
        await message.reply("❌ Tidak bisa membagi dengan nol")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("math")
@PY.TOP_CMD
async def math_operation(client, message):
    """Operasi matematika sederhana"""
    if len(message.command) < 4:
        return await message.reply(
            "Format: <code>math [operasi] [angka1] [angka2]</code>\n"
            "Operasi: tambah, kurang, kali, bagi, pangkat, modulus\n"
            "Contoh: <code>math tambah 10 5</code>"
        )
    
    operasi = message.command[1].lower()
    
    try:
        a = float(message.command[2])
        b = float(message.command[3])
    except ValueError:
        return await message.reply("Angka harus valid!")
    
    operations = {
        'tambah': ('+', a + b),
        'kurang': ('-', a - b),
        'kali': ('×', a * b),
        'bagi': ('÷', a / b if b != 0 else "Error: division by zero"),
        'pangkat': ('^', a ** b),
        'modulus': ('%', a % b if b != 0 else "Error: modulus by zero")
    }
    
    if operasi not in operations:
        return await message.reply(f"Operasi tidak dikenal! Pilih: {', '.join(operations.keys())}")
    
    symbol, result = operations[operasi]
    
    if isinstance(result, str):
        await message.reply(f"❌ {result}")
    else:
        await message.reply(
            f"<b>🧮 MATH OPERATION</b>\n\n"
            f"{a:,.2f} {symbol} {b:,.2f} = <b>{result:,.2f}</b>"
        )

@PY.UBOT("konversi")
@PY.TOP_CMD
async def konversi_satuan(client, message):
    """Konversi satuan panjang dan berat"""
    if len(message.command) < 4:
        return await message.reply(
            "Format: <code>konversi [nilai] [dari] [ke]</code>\n"
            "Contoh: <code>konversi 100 cm m</code>\n\n"
            "<b>Satuan panjang:</b> cm, m, km, inch, foot, yard, mile\n"
            "<b>Satuan berat:</b> gram, kg, ton, lb, oz\n"
            "<b>Satuan volume:</b> ml, liter, galon"
        )
    
    try:
        nilai = float(message.command[1])
        dari = message.command[2].lower()
        ke = message.command[3].lower()
    except ValueError:
        return await message.reply("Nilai harus angka!")
    
    # Unit converter - PANJANG
    length_units = {
        'cm': 0.01, 'm': 1, 'km': 1000,
        'inch': 0.0254, 'foot': 0.3048, 'yard': 0.9144,
        'mile': 1609.34
    }
    
    # Unit converter - BERAT
    weight_units = {
        'gram': 0.001, 'kg': 1, 'ton': 1000,
        'lb': 0.453592, 'oz': 0.0283495
    }
    
    # Unit converter - VOLUME
    volume_units = {
        'ml': 0.001, 'liter': 1, 'galon': 3.78541
    }
    
    # Tentukan kategori
    if dari in length_units and ke in length_units:
        # Konversi ke meter dulu
        in_meters = nilai * length_units[dari]
        hasil = in_meters / length_units[ke]
        kategori = "Panjang"
    elif dari in weight_units and ke in weight_units:
        # Konversi ke kg dulu
        in_kg = nilai * weight_units[dari]
        hasil = in_kg / weight_units[ke]
        kategori = "Berat"
    elif dari in volume_units and ke in volume_units:
        # Konversi ke liter dulu
        in_liter = nilai * volume_units[dari]
        hasil = in_liter / volume_units[ke]
        kategori = "Volume"
    else:
        return await message.reply("Unit tidak dikenal atau tidak sama kategori!")
    
    await message.reply(
        f"<b>📏 KONVERSI SATUAN ({kategori})</b>\n\n"
        f"📊 <b>{nilai} {dari}</b>\n"
        f"   = <b>{hasil:.4f} {ke}</b>"
    )

# ==================== TEXT TOOLS ====================

@PY.UBOT("reverse")
@PY.TOP_CMD
async def reverse_text(client, message):
    """Balikkan teks"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>reverse [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    reversed_text = text[::-1]
    
    await message.reply(
        f"<b>🔄 REVERSE TEXT</b>\n\n"
        f"📝 <b>Original:</b> {text[:100]}{'...' if len(text) > 100 else ''}\n"
        f"🔁 <b>Reverse:</b> {reversed_text[:100]}{'...' if len(reversed_text) > 100 else ''}"
    )

@PY.UBOT("count")
@PY.TOP_CMD
async def count_text(client, message):
    """Hitung karakter dan kata"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>count [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    
    char_count = len(text)
    char_no_spaces = len(text.replace(' ', ''))
    word_count = len(text.split())
    line_count = text.count('\n') + 1
    
    # Hitung huruf, angka, simbol
    letter_count = sum(c.isalpha() for c in text)
    digit_count = sum(c.isdigit() for c in text)
    space_count = sum(c.isspace() for c in text)
    other_count = char_count - letter_count - digit_count - space_count
    
    await message.reply(
        f"<b>📊 TEXT STATISTICS</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n\n"
        f"🔤 <b>Total Karakter:</b> {char_count}\n"
        f"🔡 <b>Karakter (tanpa spasi):</b> {char_no_spaces}\n"
        f"📚 <b>Jumlah Kata:</b> {word_count}\n"
        f"📏 <b>Jumlah Baris:</b> {line_count}\n\n"
        f"<b>Rincian:</b>\n"
        f"   • Huruf: {letter_count}\n"
        f"   • Angka: {digit_count}\n"
        f"   • Spasi: {space_count}\n"
        f"   • Simbol: {other_count}"
    )

@PY.UBOT("upper")
@PY.TOP_CMD
async def upper_text(client, message):
    """Ubah ke huruf besar"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>upper [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    upper_text = text.upper()
    
    await message.reply(
        f"<b>⬆️ UPPERCASE</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔠 <b>Hasil:</b> {upper_text[:50]}{'...' if len(upper_text) > 50 else ''}"
    )

@PY.UBOT("lower")
@PY.TOP_CMD
async def lower_text(client, message):
    """Ubah ke huruf kecil"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>lower [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    lower_text = text.lower()
    
    await message.reply(
        f"<b>⬇️ LOWERCASE</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔡 <b>Hasil:</b> {lower_text[:50]}{'...' if len(lower_text) > 50 else ''}"
    )

@PY.UBOT("capitalize")
@PY.TOP_CMD
async def capitalize_text(client, message):
    """Kapitalisasi tiap kata"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>capitalize [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    capitalized = text.title()
    
    await message.reply(
        f"<b>📝 CAPITALIZE</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"✨ <b>Hasil:</b> {capitalized[:50]}{'...' if len(capitalized) > 50 else ''}"
    )

@PY.UBOT("swapcase")
@PY.TOP_CMD
async def swapcase_text(client, message):
    """Balik huruf besar/kecil"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>swapcase [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    swapped = text.swapcase()
    
    await message.reply(
        f"<b>🔄 SWAP CASE</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"🔀 <b>Hasil:</b> {swapped[:50]}{'...' if len(swapped) > 50 else ''}"
    )

@PY.UBOT("title")
@PY.TOP_CMD
async def title_text(client, message):
    """Format judul"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>title [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    titled = text.title()
    
    await message.reply(
        f"<b>📰 TITLE CASE</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"📰 <b>Hasil:</b> {titled[:50]}{'...' if len(titled) > 50 else ''}"
    )

@PY.UBOT("strip")
@PY.TOP_CMD
async def strip_text(client, message):
    """Hapus spasi berlebih"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>strip [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    
    # Hapus spasi berlebih
    stripped = ' '.join(text.split())
    
    await message.reply(
        f"<b>✂️ STRIP SPACES</b>\n\n"
        f"📝 <b>Original:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n"
        f"✨ <b>Hasil:</b> {stripped[:50]}{'...' if len(stripped) > 50 else ''}"
    )

# ==================== TIME TOOLS ====================

@PY.UBOT("timestamp")
@PY.TOP_CMD
async def get_timestamp(client, message):
    """Dapatkan timestamp sekarang"""
    now = datetime.now()
    timestamp = int(now.timestamp())
    
    await message.reply(
        f"<b>⏰ TIMESTAMP</b>\n\n"
        f"📅 <b>Tanggal:</b> {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"🔢 <b>Timestamp:</b> <code>{timestamp}</code>\n"
        f"🌍 <b>UTC:</b> {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
    )

@PY.UBOT("epoch")
@PY.TOP_CMD
async def epoch_converter(client, message):
    """Konversi epoch ke tanggal"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>epoch [timestamp]</code>")
    
    try:
        timestamp = int(message.command[1])
        
        # Cek panjang timestamp (detik atau milidetik)
        if timestamp > 10**12:  # Kemungkinan milidetik
            timestamp = timestamp / 1000
        
        date = datetime.fromtimestamp(timestamp)
        utc_date = datetime.utcfromtimestamp(timestamp)
        
        await message.reply(
            f"<b>📅 EPOCH CONVERTER</b>\n\n"
            f"🔢 <b>Timestamp:</b> {message.command[1]}\n"
            f"📆 <b>Lokal:</b> {date.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"🌍 <b>UTC:</b> {utc_date.strftime('%Y-%m-%d %H:%M:%S')}"
        )
    except ValueError:
        await message.reply("Timestamp harus angka!")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("timezone")
@PY.TOP_CMD
async def timezone_info(client, message):
    """Waktu di berbagai kota"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>timezone [kota]</code>\nContoh: <code>timezone jakarta</code>")
    
    city = message.command[1].lower()
    
    # Database zona waktu sederhana
    timezones = {
        'jakarta': 'Asia/Jakarta',
        'surabaya': 'Asia/Jakarta',
        'bali': 'Asia/Makassar',
        'makassar': 'Asia/Makassar',
        'jayapura': 'Asia/Jayapura',
        'tokyo': 'Asia/Tokyo',
        'seoul': 'Asia/Seoul',
        'beijing': 'Asia/Shanghai',
        'singapore': 'Asia/Singapore',
        'kuala lumpur': 'Asia/Kuala_Lumpur',
        'bangkok': 'Asia/Bangkok',
        'mumbai': 'Asia/Kolkata',
        'dubai': 'Asia/Dubai',
        'moscow': 'Europe/Moscow',
        'london': 'Europe/London',
        'paris': 'Europe/Paris',
        'berlin': 'Europe/Berlin',
        'rome': 'Europe/Rome',
        'new york': 'America/New_York',
        'los angeles': 'America/Los_Angeles',
        'chicago': 'America/Chicago',
        'toronto': 'America/Toronto',
        'sydney': 'Australia/Sydney',
        'auckland': 'Pacific/Auckland'
    }
    
    if city not in timezones:
        # Cari partial match
        found = False
        for key, tz in timezones.items():
            if city in key:
                city = key
                found = True
                break
        
        if not found:
            cities = ', '.join(sorted(set(timezones.keys())[:10]))
            return await message.reply(
                f"❌ Kota '{city}' tidak ditemukan.\n"
                f"Contoh kota: {cities}..."
            )
    
    try:
        import pytz
        tz = pytz.timezone(timezones[city])
        now = datetime.now(tz)
        
        # Dapatkan offset
        offset = now.strftime('%z')
        offset_hours = int(offset[:3]) if offset else 0
        
        # Dapatkan waktu di UTC
        utc_now = datetime.now(pytz.UTC)
        
        await message.reply(
            f"<b>🌍 TIMEZONE: {city.upper()}</b>\n\n"
            f"📍 <b>Zona:</b> {timezones[city]}\n"
            f"🕐 <b>Waktu sekarang:</b> {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"📊 <b>Offset UTC:</b> UTC{offset_hours:+d}\n"
            f"🌐 <b>UTC:</b> {utc_now.strftime('%Y-%m-%d %H:%M:%S')}"
        )
    except ImportError:
        await message.reply("Module pytz tidak terinstall. Install dengan: pip install pytz")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("countdown")
@PY.TOP_CMD
async def countdown_date(client, message):
    """Hitung mundur ke tanggal tertentu"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>countdown [tanggal]</code>\nContoh: <code>countdown 2025-01-01</code>")
    
    date_str = message.command[1]
    
    try:
        target = datetime.strptime(date_str, '%Y-%m-%d')
        now = datetime.now()
        
        if target < now:
            return await message.reply("❌ Tanggal target sudah lewat!")
        
        diff = target - now
        
        days = diff.days
        hours = diff.seconds // 3600
        minutes = (diff.seconds % 3600) // 60
        seconds = diff.seconds % 60
        
        total_hours = days * 24 + hours
        
        await message.reply(
            f"<b>⏳ COUNTDOWN</b>\n\n"
            f"📅 <b>Target:</b> {target.strftime('%d %B %Y')}\n"
            f"📊 <b>Sisa waktu:</b>\n"
            f"   • {days} hari\n"
            f"   • {total_hours} jam\n"
            f"   • {diff.seconds} detik\n\n"
            f"📈 <b>Detail:</b> {days} hari, {hours} jam, {minutes} menit, {seconds} detik"
        )
    except ValueError:
        await message.reply("Format tanggal salah! Gunakan YYYY-MM-DD\nContoh: 2025-01-01")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

# ==================== NUMBER TOOLS ====================

@PY.UBOT("random")
@PY.TOP_CMD
async def random_number(client, message):
    """Generate angka random"""
    if len(message.command) < 3:
        return await message.reply("Format: <code>random [min] [max]</code>\nContoh: <code>random 1 100</code>")
    
    try:
        min_val = int(message.command[1])
        max_val = int(message.command[2])
        
        if min_val > max_val:
            min_val, max_val = max_val, min_val
        
        rand_num = random.randint(min_val, max_val)
        
        await message.reply(
            f"<b>🎲 RANDOM NUMBER</b>\n\n"
            f"📊 <b>Range:</b> {min_val} - {max_val}\n"
            f"🔢 <b>Hasil:</b> <code>{rand_num}</code>"
        )
    except ValueError:
        await message.reply("Min dan Max harus angka!")

@PY.UBOT("prime")
@PY.TOP_CMD
async def cek_prima(client, message):
    """Cek bilangan prima"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>prime [angka]</code>")
    
    try:
        num = int(message.command[1])
        
        if num < 2:
            is_prime = False
        else:
            is_prime = True
            for i in range(2, int(num**0.5) + 1):
                if num % i == 0:
                    is_prime = False
                    break
        
        status = "✅ BILANGAN PRIMA" if is_prime else "❌ BUKAN bilangan prima"
        
        # Cari bilangan prima terdekat
        if not is_prime and num > 2:
            next_prime = num + 1
            while True:
                prime_check = True
                for i in range(2, int(next_prime**0.5) + 1):
                    if next_prime % i == 0:
                        prime_check = False
                        break
                if prime_check:
                    break
                next_prime += 1
            
            prev_prime = num - 1
            while prev_prime > 1:
                prime_check = True
                for i in range(2, int(prev_prime**0.5) + 1):
                    if prev_prime % i == 0:
                        prime_check = False
                        break
                if prime_check:
                    break
                prev_prime -= 1
            
            additional = f"\n📌 <b>Prima terdekat:</b> {prev_prime} (sebelum), {next_prime} (sesudah)"
        else:
            additional = ""
        
        await message.reply(
            f"<b>🔢 CEK PRIMA</b>\n\n"
            f"📊 <b>Angka:</b> {num}\n"
            f"📌 <b>Status:</b> {status}{additional}"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("fibonacci")
@PY.TOP_CMD
async def fibonacci(client, message):
    """Deret Fibonacci ke-n"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>fibonacci [n]</code>\nContoh: <code>fibonacci 10</code>")
    
    try:
        n = int(message.command[1])
        
        if n < 1:
            return await message.reply("n harus positif!")
        if n > 50:
            return await message.reply("Maksimal n = 50 (biar ga kepanjangan)")
        
        # Generate Fibonacci
        fib = [0, 1]
        for i in range(2, n):
            fib.append(fib[i-1] + fib[i-2])
        
        result = fib[:n]
        
        # Hitung rasio emas
        if n > 2:
            golden_ratio = fib[-1] / fib[-2] if fib[-2] != 0 else 0
            golden_info = f"\n📊 <b>Rasio Emas:</b> {golden_ratio:.6f} (mendekati 1.618)"
        else:
            golden_info = ""
        
        await message.reply(
            f"<b>🔢 FIBONACCI</b>\n\n"
            f"📊 <b>n = {n}</b>\n"
            f"📋 <b>Deret:</b> {', '.join(map(str, result))}{golden_info}"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("faktorial")
@PY.TOP_CMD
async def factorial(client, message):
    """Hitung faktorial"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>faktorial [angka]</code>\nContoh: <code>faktorial 5</code>")
    
    try:
        num = int(message.command[1])
        
        if num < 0:
            return await message.reply("Faktorial tidak didefinisikan untuk bilangan negatif!")
        if num > 100:
            return await message.reply("Angka terlalu besar! Maksimal 100")
        
        result = 1
        for i in range(1, num + 1):
            result *= i
        
        await message.reply(
            f"<b>🔢 FAKTORIAL</b>\n\n"
            f"📊 <b>{num}!</b> = {result:,}\n\n"
            f"📝 <b>Rumus:</b> {' × '.join(str(i) for i in range(1, num + 1))}"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("biner")
@PY.TOP_CMD
async def to_binary(client, message):
    """Konversi angka ke biner"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>biner [angka]</code>")
    
    try:
        num = int(message.command[1])
        binary = bin(num)[2:]
        
        await message.reply(
            f"<b>🔢 BINARY CONVERTER</b>\n\n"
            f"📊 <b>Desimal:</b> {num}\n"
            f"📟 <b>Biner:</b> <code>{binary}</code>\n"
            f"📏 <b>Panjang bit:</b> {len(binary)} bit"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("hexa")
@PY.TOP_CMD
async def to_hexadecimal(client, message):
    """Konversi angka ke heksadesimal"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>hexa [angka]</code>")
    
    try:
        num = int(message.command[1])
        hexa = hex(num)[2:].upper()
        
        await message.reply(
            f"<b>🔢 HEXADECIMAL CONVERTER</b>\n\n"
            f"📊 <b>Desimal:</b> {num}\n"
            f"📟 <b>Heksadesimal:</b> <code>{hexa}</code>\n"
            f"📏 <b>Panjang:</b> {len(hexa)} karakter"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("oktal")
@PY.TOP_CMD
async def to_octal(client, message):
    """Konversi angka ke oktal"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>oktal [angka]</code>")
    
    try:
        num = int(message.command[1])
        octal = oct(num)[2:]
        
        await message.reply(
            f"<b>🔢 OCTAL CONVERTER</b>\n\n"
            f"📊 <b>Desimal:</b> {num}\n"
            f"📟 <b>Oktal:</b> <code>{octal}</code>"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

@PY.UBOT("romawi")
@PY.TOP_CMD
async def to_roman(client, message):
    """Konversi angka ke romawi"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>romawi [angka]</code>\nMaksimal 3999")
    
    try:
        num = int(message.command[1])
        
        if num < 1 or num > 3999:
            return await message.reply("Angka harus antara 1 - 3999")
        
        # Konversi ke romawi
        val = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
        sym = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
        
        roman = ""
        i = 0
        while num > 0:
            for _ in range(num // val[i]):
                roman += sym[i]
                num -= val[i]
            i += 1
        
        await message.reply(
            f"<b>🔢 ROMAN CONVERTER</b>\n\n"
            f"📊 <b>Angka:</b> {message.command[1]}\n"
            f"📜 <b>Romawi:</b> <code>{roman}</code>"
        )
    except ValueError:
        await message.reply("Masukkan angka yang valid!")

# ==================== WEB TOOLS ====================

@PY.UBOT("short")
@PY.TOP_CMD
async def short_link(client, message):
    """Short link dengan tinyurl"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>short [url]</code>")
    
    url = message.command[1]
    
    if not validate_url(url):
        return await message.reply("❌ URL tidak valid! Gunakan format http:// atau https://")
    
    msg = await message.reply(f"🔗 Memperpendek link...")
    
    try:
        # TinyURL API
        response = requests.get(f"https://tinyurl.com/api-create.php?url={url}", timeout=10)
        
        if response.status_code == 200:
            short_url = response.text.strip()
            
            await msg.edit(
                f"<b>🔗 SHORT LINK</b>\n\n"
                f"📎 <b>Original:</b> {url}\n"
                f"✂️ <b>Short:</b> <code>{short_url}</code>\n"
                f"📊 <b>Service:</b> TinyURL"
            )
        else:
            await msg.edit("❌ Gagal memperpendek link")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("source")
@PY.TOP_CMD
async def view_source(client, message):
    """Lihat source code website"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>source [url]</code>")
    
    url = message.command[1]
    
    if not validate_url(url):
        url = "http://" + url
    
    msg = await message.reply(f"🔍 Mengambil source code...")
    
    try:
        response = requests.get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
        
        if response.status_code == 200:
            source = response.text[:1000]  # Ambil 1000 karakter pertama
            
            await msg.edit(
                f"<b>📄 SOURCE CODE: {url}</b>\n\n"
                f"<code>{source}</code>\n\n"
                f"<i>...dan {len(response.text) - 1000} karakter lainnya</i>"
            )
        else:
            await msg.edit(f"❌ Gagal mengambil source. Status code: {response.status_code}")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("headers")
@PY.TOP_CMD
async def http_headers(client, message):
    """Lihat HTTP headers website"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>headers [url]</code>")
    
    url = message.command[1]
    
    if not validate_url(url):
        url = "http://" + url
    
    msg = await message.reply(f"🔍 Mengambil headers...")
    
    try:
        response = requests.get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
        
        headers_text = "<b>📋 HTTP HEADERS</b>\n\n"
        headers_text += f"📍 <b>URL:</b> {url}\n"
        headers_text += f"📊 <b>Status:</b> {response.status_code} {response.reason}\n\n"
        
        for key, value in response.headers.items():
            headers_text += f"<b>{key}:</b> {value}\n"
        
        if len(headers_text) > 1000:
            headers_text = headers_text[:1000] + "\n\n<i>...truncated</i>"
        
        await msg.edit(headers_text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("status")
@PY.TOP_CMD
async def check_status(client, message):
    """Cek status website"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>status [url]</code>")
    
    url = message.command[1]
    
    if not validate_url(url):
        url = "http://" + url
    
    msg = await message.reply(f"🔍 Mengecek status...")
    
    try:
        start_time = time.time()
        response = requests.get(url, timeout=10, headers={'User-Agent': 'Mozilla/5.0'})
        end_time = time.time()
        
        response_time = (end_time - start_time) * 1000
        
        status_emoji = "✅" if response.status_code < 400 else "⚠️" if response.status_code < 500 else "❌"
        
        await msg.edit(
            f"<b>{status_emoji} STATUS CHECK: {url}</b>\n\n"
            f"📊 <b>Status Code:</b> {response.status_code} {response.reason}\n"
            f"⏱️ <b>Response Time:</b> {response_time:.2f} ms\n"
            f"📏 <b>Content Length:</b> {len(response.content):,} bytes\n"
            f"🔍 <b>Server:</b> {response.headers.get('Server', 'Unknown')}\n"
            f"📄 <b>Content Type:</b> {response.headers.get('Content-Type', 'Unknown')}"
        )
        
    except requests.exceptions.ConnectionError:
        await msg.edit(f"❌ {url} tidak dapat dijangkau (Connection Error)")
    except requests.exceptions.Timeout:
        await msg.edit(f"❌ {url} timeout (lambat merespon)")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("screenshot")
@PY.TOP_CMD
async def website_screenshot(client, message):
    """Screenshot website"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>screenshot [url]</code>")
    
    url = message.command[1]
    
    if not validate_url(url):
        url = "http://" + url
    
    msg = await message.reply(f"📸 Mengambil screenshot...")
    
    try:
        # Pake API screenshot (ganti dengan API key sendiri klo perlu)
        api_url = f"https://api.screenshotmachine.com/?key=YOUR_API_KEY&url={url}&size=M&format=png"
        
        # Fallback ke layman API
        response = requests.get(f"https://image.thum.io/get/width/400/crop/800/{url}", timeout=15)
        
        if response.status_code == 200:
            # Simpan sementara
            filename = f"screenshot_{int(time.time())}.png"
            with open(filename, 'wb') as f:
                f.write(response.content)
            
            await msg.delete()
            
            await client.send_photo(
                chat_id=message.chat.id,
                photo=filename,
                caption=f"<b>📸 SCREENSHOT: {url}</b>",
                reply_to_message_id=message.id
            )
            
            # Hapus file
            os.remove(filename)
        else:
            await msg.edit("❌ Gagal mengambil screenshot")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== GENERATOR ====================

@PY.UBOT("pass")
@PY.TOP_CMD
async def generate_password(client, message):
    """Generate random password"""
    if len(message.command) < 2:
        length = 12
    else:
        try:
            length = int(message.command[1])
            if length < 4:
                return await message.reply("Minimal panjang 4 karakter")
            if length > 50:
                return await message.reply("Maksimal panjang 50 karakter")
        except ValueError:
            return await message.reply("Panjang harus angka!")
    
    # Karakter untuk password
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    # Pasti ada minimal 1 dari setiap kategori
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(symbols)
    ]
    
    # Sisanya random
    all_chars = lowercase + uppercase + digits + symbols
    password.extend(random.choice(all_chars) for _ in range(length - 4))
    
    # Acak urutan
    random.shuffle(password)
    
    password_str = ''.join(password)
    
    # Hitung kekuatan password
    strength = "Lemah"
    if length >= 12 and any(c in symbols for c in password_str):
        strength = "Kuat"
    elif length >= 8:
        strength = "Sedang"
    
    await message.reply(
        f"<b>🔑 RANDOM PASSWORD</b>\n\n"
        f"📏 <b>Panjang:</b> {length} karakter\n"
        f"💪 <b>Kekuatan:</b> {strength}\n"
        f"🔐 <b>Password:</b> <code>{password_str}</code>\n\n"
        f"<i>⚠️ Simpan password dengan aman!</i>"
    )

@PY.UBOT("uuid")
@PY.TOP_CMD
async def generate_uuid(client, message):
    """Generate UUID random"""
    import uuid
    
    uuid1 = str(uuid.uuid4())
    uuid2 = str(uuid.uuid4())
    
    await message.reply(
        f"<b>🆔 RANDOM UUID</b>\n\n"
        f"📋 <b>UUID v4:</b>\n"
        f"<code>{uuid1}</code>\n"
        f"<code>{uuid2}</code>\n\n"
        f"📊 <b>Total:</b> 2 UUID generated"
    )

@PY.UBOT("hash")
@PY.TOP_CMD
async def generate_hash(client, message):
    """Generate berbagai hash"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>hash [teks]</code>")
    
    text = message.text.split(None, 1)[1]
    
    md5_hash = hashlib.md5(text.encode()).hexdigest()
    sha1_hash = hashlib.sha1(text.encode()).hexdigest()
    sha256_hash = hashlib.sha256(text.encode()).hexdigest()
    
    await message.reply(
        f"<b>🔐 HASH GENERATOR</b>\n\n"
        f"📝 <b>Teks:</b> {text[:50]}{'...' if len(text) > 50 else ''}\n\n"
        f"<b>MD5:</b>\n<code>{md5_hash}</code>\n\n"
        f"<b>SHA1:</b>\n<code>{sha1_hash}</code>\n\n"
        f"<b>SHA256:</b>\n<code>{sha256_hash[:100]}...</code>"
    )

@PY.UBOT("token")
@PY.TOP_CMD
async def generate_token(client, message):
    """Generate random token"""
    if len(message.command) < 2:
        length = 32
    else:
        try:
            length = int(message.command[1])
            if length < 8:
                return await message.reply("Minimal panjang 8 karakter")
            if length > 64:
                return await message.reply("Maksimal panjang 64 karakter")
        except ValueError:
            return await message.reply("Panjang harus angka!")
    
    # Token biasanya pake hex
    token = ''.join(random.choices('0123456789abcdef', k=length))
    
    # Format token (contoh: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
    if length >= 32:
        formatted = f"{token[:8]}-{token[8:12]}-{token[12:16]}-{token[16:20]}-{token[20:]}"
    else:
        formatted = token
    
    await message.reply(
        f"<b>🎟️ RANDOM TOKEN</b>\n\n"
        f"📏 <b>Panjang:</b> {length} karakter\n"
        f"🔑 <b>Token:</b> <code>{formatted}</code>"
    )

# ==================== VALIDATOR ====================

@PY.UBOT("email")
@PY.TOP_CMD
async def validate_email_tool(client, message):
    """Validasi email"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>email [email]</code>")
    
    email = message.command[1]
    
    if validate_email(email):
        # Cek domain MX record
        domain = email.split('@')[1]
        try:
            mx_records = socket.getaddrinfo(domain, 25)
            mx_status = "✅ Domain memiliki MX record"
        except:
            mx_status = "⚠️ Domain mungkin tidak memiliki mail server"
        
        await message.reply(
            f"<b>📧 EMAIL VALIDATOR</b>\n\n"
            f"📧 <b>Email:</b> {email}\n"
            f"✅ <b>Status:</b> VALID\n"
            f"📊 {mx_status}"
        )
    else:
        await message.reply(
            f"<b>📧 EMAIL VALIDATOR</b>\n\n"
            f"📧 <b>Email:</b> {email}\n"
            f"❌ <b>Status:</b> TIDAK VALID\n\n"
            f"<i>Format email: nama@domain.com</i>"
        )

@PY.UBOT("url")
@PY.TOP_CMD
async def validate_url_tool(client, message):
    """Validasi URL"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>url [url]</code>")
    
    url = message.command[1]
    
    if validate_url(url):
        # Cek apakah bisa diakses
        try:
            response = requests.head(url, timeout=5, allow_redirects=True)
            status = f"✅ DAPAT DIAKSES (Status: {response.status_code})"
        except:
            status = "⚠️ TIDAK dapat diakses (mungkin down)"
        
        await message.reply(
            f"<b>🔗 URL VALIDATOR</b>\n\n"
            f"🔗 <b>URL:</b> {url}\n"
            f"✅ <b>Format:</b> VALID\n"
            f"📊 {status}"
        )
    else:
        await message.reply(
            f"<b>🔗 URL VALIDATOR</b>\n\n"
            f"🔗 <b>URL:</b> {url}\n"
            f"❌ <b>Status:</b> TIDAK VALID\n\n"
            f"<i>Format URL: http://domain.com</i>"
        )

@PY.UBOT("ip")
@PY.TOP_CMD
async def validate_ip_tool(client, message):
    """Validasi IP address"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>ip [ip_address]</code>")
    
    ip = message.command[1]
    
    if validate_ip(ip):
        # Cek apakah IP publik/private
        first_octet = int(ip.split('.')[0])
        
        if first_octet == 10:
            ip_type = "Private (Class A)"
        elif first_octet == 172 and 16 <= int(ip.split('.')[1]) <= 31:
            ip_type = "Private (Class B)"
        elif first_octet == 192 and ip.split('.')[1] == '168':
            ip_type = "Private (Class C)"
        elif first_octet == 127:
            ip_type = "Loopback"
        else:
            ip_type = "Public"
        
        await message.reply(
            f"<b>🌐 IP VALIDATOR</b>\n\n"
            f"📍 <b>IP:</b> {ip}\n"
            f"✅ <b>Status:</b> VALID\n"
            f"🏷️ <b>Tipe:</b> {ip_type}"
        )
    else:
        await message.reply(
            f"<b>🌐 IP VALIDATOR</b>\n\n"
            f"📍 <b>IP:</b> {ip}\n"
            f"❌ <b>Status:</b> TIDAK VALID\n\n"
            f"<i>Format IP: xxx.xxx.xxx.xxx</i>"
        )

@PY.UBOT("phone")
@PY.TOP_CMD
async def validate_phone(client, message):
    """Validasi nomor HP (sederhana)"""
    if len(message.command) < 2:
        return await message.reply("Format: <code>phone [nomor]</code>")
    
    phone = message.command[1]
    
    # Hapus karakter non-digit
    digits = ''.join(filter(str.isdigit, phone))
    
    if len(digits) < 10 or len(digits) > 15:
        status = "❌ TIDAK VALID"
        info = "Panjang nomor harus 10-15 digit"
    elif digits.startswith('0'):
        status = "✅ VALID (Format lokal)"
        info = f"International: +62{digits[1:]}"
    elif digits.startswith('62'):
        status = "✅ VALID (Format internasional)"
        info = f"Lokal: 0{digits[2:]}"
    else:
        status = "✅ VALID (Nomor asing)"
        info = "Nomor internasional"
    
    await message.reply(
        f"<b>📱 PHONE VALIDATOR</b>\n\n"
        f"📞 <b>Nomor:</b> {phone}\n"
        f"📊 <b>Digit:</b> {digits}\n"
        f"📌 <b>Status:</b> {status}\n"
        f"ℹ️ <b>Info:</b> {info}"
    )