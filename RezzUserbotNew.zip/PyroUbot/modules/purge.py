from PyroUbot import *

__MODULE__ = "𝐏𝐮𝐫𝐠𝐞"
__HELP__ = """
<blockquote><b>🧹 𝐏𝐮𝐫𝐠𝐞</b>

 • <code>{0}purge &lt;jumlah></code> - Hapus pesan
 • <code>{0}purgeall</code> - Hapus semua pesan</blockquote>
"""

@PY.UBOT("purge")
@PY.TOP_CMD
async def purge(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    args = message.text.split()
    jumlah = int(args[1]) if len(args) > 1 else 10
    deleted = 0
    async for msg in client.get_chat_history(message.chat.id, limit=jumlah):
        if not msg.service:
            await msg.delete()
            deleted += 1
    await message.reply(f"✅ {deleted} pesan dihapus!")

@PY.UBOT("purgeall")
@PY.TOP_CMD
async def purge_all(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    msg = await message.reply("⚠️ Hapus semua pesan? Ketik yes untuk konfirmasi")
    def check(m):
        return m.from_user.id == message.from_user.id and m.text.lower() == "yes"
    try:
        await client.wait_for_message(check, timeout=30)
        deleted = 0
        async for m in client.get_chat_history(message.chat.id, limit=100):
            if not m.service:
                await m.delete()
                deleted += 1
        await msg.edit(f"✅ {deleted} pesan dihapus!")
    except:
        await msg.edit("❌ Dibatalkan!")
