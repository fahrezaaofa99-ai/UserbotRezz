from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲 𝐑𝐞𝐚𝐥"
__HELP__ = """
<blockquote><b>💱 𝐂𝐮𝐫𝐫𝐞𝐧𝐜𝐲 𝐑𝐞𝐚𝐥</b>

 • <code>{0}usd</code> - USD to IDR
 • <code>{0}sgd</code> - SGD to IDR
 • <code>{0}myr</code> - MYR to IDR
 • <code>{0}eur</code> - EUR to IDR
 • <code>{0}gbp</code> - GBP to IDR</blockquote>
"""

def get_rate(from_curr, to_curr):
    try:
        r = requests.get(f"https://api.exchangerate-api.com/v4/latest/{from_curr}")
        return r.json()['rates'][to_curr]
    except:
        return None

@PY.UBOT("usd")
@PY.TOP_CMD
async def usd_to_idr(client, message):
    rate = get_rate("USD", "IDR")
    if rate:
        await message.reply(f"💵 1 USD = Rp{rate:,.0f}")
    else:
        await message.reply("❌ Gagal")

@PY.UBOT("sgd")
@PY.TOP_CMD
async def sgd_to_idr(client, message):
    rate = get_rate("SGD", "IDR")
    if rate:
        await message.reply(f"🇸🇬 1 SGD = Rp{rate:,.0f}")
    else:
        await message.reply("❌ Gagal")

@PY.UBOT("myr")
@PY.TOP_CMD
async def myr_to_idr(client, message):
    rate = get_rate("MYR", "IDR")
    if rate:
        await message.reply(f"🇲🇾 1 MYR = Rp{rate:,.0f}")
    else:
        await message.reply("❌ Gagal")

@PY.UBOT("eur")
@PY.TOP_CMD
async def eur_to_idr(client, message):
    rate = get_rate("EUR", "IDR")
    if rate:
        await message.reply(f"🇪🇺 1 EUR = Rp{rate:,.0f}")
    else:
        await message.reply("❌ Gagal")

@PY.UBOT("gbp")
@PY.TOP_CMD
async def gbp_to_idr(client, message):
    rate = get_rate("GBP", "IDR")
    if rate:
        await message.reply(f"🇬🇧 1 GBP = Rp{rate:,.0f}")
    else:
        await message.reply("❌ Gagal")
