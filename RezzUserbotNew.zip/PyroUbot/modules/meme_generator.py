from PyroUbot import *
import requests
import random

__MODULE__ = "𝐌𝐞𝐦𝐞 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫"
__HELP__ = """
<blockquote><b>😂 𝐌𝐞𝐦𝐞 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}meme</code> - Meme random dari reddit
 • <code>{0}memes</code> - Meme Indonesia random
 • <code>{0}memesearch &lt;kata></code> - Cari meme
 • <code>{0}dankmeme</code> - Meme dank
 • <code>{0}wholesome</code> - Meme wholesome
 • <code>{0}memesub &lt;subreddit></code> - Meme dari subreddit</blockquote>
"""

@PY.UBOT("meme")
@PY.TOP_CMD
async def meme_random(client, message):
    msg = await message.reply("🔍 Mencari meme...")
    try:
        r = requests.get("https://meme-api.com/gimme")
        if r.status_code == 200:
            data = r.json()
            await message.reply_photo(data['url'], caption=f"😂 {data['title']}\n⬆️ {data['ups']} upvotes")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("memes")
@PY.TOP_CMD
async def meme_indonesia(client, message):
    msg = await message.reply("🔍 Mencari meme indo...")
    try:
        r = requests.get("https://meme-api.com/gimme/indonesia")
        if r.status_code == 200:
            data = r.json()
            await message.reply_photo(data['url'], caption=f"😂 {data['title']}")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("memesearch")
@PY.TOP_CMD
async def meme_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .memesearch <kata>")
    msg = await message.reply("🔍 Mencari...")
    try:
        r = requests.get(f"https://meme-api.com/gimme/{args[1].replace(' ', '')}")
        if r.status_code == 200:
            data = r.json()
            if data.get('url'):
                await message.reply_photo(data['url'], caption=f"😂 {data['title']}")
                await msg.delete()
            else:
                await msg.edit("❌ Tidak ditemukan")
        else:
            await msg.edit("❌ Tidak ditemukan")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("dankmeme")
@PY.TOP_CMD
async def dank_meme(client, message):
    msg = await message.reply("🔍 Mencari dank meme...")
    try:
        r = requests.get("https://meme-api.com/gimme/dankmemes")
        if r.status_code == 200:
            data = r.json()
            await message.reply_photo(data['url'], caption=f"🔥 {data['title']}")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("wholesome")
@PY.TOP_CMD
async def wholesome_meme(client, message):
    msg = await message.reply("🔍 Mencari wholesome meme...")
    try:
        r = requests.get("https://meme-api.com/gimme/wholesomememes")
        if r.status_code == 200:
            data = r.json()
            await message.reply_photo(data['url'], caption=f"🤗 {data['title']}")
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("memesub")
@PY.TOP_CMD
async def meme_subreddit(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .memesub <subreddit>")
    msg = await message.reply("🔍 Mencari...")
    try:
        r = requests.get(f"https://meme-api.com/gimme/{args[1]}")
        if r.status_code == 200:
            data = r.json()
            if data.get('url'):
                await message.reply_photo(data['url'], caption=f"r/{args[1]}\n📌 {data['title']}")
                await msg.delete()
            else:
                await msg.edit("❌ Subreddit tidak ditemukan")
        else:
            await msg.edit("❌ Error")
    except:
        await msg.edit("❌ Error")
