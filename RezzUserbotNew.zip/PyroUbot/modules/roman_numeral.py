from PyroUbot import *

__MODULE__ = "𝐑𝐨𝐦𝐚𝐧"
__HELP__ = """
<blockquote><b>🏛️ 𝐑𝐨𝐦𝐚𝐧 𝐍𝐮𝐦𝐞𝐫𝐚𝐥</b>

 • <code>{0}roman &lt;angka></code> - Decimal ke Roman
 • <code>{0}deroman &lt;roman></code> - Roman ke Decimal</blockquote>
"""

def to_roman(num):
    val = [1000,900,500,400,100,90,50,40,10,9,5,4,1]
    sym = ["M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"]
    roman = ''
    for i in range(len(val)):
        count = num // val[i]
        roman += sym[i] * count
        num -= val[i] * count
    return roman

def from_roman(roman):
    roman_map = {'I':1, 'V':5, 'X':10, 'L':50, 'C':100, 'D':500, 'M':1000}
    num = 0
    for i in range(len(roman)):
        if i+1 < len(roman) and roman_map[roman[i]] < roman_map[roman[i+1]]:
            num -= roman_map[roman[i]]
        else:
            num += roman_map[roman[i]]
    return num

@PY.UBOT("roman")
@PY.TOP_CMD
async def to_roman_num(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .roman <angka>")
    try:
        angka = int(args[1])
        if angka > 3999:
            return await message.reply("❌ Maksimal 3999")
        roman = to_roman(angka)
        await message.reply(f"🏛️ {angka} = {roman}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("deroman")
@PY.TOP_CMD
async def from_roman_num(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .deroman <roman>")
    try:
        num = from_roman(args[1].upper())
        await message.reply(f"🏛️ {args[1].upper()} = {num}")
    except:
        await message.reply("❌ Error")
