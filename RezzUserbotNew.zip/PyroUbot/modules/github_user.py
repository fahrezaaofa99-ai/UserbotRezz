from PyroUbot import *
import requests

__MODULE__ = "𝐆𝐢𝐭𝐇𝐮𝐛"
__HELP__ = """
<blockquote><b>🐙 𝐆𝐢𝐭𝐇𝐮𝐛 𝐔𝐬𝐞𝐫</b>

 • <code>{0}github &lt;username></code> - Info user GitHub</blockquote>
"""

@PY.UBOT("github")
@PY.TOP_CMD
async def github_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .github <username>")
    msg = await message.reply("🐙 Mencari...")
    try:
        r = requests.get(f"https://api.github.com/users/{args[1]}")
        if r.status_code == 200:
            data = r.json()
            text = f"""
╭──〔 🐙 GITHUB USER 〕
│
│ 📌 {data.get('login', 'N/A')}
│ 👤 Name: {data.get('name', 'N/A')}
│ 📚 Repos: {data.get('public_repos', 0)}
│ 👥 Followers: {data.get('followers', 0)}
│ 📝 Bio: {data.get('bio', 'N/A')[:100]}
│
╰── ✨ GitHub ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ User tidak ditemukan")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")
