from PyroUbot import *
import requests

__MODULE__ = "𝐃𝐨𝐠𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🐕 𝐃𝐨𝐠 𝐅𝐚𝐜𝐭</b>

 • <code>{0}dogfact</code> - Fakta tentang anjing</blockquote>
"""

@PY.UBOT("dogfact")
@PY.TOP_CMD
async def dog_fact(client, message):
    try:
        r = requests.get("https://dogapi.dog/api/v2/facts")
        if r.status_code == 200:
            fact = r.json()['data'][0]['attributes']['body']
            await message.reply(f"🐕 **Dog Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
