from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐚𝐧𝐝𝐖𝐢𝐤𝐢"
__HELP__ = """
<blockquote><b>📚 𝐑𝐚𝐧𝐝𝐨𝐦 𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚</b>

 • <code>{0}randomwiki</code> - Artikel Wikipedia random</blockquote>
"""

@PY.UBOT("randomwiki")
@PY.TOP_CMD
async def random_wiki(client, message):
    msg = await message.reply("📚 Mencari artikel random...")
    try:
        r = requests.get("https://en.wikipedia.org/api/rest_v1/page/random/summary")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"📚 **{data['title']}**\n\n{data['extract'][:500]}...")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
