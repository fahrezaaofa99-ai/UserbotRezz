from PyroUbot import *
import random

__MODULE__ = "𝐂𝐨𝐢𝐧"
__HELP__ = """
<blockquote><b>🪙 𝐂𝐨𝐢𝐧 𝐅𝐥𝐢𝐩</b>

 • <code>{0}coin</code> - Lempar koin</blockquote>
"""

@PY.UBOT("coin")
@PY.TOP_CMD
async def coin_flip(client, message):
    hasil = random.choice(["HEADS 🪙", "TAILS 🪙"])
    await message.reply(f"🪙 **Hasil lemparan:** {hasil}")
