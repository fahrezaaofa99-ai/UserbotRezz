from PyroUbot import *
import requests
import os

__MODULE__ = "𝐒𝐜𝐫𝐞𝐞𝐧𝐬𝐡𝐨𝐭"
__HELP__ = """
<blockquote><b>📸 𝐒𝐜𝐫𝐞𝐞𝐧𝐬𝐡𝐨𝐭 𝐖𝐞𝐛</b>

 • <code>{0}ss &lt;url></code> - Screenshot website
 • <code>{0}ssfull &lt;url></code> - Screenshot full page
 • <code>{0}ssmobile &lt;url></code> - Screenshot mode mobile</blockquote>
"""

@PY.UBOT("ss")
@PY.TOP_CMD
async def screenshot_web(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .ss <url>\n\nContoh: .ss https://google.com")
    
    msg = await message.reply("📸 Mengambil screenshot...")
    
    try:
        url = args[1]
        if not url.startswith("http"):
            url = "https://" + url
        
        # API screenshot (gak perlu Selenium)
        api_url = f"https://image.thum.io/get/width/800/crop/800/maxAge/1/{url}"
        
        await msg.edit("📤 Mengirim screenshot...")
        await client.send_photo(
            message.chat.id,
            api_url,
            caption=f"📸 **Screenshot:** {url}",
            reply_to_message_id=message.id
        )
        await msg.delete()
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("ssfull")
@PY.TOP_CMD
async def screenshot_full(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .ssfull <url>")
    
    msg = await message.reply("📸 Mengambil screenshot full page...")
    
    try:
        url = args[1]
        if not url.startswith("http"):
            url = "https://" + url
        
        # API screenshot full page
        api_url = f"https://image.thum.io/get/width/1024/maxAge/1/{url}"
        
        await msg.edit("📤 Mengirim screenshot...")
        await client.send_photo(
            message.chat.id,
            api_url,
            caption=f"📸 **Screenshot Full Page:** {url}",
            reply_to_message_id=message.id
        )
        await msg.delete()
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("ssmobile")
@PY.TOP_CMD
async def screenshot_mobile(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .ssmobile <url>")
    
    msg = await message.reply("📱 Mengambil screenshot mode mobile...")
    
    try:
        url = args[1]
        if not url.startswith("http"):
            url = "https://" + url
        
        # API screenshot mobile
        api_url = f"https://image.thum.io/get/width/375/height/667/maxAge/1/{url}"
        
        await msg.edit("📤 Mengirim screenshot...")
        await client.send_photo(
            message.chat.id,
            api_url,
            caption=f"📱 **Screenshot Mobile:** {url}",
            reply_to_message_id=message.id
        )
        await msg.delete()
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

