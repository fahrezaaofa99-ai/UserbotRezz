from PyroUbot import *
import requests, base64, asyncio
from datetime import datetime

__MODULE__ = "𝐒𝐩𝐨𝐭𝐢𝐟𝐲 𝐌𝐮𝐬𝐢𝐜"
__HELP__ = """
<blockquote><b>🎵 𝐒𝐩𝐨𝐭𝐢𝐟𝐲 𝐌𝐮𝐬𝐢𝐜</b>

<b>🔍 𝐂𝐀𝐑𝐈 𝐋𝐀𝐆𝐔</b>
 • <code>{0}lagu &lt;judul></code> - Cari lagu
 • <code>{0}artist &lt;nama></code> - Cari artist
 • <code>{0}album &lt;judul></code> - Cari album

<b>📋 𝐈𝐍𝐅𝐎</b>
 • <code>{0}infotrack &lt;judul></code> - Info lagu
 • <code>{0}infoartis &lt;nama></code> - Info artist
 • <code>{0}topglobal</code> - Top global
 • <code>{0}topindo</code> - Top Indonesia</blockquote>
"""

TOKEN = "BQAYA3_MMbanpv63I-vMj4yEDHtgGbM7ZTiw5-ux_23_fznDvRiI97S1QENjNNiTliGgat6PsrhUZ6zIEP9rS0lO5FjPLQDRs6tujnnyJu5_zz0nraq8MncflkzkvweAjtmHblE0fTo"

def spotify_req(endpoint, params=None):
    headers = {"Authorization": f"Bearer {TOKEN}"}
    try:
        r = requests.get(f"https://api.spotify.com/v1/{endpoint}", headers=headers, params=params, timeout=10)
        return r.json() if r.status_code == 200 else None
    except:
        return None

@PY.UBOT("lagu")
@PY.TOP_CMD
async def lagu(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .lagu <judul>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "track", "limit": 5})
    if not data or 'tracks' not in data:
        return await msg.edit("❌ Tidak ditemukan")
    text = "🎵 **HASIL PENCARIAN**\n\n"
    for i, t in enumerate(data['tracks']['items'], 1):
        dur = t['duration_ms'] // 60000
        det = (t['duration_ms'] % 60000) // 1000
        artis = ', '.join([a['name'] for a in t['artists']])
        text += f"{i}. {t['name']}\n   👤 {artis}\n   ⏱️ {dur}:{det:02d}\n\n"
    await msg.edit(text)

@PY.UBOT("infotrack")
@PY.TOP_CMD
async def infotrack(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .infotrack <judul>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "track", "limit": 1})
    if not data or not data['tracks']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    t = data['tracks']['items'][0]
    dur = t['duration_ms'] // 60000
    det = (t['duration_ms'] % 60000) // 1000
    artis = ', '.join([a['name'] for a in t['artists']])
    text = f"""
╭──〔 🎵 INFO TRACK 〕
│
│ 📌 {t['name']}
│ 👤 {artis}
│ 💿 {t['album']['name']}
│ ⏱️ {dur}:{det:02d}
│ 📊 Popularitas: {t['popularity']}%
│
╰── ✨ Spotify ✨"""
    await msg.edit(text)

@PY.UBOT("artist")
@PY.TOP_CMD
async def artist(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .artist <nama>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "artist", "limit": 3})
    if not data or not data['artists']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    text = "🎤 **HASIL ARTIST**\n\n"
    for i, a in enumerate(data['artists']['items'], 1):
        text += f"{i}. {a['name']}\n   👥 Followers: {a['followers']['total']:,}\n   📊 Pop: {a['popularity']}%\n\n"
    await msg.edit(text)

@PY.UBOT("infoartis")
@PY.TOP_CMD
async def infoartis(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .infoartis <nama>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "artist", "limit": 1})
    if not data or not data['artists']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    a = data['artists']['items'][0]
    genre = ', '.join(a.get('genres', [])[:3]) or 'Tidak ada'
    text = f"""
╭──〔 🎤 INFO ARTIST 〕
│
│ 📌 {a['name']}
│ 👥 Followers: {a['followers']['total']:,}
│ 📊 Popularitas: {a['popularity']}%
│ 🎸 Genre: {genre}
│
╰── ✨ Spotify ✨"""
    await msg.edit(text)

@PY.UBOT("topglobal")
@PY.TOP_CMD
async def topglobal(client, message):
    msg = await message.reply("🔍 Mengambil top global...")
    data = spotify_req("playlists/37i9dQZEVXbMDoHDwVN2tF/tracks", {"limit": 10})
    if not data:
        return await msg.edit("❌ Gagal")
    text = "🌍 **TOP 10 GLOBAL**\n\n"
    for i, item in enumerate(data['items'][:10], 1):
        t = item['track']
        artis = ', '.join([a['name'] for a in t['artists']])
        text += f"{i}. {t['name']} - {artis}\n"
    await msg.edit(text)

@PY.UBOT("topindo")
@PY.TOP_CMD
async def topindo(client, message):
    msg = await message.reply("🔍 Mengambil top Indonesia...")
    data = spotify_req("playlists/37i9dQZEVXbJWfQ1hT4fsE/tracks", {"limit": 10})
    if not data:
        return await msg.edit("❌ Gagal")
    text = "🇮🇩 **TOP 10 INDONESIA**\n\n"
    for i, item in enumerate(data['items'][:10], 1):
        t = item['track']
        artis = ', '.join([a['name'] for a in t['artists']])
        text += f"{i}. {t['name']} - {artis}\n"
    await msg.edit(text)

@PY.UBOT("album")
@PY.TOP_CMD
async def album(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .album <judul>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "album", "limit": 3})
    if not data or not data['albums']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    text = "💿 **HASIL ALBUM**\n\n"
    for i, a in enumerate(data['albums']['items'], 1):
        artis = ', '.join([ar['name'] for ar in a['artists']])
        text += f"{i}. {a['name']}\n   👤 {artis}\n   🎵 {a['total_tracks']} track\n\n"
    await msg.edit(text)

@PY.UBOT("infoalbum")
@PY.TOP_CMD
async def infoalbum(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .infoalbum <judul>")
    msg = await message.reply(f"🔍 Mencari...")
    data = spotify_req("search", {"q": args[1], "type": "album", "limit": 1})
    if not data or not data['albums']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    a = data['albums']['items'][0]
    artis = ', '.join([ar['name'] for ar in a['artists']])
    text = f"""
╭──〔 💿 INFO ALBUM 〕
│
│ 📌 {a['name']}
│ 👤 {artis}
│ 🎵 {a['total_tracks']} track
│ 📅 {a.get('release_date', 'Unknown')}
│
╰── ✨ Spotify ✨"""
    await msg.edit(text)

@PY.UBOT("rekom")
@PY.TOP_CMD
async def rekom(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .rekom <judul>")
    msg = await message.reply(f"🔍 Mencari rekomendasi...")
    data = spotify_req("search", {"q": args[1], "type": "track", "limit": 1})
    if not data or not data['tracks']['items']:
        return await msg.edit("❌ Tidak ditemukan")
    track_id = data['tracks']['items'][0]['id']
    reco = spotify_req("recommendations", {"seed_tracks": track_id, "limit": 10})
    if not reco:
        return await msg.edit("❌ Gagal")
    text = f"🎧 **REKOMENDASI**\n📌 Berdasarkan: {data['tracks']['items'][0]['name']}\n\n"
    for i, t in enumerate(reco['tracks'][:10], 1):
        artis = ', '.join([a['name'] for a in t['artists']])
        text += f"{i}. {t['name']} - {artis}\n"
    await msg.edit(text)

@PY.UBOT("lirik")
@PY.TOP_CMD
async def lirik(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .lirik <judul>")
    msg = await message.reply(f"🔍 Mencari lirik...")
    try:
        r = requests.get(f"https://api.lyrics.ovh/v1/{args[1].replace(' ', '%20')}", timeout=10)
        if r.status_code == 200:
            lirik = r.json().get('lyrics', 'Tidak ditemukan')
            if len(lirik) > 4000:
                lirik = lirik[:4000] + "\n\n... (terpotong)"
            await msg.edit(f"📝 **LIRIK**\n🎵 {args[1]}\n\n{lirik}")
        else:
            await msg.edit("❌ Lirik tidak ditemukan")
    except:
        await msg.edit("❌ Gagal mengambil lirik")
