from PyroUbot import *

__MODULE__ = "𝐆𝐚𝐧𝐣𝐢𝐥𝐆𝐞𝐧𝐚𝐩"
__HELP__ = """
<blockquote><b>🔢 𝐆𝐚𝐧𝐣𝐢𝐥/𝐆𝐞𝐧𝐚𝐩</b>

 • <code>{0}gg &lt;angka></code> - Cek ganjil genap</blockquote>
"""

@PY.UBOT("gg")
@PY.TOP_CMD
async def ganjil_genap_check(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .gg <angka>")
    angka = int(args[1])
    if angka % 2 == 0:
        await message.reply(f"🔢 {angka} adalah **GENAP**")
    else:
        await message.reply(f"🔢 {angka} adalah **GANJIL**")
