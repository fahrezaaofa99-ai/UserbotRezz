from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>📢 𝐑𝐚𝐧𝐝𝐨𝐦 𝐅𝐚𝐜𝐭</b>

 • <code>{0}fakta</code> - Fakta random</blockquote>
"""

@PY.UBOT("fakta")
@PY.TOP_CMD
async def random_fact(client, message):
    try:
        r = requests.get("https://uselessfacts.jsph.pl/random.json?language=en")
        if r.status_code == 200:
            fact = r.json()['text']
            await message.reply(f"📢 **Fakta Random:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
