from PyroUbot import *
import random

__MODULE__ = "𝐅𝐥𝐢𝐩𝐂𝐨𝐢𝐧"
__HELP__ = """
<blockquote><b>🪙 𝐅𝐥𝐢𝐩 𝐂𝐨𝐢𝐧</b>

 • <code>{0}flip</code> - Lempar koin</blockquote>
"""

@PY.UBOT("flip")
@PY.TOP_CMD
async def flip_coin(client, message):
    hasil = random.choice(["HEADS 🪙", "TAILS 🪙"])
    await message.reply(f"🪙 **Hasil:** {hasil}")
