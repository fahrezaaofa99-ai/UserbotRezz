from PyroUbot import *
import requests

__MODULE__ = "𝐀𝐝𝐯𝐢𝐜𝐞"
__HELP__ = """
<blockquote><b>💡 𝐑𝐚𝐧𝐝𝐨𝐦 𝐀𝐝𝐯𝐢𝐜𝐞</b>

 • <code>{0}advice</code> - Nasihat random</blockquote>
"""

@PY.UBOT("advice")
@PY.TOP_CMD
async def random_advice(client, message):
    try:
        r = requests.get("https://api.adviceslip.com/advice")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"💡 **Advice:**\n\n{data['slip']['advice']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
