from PyroUbot import *
import re

__MODULE__ = "𝐏𝐚𝐬𝐬𝐒𝐭𝐫𝐞𝐧𝐠𝐭𝐡"
__HELP__ = """
<blockquote><b>🔐 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 𝐒𝐭𝐫𝐞𝐧𝐠𝐭𝐡</b>

 • <code>{0}passcheck &lt;password></code> - Cek kekuatan password</blockquote>
"""

@PY.UBOT("passcheck")
@PY.TOP_CMD
async def password_strength(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .passcheck <password>")
    pwd = args[1]
    score = 0
    if len(pwd) >= 8: score += 1
    if re.search(r'[A-Z]', pwd): score += 1
    if re.search(r'[a-z]', pwd): score += 1
    if re.search(r'[0-9]', pwd): score += 1
    if re.search(r'[!@#$%^&*]', pwd): score += 1
    
    if score <= 2: strength = "Lemah 🔴"
    elif score <= 4: strength = "Sedang 🟡"
    else: strength = "Kuat 🟢"
    
    await message.reply(f"🔐 **Password Strength:** {strength}\n📊 Score: {score}/5")
