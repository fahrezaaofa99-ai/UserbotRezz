from PyroUbot import *
from datetime import datetime

__MODULE__ = "𝐀𝐠𝐞"
__HELP__ = """
<blockquote><b>📅 𝐀𝐠𝐞 𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫</b>

 • <code>{0}age &lt;DD-MM-YYYY></code> - Hitung umur
 • <code>{0}days &lt;DD-MM-YYYY></code> - Hari ke target
 • <code>{0}weekday &lt;DD-MM-YYYY></code> - Hari apa</blockquote>
"""

@PY.UBOT("age")
@PY.TOP_CMD
async def age_calc(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .age DD-MM-YYYY")
    try:
        lahir = datetime.strptime(args[1], "%d-%m-%Y")
        today = datetime.now()
        umur = today.year - lahir.year - ((today.month, today.day) < (lahir.month, lahir.day))
        await message.reply(f"📅 Umur: {umur} tahun")
    except:
        await message.reply("❌ Format salah! Contoh: 15-08-2000")

@PY.UBOT("days")
@PY.TOP_CMD
async def days_to(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .days DD-MM-YYYY")
    try:
        target = datetime.strptime(args[1], "%d-%m-%Y")
        now = datetime.now()
        selisih = target - now
        await message.reply(f"📅 {selisih.days} hari lagi ke {args[1]}")
    except:
        await message.reply("❌ Format salah")

@PY.UBOT("weekday")
@PY.TOP_CMD
async def weekday(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .weekday DD-MM-YYYY")
    try:
        tgl = datetime.strptime(args[1], "%d-%m-%Y")
        hari = tgl.strftime("%A")
        await message.reply(f"📅 {args[1]} adalah hari {hari}")
    except:
        await message.reply("❌ Format salah")
