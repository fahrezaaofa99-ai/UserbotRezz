from PyroUbot import *
import requests
from datetime import datetime

__MODULE__ = "𝐐𝐨𝐭𝐃"
__HELP__ = """
<blockquote><b>💬 𝐐𝐮𝐨𝐭𝐞 𝐨𝐟 𝐭𝐡𝐞 𝐃𝐚𝐲</b>

 • <code>{0}qotd</code> - Quote hari ini</blockquote>
"""

@PY.UBOT("qotd")
@PY.TOP_CMD
async def quote_of_day(client, message):
    try:
        r = requests.get("https://zenquotes.io/api/today")
        if r.status_code == 200:
            data = r.json()
            q = data[0]
            await message.reply(f"💬 **Quote of the Day**\n\n{q['q']}\n\n— {q['a']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
