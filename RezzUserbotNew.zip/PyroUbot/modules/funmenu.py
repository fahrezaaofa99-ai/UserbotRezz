# Nama file: /root/RezzUserbot/PyroUbot/modules/fun.py
# Fitur: Fun commands buat becanda

from PyroUbot import *
import random
import requests
from datetime import datetime

__MODULE__ = "ꜰᴜɴ"
__HELP__ = """
<blockquote><b>🎭 FUN COMMANDS</b>

<b>😂 JOKES</b>
 • <code>{0}bapak</code> - Jokes bapak-bapak random
 • <code>{0}dad</code> - Dad jokes (english)
 • <code>{0}canda</code> - Candaan random
 • <code>{0}lawak</code> - Lawakan receh

<b>🔮 FORTUNE</b>
 • <code>{0}yesno</code> - Jawaban random yes/no
 • <code>{0}apakah</code> [pertanyaan] - Tanya random
   Contoh: <code>{0}apakah gue ganteng</code>
 • <code>{0}rate</code> [sesuatu] - Rating random 0-100%
   Contoh: <code>{0}rate kegantengan lu</code>

<b>💬 TEXT STYLE</b>
 • <code>{0}clown</code> [teks] - Ubah jadi 🤡 style
 • <code>{0}zalgo</code> [teks] - Ubah jadi text horror
 • <code>{0}vapor</code> [teks] - Vaporwave style
 • <code>{0}small</code> [teks] - Huruf kecil semua
 • <code>{0}big</code> [teks] - Huruf besar semua

<b>🎲 RANDOM</b>
 • <code>{0}coin</code> - Flip koin (head/tail)
 • <code>{0}roll</code> - Roll dadu (1-6)
 • <code>{0}8ball</code> [pertanyaan] - Magic 8 ball

<b>👽 FAKTA</b>
 • <code>{0}fakta</code> - Fakta random aneh
 • <code>{0}truth</code> - Random truth or dare (truth)
 • <code>{0}dare</code> - Random truth or dare (dare)
 • <code>{0}would</code> - Would you rather?

<b>🖼️ MEME</b>
 • <code>{0}meme</code> - Random meme dari internet
 • <code>{0}doge</code> - Doge meme
 • <code>{0}cat</code> - Kucing lucu</blockquote>
"""

# Database jokes lokal
jokes_bapak = [
    "Gue mandi pake air? Iya, air... mata bundir",
    "Kalo naik motor sama bapak, yang boncenger pegang apa? Pegang... uang jajan",
    "Makan apa yang bikin capek? Makan... hati lo",
    "Kucing apa yang bisa bikin orang stress? Kucing... IU",
    "Kenapa ayam kalo berkokok matanya merem? Soalnya udah hapal teksnya",
    "Minuman apa yang paling sakti? Air... muka lo",
    "Kenapa orang kalo ngomong suka megang-megang? Soalnya kalo megang-megang orang, bisa kena pelecehan",
    "Tau gak kenapa ikan asin satu-satunya ikan yang jomblo? Soalnya dia 'ikan asin' (aku masih single)",
    "Kenapa anak kodok suka lompat-lompat? Soalnya bapaknya juga suka lompat-lompat, apalagi kalo digoreng",
    "Minuman apa yang paling sehat? Air... putih, soalnya kalo air hitam mah kopi"
]

jokes_english = [
    "Why don't scientists trust atoms? Because they make up everything!",
    "What do you call a fake noodle? An impasta!",
    "Why did the scarecrow win an award? Because he was outstanding in his field!",
    "I told my wife she should embrace her mistakes. She gave me a hug.",
    "Why don't eggs tell jokes? They'd crack each other up!",
    "I'm reading a book on anti-gravity. It's impossible to put down!",
    "Did you hear about the mathematician who's afraid of negative numbers? He'll stop at nothing to avoid them.",
    "What do you get when you cross a snowman and a vampire? Frostbite!",
    "Why did the bicycle fall over? Because it was two-tired!",
    "How does a penguin build its house? Igloos it together!"
]

facts = [
    "Kamu menghirup 0.000000000000000000000000001% kentut Napoleon setiap kali bernapas",
    "Semut selalu jatuh ke kanan kalau diberi alkohol",
    "Kucing bisa menghasilkan listrik 0.0000001 volt saat digelus",
    "Otak kamu lebih aktif di malam hari daripada siang hari",
    "Mendengkur bisa mencapai 80 desibel, setara dengan suara bor",
    "Bayi terlahir dengan 300 tulang, orang dewasa cuma 206",
    "Lidah manusia punya sidik jari yang unik",
    "Senyum membakar 26 kalori, tapi ketawa bakar 250 kalori/jam",
    "Gajah satu-satunya mamalia yang gabisa lompat",
    "Bangkai manusia bisa terbakar sendiri kalau kondisi tertentu"
]

would_questions = [
    "Would you rather be able to fly or be invisible?",
    "Would you rather live 100 years in the past or 100 years in the future?",
    "Would you rather be famous but unhappy, or unknown but happy?",
    "Would you rather have a rewind button or a pause button in your life?",
    "Would you rather be able to talk to animals or speak all human languages?",
    "Would you rather never use social media again or never watch TV again?",
    "Would you rather have unlimited money or unlimited time?",
    "Would you rather know when you die or how you die?",
    "Would you rather be too hot or too cold for the rest of your life?",
    "Would you rather lose your sense of smell or your sense of taste?"
]

# ==================== JOKES ====================

@PY.UBOT("bapak")
@PY.TOP_CMD
async def joke_bapak(client, message):
    """Jokes bapak-bapak"""
    joke = random.choice(jokes_bapak)
    await message.reply(f"<b>😂 JOKES BAPAK-BAPAK</b>\n\n{joke}")

@PY.UBOT("dad")
@PY.TOP_CMD
async def joke_dad(client, message):
    """Dad jokes english"""
    joke = random.choice(jokes_english)
    await message.reply(f"<b>😂 DAD JOKES</b>\n\n{joke}")

@PY.UBOT("canda")
@PY.TOP_CMD
async def canda_random(client, message):
    """Candaan random"""
    canda = [
        "Lo tau nggak? Kalau lo baca pesan ini, lo lagi baca pesan",
        "Gue punya bensin, lo punya api? Kalo digabung jadi... kebakaran",
        "Kenapa ayam nyebrang jalan? Mau ke warung",
        "Orang apa yang paling susah diprediksi? Orang... tua",
        "Gue punya kucing, lo punya kucing? Kalo digabung jadi... kucingan",
        "Lo tau nggak kenapa air laut asin? Karena ikannya pada keringetan",
        "Apa bedanya lo sama kompor? Kalo kompor nyala bikin masak, kalo lo nyala bikin... malu",
        "Gue mau nanya, kalo lo jawab berarti lo tau, kalo lo nggak jawab berarti lo nggak tau",
        "Kenapa orang kalo tidur matanya merem? Karena kalo merem kan jadi gelap",
        "Lo tau nggak kenapa pohon kelapa tinggi? Karena kalo pendek namanya pohon kacang"
    ]
    await message.reply(f"<b>😂 CANDAAAN</b>\n\n{random.choice(canda)}")

@PY.UBOT("lawak")
@PY.TOP_CMD
async def lawak_receh(client, message):
    """Lawakan receh"""
    lawak = [
        "Mobil apa yang bikin keringetan? Mobil... balap",
        "Apa bedanya lo sama sepatu? Kalo sepatu bisa dirombak, kalo lo... dirombak juga sih",
        "Kenapa kucing suka makan ikan? Karena dia kucing",
        "Gelas apa yang paling kecil? Gelas... kecil",
        "Orang apa yang paling kuat? Orang... tua",
        "Kenapa HP harus diisi? Karena kalo kosong, gabisa dipake",
        "Apa itu SUKA? Sampai Ujung Kakinya Akupun Suka",
        "Lo tau nggak bahasa inggrisnya 'nasi uduk'? Rice... duduk",
        "Kenapa orang kalo liat duit senyum? Karena senyum itu ibadah",
        "Apa bahasa jepangnya 'makan'? Tak... makan"
    ]
    await message.reply(f"<b>😂 LAWAK RECEH</b>\n\n{random.choice(lawak)}")

# ==================== FORTUNE ====================

@PY.UBOT("yesno")
@PY.TOP_CMD
async def yes_no(client, message):
    """Jawaban random yes/no"""
    answers = ["✅ Yes", "❌ No", "🤔 Maybe", "🔥 Definitely yes", "💀 Definitely no", "😏 Ask again later"]
    await message.reply(f"<b>🔮 YES/NO</b>\n\n{random.choice(answers)}")

@PY.UBOT("apakah")
@PY.TOP_CMD
async def apakah(client, message):
    """Tanya random"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>apakah gue ganteng</code>")
    
    answers = [
        "Iya", "Tidak", "Mungkin", "Bisa jadi", "Jelas banget", 
        "Gak mungkin lah", "Lo pikir?", "YNTKTS", "Ask your mom",
        "Menurut lo?", "100% iya", "0%", "50:50", "Coba tanya lagi nanti"
    ]
    
    question = message.text.split(None, 1)[1]
    await message.reply(
        f"<b>🔮 APAKAH</b>\n\n"
        f"Pertanyaan: {question}\n"
        f"Jawaban: <b>{random.choice(answers)}</b>"
    )

@PY.UBOT("rate")
@PY.TOP_CMD
async def rate_random(client, message):
    """Rating random"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>rate kegantengan lu</code>")
    
    rate = random.randint(0, 100)
    thing = message.text.split(None, 1)[1]
    
    emoji = "💩" if rate < 20 else "😐" if rate < 40 else "👍" if rate < 60 else "🔥" if rate < 80 else "💯"
    
    await message.reply(
        f"<b>📊 RATING</b>\n\n"
        f"{thing}\n"
        f"{emoji} <b>{rate}%</b>"
    )

# ==================== TEXT STYLE ====================

@PY.UBOT("clown")
@PY.TOP_CMD
async def clown_style(client, message):
    """Ubah jadi 🤡 style"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>clown lu jelek</code>")
    
    text = message.text.split(None, 1)[1]
    
    # Alternating caps 🤡 style
    result = ""
    for i, char in enumerate(text):
        if i % 2 == 0:
            result += char.lower()
        else:
            result += char.upper()
    
    await message.reply(f"<b>🤡 CLOWN STYLE</b>\n\n{result}")

@PY.UBOT("zalgo")
@PY.TOP_CMD
async def zalgo_text(client, message):
    """Ubah jadi text horror"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>zalgo hello</code>")
    
    text = message.text.split(None, 1)[1]
    
    # Zalgo combining characters
    zalgo_chars = [
        '\u0300', '\u0301', '\u0302', '\u0303', '\u0304', '\u0305',
        '\u0306', '\u0307', '\u0308', '\u0309', '\u030A', '\u030B',
        '\u030C', '\u030D', '\u030E', '\u030F', '\u0310', '\u0311'
    ]
    
    result = ""
    for char in text:
        result += char
        # Tambah random combining characters
        for _ in range(random.randint(0, 3)):
            result += random.choice(zalgo_chars)
    
    await message.reply(f"<b>👻 ZALGO TEXT</b>\n\n{result}")

@PY.UBOT("vapor")
@PY.TOP_CMD
async def vaporwave(client, message):
    """Vaporwave style"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>vapor hello</code>")
    
    text = message.text.split(None, 1)[1].upper()
    
    # Fullwidth characters
    result = ""
    for char in text:
        if 'A' <= char <= 'Z':
            result += chr(ord(char) + 0xFEE0)
        elif '0' <= char <= '9':
            result += chr(ord(char) + 0xFEE0)
        else:
            result += char
    
    await message.reply(f"<b>🌆 VAPORWAVE</b>\n\n{result}")

@PY.UBOT("small")
@PY.TOP_CMD
async def small_text(client, message):
    """Small text"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>small hello</code>")
    
    text = message.text.split(None, 1)[1]
    
    # Small caps (simplified)
    small_map = {
        'a': 'ᵃ', 'b': 'ᵇ', 'c': 'ᶜ', 'd': 'ᵈ', 'e': 'ᵉ', 'f': 'ᶠ', 'g': 'ᵍ',
        'h': 'ʰ', 'i': 'ⁱ', 'j': 'ʲ', 'k': 'ᵏ', 'l': 'ˡ', 'm': 'ᵐ', 'n': 'ⁿ',
        'o': 'ᵒ', 'p': 'ᵖ', 'q': 'q', 'r': 'ʳ', 's': 'ˢ', 't': 'ᵗ', 'u': 'ᵘ',
        'v': 'ᵛ', 'w': 'ʷ', 'x': 'ˣ', 'y': 'ʸ', 'z': 'ᶻ'
    }
    
    result = ""
    for char in text.lower():
        result += small_map.get(char, char)
    
    await message.reply(f"<b>🔡 SMALL TEXT</b>\n\n{result}")

@PY.UBOT("big")
@PY.TOP_CMD
async def big_text(client, message):
    """Big text"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>big hello</code>")
    
    text = message.text.split(None, 1)[1]
    
    # BIG TEXT
    await message.reply(f"<b>🔠 BIG TEXT</b>\n\n{text.upper()}")

# ==================== RANDOM ====================

@PY.UBOT("coin")
@PY.TOP_CMD
async def flip_coin(client, message):
    """Flip koin"""
    result = random.choice(["🪙 HEAD", "🪙 TAIL"])
    await message.reply(f"<b>🪙 FLIP COIN</b>\n\n{result}")

@PY.UBOT("roll")
@PY.TOP_CMD
async def roll_dice(client, message):
    """Roll dadu"""
    dice = random.randint(1, 6)
    dice_emoji = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"][dice-1]
    await message.reply(f"<b>🎲 ROLL DICE</b>\n\n{dice_emoji} {dice}")

@PY.UBOT("8ball")
@PY.TOP_CMD
async def magic_8ball(client, message):
    """Magic 8 ball"""
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>8ball apakah gue ganteng</code>")
    
    answers = [
        "🎱 It is certain",
        "🎱 It is decidedly so",
        "🎱 Without a doubt",
        "🎱 Yes definely",
        "🎱 You may rely on it",
        "🎱 As I see it, yes",
        "🎱 Most likely",
        "🎱 Outlook good",
        "🎱 Yes",
        "🎱 Signs point to yes",
        "🎱 Reply hazy, try again",
        "🎱 Ask again later",
        "🎱 Better not tell you now",
        "🎱 Cannot predict now",
        "🎱 Concentrate and ask again",
        "🎱 Don't count on it",
        "🎱 My reply is no",
        "🎱 My sources say no",
        "🎱 Outlook not so good",
        "🎱 Very doubtful"
    ]
    
    question = message.text.split(None, 1)[1]
    await message.reply(
        f"<b>🎱 MAGIC 8 BALL</b>\n\n"
        f"Q: {question}\n"
        f"A: {random.choice(answers)}"
    )

# ==================== FAKTA ====================

@PY.UBOT("fakta")
@PY.TOP_CMD
async def random_fact(client, message):
    """Fakta random"""
    fact = random.choice(facts)
    await message.reply(f"<b>👽 FAKTA UNIK</b>\n\n{fact}")

@PY.UBOT("truth")
@PY.TOP_CMD
async def truth_random(client, message):
    """Random truth"""
    truths = [
        "Apa hal paling memalukan yang pernah kamu alami?",
        "Siapa crush kamu sekarang?",
        "Kapan terakhir kali kamu nangis? Kenapa?",
        "Apa ketakutan terbesar kamu?",
        "Apa hal terbodoh yang pernah kamu lakukan karena cinta?",
        "Siapa orang yang paling kamu benci? Kenapa?",
        "Apa rahasia terbesar yang belum pernah kamu ceritakan ke siapa pun?",
        "Kamu pernah ngintip orang gak?",
        "Apa mimpi teraneh yang pernah kamu alami?",
        "Kamu pernah suka sama temen sendiri?",
        "Apa kebiasaan terburuk kamu?",
        "Kamu pernah bohong sama orang tua? Tentang apa?",
        "Apa hal yang paling kamu sesali?",
        "Kamu pernah nyuri sesuatu gak?",
        "Siapa artis yang kamu anggap menarik?"
    ]
    await message.reply(f"<b>🤔 TRUTH</b>\n\n{random.choice(truths)}")

@PY.UBOT("dare")
@PY.TOP_CMD
async def dare_random(client, message):
    """Random dare"""
    dares = [
        "Kirim pesan random ke mantan kamu",
        "Post selfie dengan wajah paling jelek",
        "Chat crush kamu 'aku suka kamu'",
        "Telpon orang tua bilang 'aku hamil/nikah'",
        "Makan cabe rawit 5 biji langsung",
        "Sebutkan 3 hal positif tentang orang di sebelah kiri kamu",
        "Kirim voice note nyanyiin lagu anak-anak",
        "Ganti profil picture dengan foto random selama 1 jam",
        "Follow akun Instagram random",
        "Chat admin grup pake bahasa alien",
        "Sumpah serapah pake bahasa daerah selama 1 menit",
        "Bikin status WA pake foto selfie sekarang",
        "Kirim pesan ke bestie 'utang 1 juta dong'",
        "Sebutin 5 mantan kamu (kalo ada)",
        "Ceritain pengalaman paling awkward dalam hidup"
    ]
    await message.reply(f"<b>😈 DARE</b>\n\n{random.choice(dares)}")

@PY.UBOT("would")
@PY.TOP_CMD
async def would_rather(client, message):
    """Would you rather"""
    question = random.choice(would_questions)
    await message.reply(f"<b>🤔 WOULD YOU RATHER</b>\n\n{question}")

# ==================== MEME ====================

@PY.UBOT("meme")
@PY.TOP_CMD
async def random_meme(client, message):
    """Random meme dari internet"""
    msg = await message.reply("🔍 Mencari meme...")
    
    try:
        # Pake meme API
        response = requests.get("https://meme-api.com/gimme", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            meme_url = data['url']
            title = data['title']
            
            await msg.delete()
            
            await client.send_photo(
                chat_id=message.chat.id,
                photo=meme_url,
                caption=f"<b>😂 MEME</b>\n\n{title}",
                reply_to_message_id=message.id
            )
        else:
            # Fallback ke meme lokal
            await msg.edit(
                "<b>😂 MEME LOKAL</b>\n\n"
                "https://i.imgur.com/1.jpg\n"
                "https://i.imgur.com/2.jpg\n"
                "https://i.imgur.com/3.jpg\n\n"
                "<i>API error, coba lagi nanti</i>"
            )
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("doge")
@PY.TOP_CMD
async def doge_meme(client, message):
    """Doge meme"""
    doge_urls = [
        "https://i.imgur.com/4VJZv.jpg",
        "https://i.imgur.com/MPj0c.jpg",
        "https://i.imgur.com/nVB1Q.jpg",
        "https://i.imgur.com/7CzA8.jpg",
        "https://i.imgur.com/LG9Qx.jpg"
    ]
    
    await client.send_photo(
        chat_id=message.chat.id,
        photo=random.choice(doge_urls),
        caption="<b>🐕 DOGE</b>\n\nmuch wow very doge",
        reply_to_message_id=message.id
    )

@PY.UBOT("cat")
@PY.TOP_CMD
async def random_cat(client, message):
    """Random cat image"""
    msg = await message.reply("🔍 Mencari kucing...")
    
    try:
        # Cat API
        response = requests.get("https://api.thecatapi.com/v1/images/search", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            cat_url = data[0]['url']
            
            await msg.delete()
            
            await client.send_photo(
                chat_id=message.chat.id,
                photo=cat_url,
                caption="<b>🐱 KUCING LUCU</b>",
                reply_to_message_id=message.id
            )
        else:
            await msg.edit("❌ Gagal ambil gambar kucing")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== ASCII ART ====================

@PY.UBOT("ascii")
@PY.TOP_CMD
async def ascii_art(client, message):
    """ASCII art random"""
    arts = [
        """
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣄⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⣠⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠀⠀⠀
        ⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀
        """,
        """
        ⠀⠀⠀⠀⠀⠀⠀⢀⣀⣤⣤⣶⣶⣶⣶⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⢀⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⡀⠀⠀⠀
        ⠀⠀⣠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⠀⠀
        ⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀
        """,
        """
        ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
        ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
        ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
        """
    ]
    
    await message.reply(f"<b>🎨 ASCII ART</b>\n\n<code>{random.choice(arts)}</code>")
