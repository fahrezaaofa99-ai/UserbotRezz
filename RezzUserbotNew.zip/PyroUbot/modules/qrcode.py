from PyroUbot import *
import qrcode
import os

__MODULE__ = "𝐐𝐑 𝐂𝐨𝐝𝐞"
__HELP__ = """
<blockquote><b>📱 𝐐𝐑 𝐂𝐨𝐝𝐞</b>

 • <code>{0}qrmake &lt;text></code> - Buat QR Code
 • <code>{0}qrread &lt;reply gambar></code> - Baca QR Code</blockquote>
"""

@PY.UBOT("qrmake")
@PY.TOP_CMD
async def make_qr(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .qrmake <text>")
    msg = await message.reply("🔄 Membuat QR Code...")
    img = qrcode.make(args[1])
    path = f"qr_{message.id}.png"
    img.save(path)
    await message.reply_photo(path)
    os.remove(path)
    await msg.delete()

@PY.UBOT("qrread")
@PY.TOP_CMD
async def read_qr(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply("❌ Balas ke gambar QR Code!")
    msg = await message.reply("🔄 Membaca QR Code...")
    try:
        import cv2
        import numpy as np
        file = await message.reply_to_message.download()
        img = cv2.imread(file)
        detector = cv2.QRCodeDetector()
        data, _, _ = detector.detectAndDecode(img)
        os.remove(file)
        if data:
            await msg.edit(f"📱 **Hasil QR Code:**\n\n{data}")
        else:
            await msg.edit("❌ Tidak dapat membaca QR Code")
    except:
        await msg.edit("❌ Install opencv-python dulu: pip install opencv-python")
