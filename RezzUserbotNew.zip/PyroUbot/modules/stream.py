# Nama file: /root/RezzUserbot/PyroUbot/modules/stream.py
# Fitur: Streaming & Media Info

from PyroUbot import *
import requests
import json
import random
from datetime import datetime

__MODULE__ = "sᴛʀᴇᴀᴍ"
__HELP__ = """
<blockquote><b>🎬 STREAMING & MEDIA</b>

<b>🎥 MOVIE INFO</b>
 • <code>{0}movie</code> [judul] - Cari info film
   Contoh: <code>{0}movie avengers</code>

 • <code>{0}tv</code> [judul] - Cari info TV series
   Contoh: <code>{0}tv game of thrones</code>

 • <code>{0}trending</code> - Film trending hari ini
 • <code>{0}upcoming</code> - Film yang akan datang

<b>🎬 STREAMING</b>
 • <code>{0}watch</code> [judul] - Cari link streaming
 • <code>{0}subs</code> [judul] - Cari subtitle
 • <code>{0}rating</code> [judul] - Rating IMDb & Rotten Tomatoes

<b>📺 LIVE TV</b>
 • <code>{0}tvindo</code> - Daftar channel TV Indonesia
 • <code>{0}livetv</code> [channel] - Link live streaming TV
   Contoh: <code>{0}livetv rcti</code>

<b>🎵 MUSIC</b>
 • <code>{0}lyrics</code> [judul lagu] - Cari lirik lagu
 • <code>{0}chord</code> [judul lagu] - Cari chord gitar
 • <code>{0}album</code> [judul album] - Info album

<b>🎮 GAMING</b>
 • <code>{0}game</code> [judul game] - Info game
 • <code>{0}system</code> [game] - Requirements game
 • <code>{0}review</code> [game] - Review game

<b>📚 BOOKS</b>
 • <code>{0}book</code> [judul buku] - Cari info buku
 • <code>{0}author</code> [nama] - Info penulis
 • <code>{0}quote</code> - Quote buku random</blockquote>
"""

# OMDb API (The Open Movie Database)
OMDB_API = "http://www.omdbapi.com/"
OMDB_KEY = "apikey=dbb0c0ae"  # API Key publik (ganti klo perlu)

# TVmaze API buat TV series
TVMAZE_API = "http://api.tvmaze.com"

# TheMovieDB API
TMDB_API = "https://api.themoviedb.org/3"
TMDB_KEY = "api_key=5c2f6a6e7f5b8c9d0e1f2a3b4c5d6e7f"  # API Key publik

# ==================== MOVIE INFO ====================

@PY.UBOT("movie")
@PY.TOP_CMD
async def movie_info(client, message):
    """Cari info film"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul film!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🎬 Mencari film: {query}...")
    
    try:
        # Cari di OMDb
        response = requests.get(
            f"{OMDB_API}?{OMDB_KEY}&t={query}&plot=full",
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if data.get('Response') == 'False':
            return await msg.edit(f"❌ Film '{query}' tidak ditemukan")
        
        title = data.get('Title', 'N/A')
        year = data.get('Year', 'N/A')
        rated = data.get('Rated', 'N/A')
        released = data.get('Released', 'N/A')
        runtime = data.get('Runtime', 'N/A')
        genre = data.get('Genre', 'N/A')
        director = data.get('Director', 'N/A')
        writer = data.get('Writer', 'N/A')
        actors = data.get('Actors', 'N/A')
        plot = data.get('Plot', 'N/A')[:300] + "..." if len(data.get('Plot', '')) > 300 else data.get('Plot', 'N/A')
        language = data.get('Language', 'N/A')
        country = data.get('Country', 'N/A')
        awards = data.get('Awards', 'N/A')
        imdb_rating = data.get('imdbRating', 'N/A')
        imdb_votes = data.get('imdbVotes', 'N/A')
        imdb_id = data.get('imdbID', 'N/A')
        poster = data.get('Poster', '')
        
        # Dapatkan rating Rotten Tomatoes
        tomato_score = "N/A"
        for rating in data.get('Ratings', []):
            if rating.get('Source') == 'Rotten Tomatoes':
                tomato_score = rating.get('Value')
                break
        
        text = f"<b>🎬 MOVIE INFO</b>\n\n"
        text += f"<b>{title}</b> ({year})\n\n"
        text += f"⭐ <b>IMDb:</b> {imdb_rating} ({imdb_votes} votes)\n"
        if tomato_score != "N/A":
            text += f"🍅 <b>Rotten Tomatoes:</b> {tomato_score}\n"
        text += f"🎭 <b>Rated:</b> {rated}\n"
        tex += f"📅 <b>Released:</b> {released}\n"
        text += f"⏱️ <b>Runtime:</b> {runtime}\n"
        text += f"🎯 <b>Genre:</b> {genre}\n"
        text += f"🎬 <b>Director:</b> {director}\n"
        text += f"✍️ <b>Writer:</b> {writer}\n"
        text += f"👥 <b>Cast:</b> {actors}\n"
        text += f"🌍 <b>Country:</b> {country}\n"
        text += f"🗣️ <b>Language:</b> {language}\n"
        text += f"🏆 <b>Awards:</b> {awards}\n\n"
        text += f"📝 <b>Plot:</b> {plot}\n\n"
        text += f"🔗 <a href='https://www.imdb.com/title/{imdb_id}'>IMDb Page</a>"
        
        await msg.edit(text, disable_web_page_preview=False)
        
        # Kirim poster kalo ada
        if poster and poster != 'N/A':
            await client.send_photo(
                chat_id=message.chat.id,
                photo=poster,
                reply_to_message_id=message.id
            )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("tv")
@PY.TOP_CMD
async def tv_series(client, message):
    """Cari info TV series"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul TV series!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"📺 Mencari TV series: {query}...")
    
    try:
        # Cari di TVmaze
        response = requests.get(
            f"{TVMAZE_API}/singlesearch/shows",
            params={"q": query},
            timeout=10
        )
        
        if response.status_code != 200:
            # Fallback ke OMDb
            response = requests.get(
                f"{OMDB_API}?{OMDB_KEY}&t={query}&type=series&plot=full",
                timeout=10
            )
            
            if response.status_code != 200:
                return await msg.edit("❌ Gagal mengambil data")
            
            data = response.json()
            
            if data.get('Response') == 'False':
                return await msg.edit(f"❌ Series '{query}' tidak ditemukan")
            
            title = data.get('Title', 'N/A')
            year = data.get('Year', 'N/A')
            rated = data.get('Rated', 'N/A')
            released = data.get('Released', 'N/A')
            runtime = data.get('Runtime', 'N/A')
            genre = data.get('Genre', 'N/A')
            plot = data.get('Plot', 'N/A')[:300] + "..." if len(data.get('Plot', '')) > 300 else data.get('Plot', 'N/A')
            imdb_rating = data.get('imdbRating', 'N/A')
            total_seasons = data.get('totalSeasons', 'N/A')
            imdb_id = data.get('imdbID', 'N/A')
            poster = data.get('Poster', '')
            
            text = f"<b>📺 TV SERIES INFO</b>\n\n"
            text += f"<b>{title}</b> ({year})\n\n"
            text += f"⭐ <b>IMDb:</b> {imdb_rating}\n"
            text += f"🎭 <b>Rated:</b> {rated}\n"
            text += f"📅 <b>Released:</b> {released}\n"
            text += f"⏱️ <b>Episode Runtime:</b> {runtime}\n"
            text += f"🎯 <b>Genre:</b> {genre}\n"
            text += f"📊 <b>Total Seasons:</b> {total_seasons}\n\n"
            text += f"📝 <b>Plot:</b> {plot}\n\n"
            text += f"🔗 <a href='https://www.imdb.com/title/{imdb_id}'>IMDb Page</a>"
            
            await msg.edit(text, disable_web_page_preview=False)
            
            if poster and poster != 'N/A':
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=poster,
                    reply_to_message_id=message.id
                )
        else:
            data = response.json()
            
            title = data.get('name', 'N/A')
            year = data.get('premiered', 'N/A')[:4] if data.get('premiered') else 'N/A'
            status = data.get('status', 'N/A')
            runtime = data.get('runtime', 'N/A')
            genre = ', '.join(data.get('genres', [])) if data.get('genres') else 'N/A'
            summary = data.get('summary', '').replace('<p>', '').replace('</p>', '')[:300] + "..."
            rating = data.get('rating', {}).get('average', 'N/A')
            network = data.get('network', {}).get('name', 'N/A') if data.get('network') else 'N/A'
            schedule = data.get('schedule', {})
            schedule_time = schedule.get('time', 'N/A')
            schedule_days = ', '.join(schedule.get('days', [])) if schedule.get('days') else 'N/A'
            image = data.get('image', {}).get('original', '')
            url = data.get('url', '')
            
            text = f"<b>📺 TV SERIES INFO</b>\n\n"
            text += f"<b>{title}</b> ({year})\n\n"
            if rating != 'N/A':
                text += f"⭐ <b>Rating:</b> {rating}/10\n"
            text += f"📊 <b>Status:</b> {status}\n"
            text += f"📺 <b>Network:</b> {network}\n"
            text += f"⏱️ <b>Runtime:</b> {runtime} min\n"
            text += f"🎯 <b>Genre:</b> {genre}\n"
            text += f"📅 <b>Schedule:</b> {schedule_days} at {schedule_time}\n\n"
            text += f"📝 <b>Summary:</b> {summary}\n\n"
            text += f"🔗 <a href='{url}'>TVmaze Page</a>"
            
            await msg.edit(text, disable_web_page_preview=False)
            
            if image:
                await client.send_photo(
                    chat_id=message.chat.id,
                    photo=image,
                    reply_to_message_id=message.id
                )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("trending")
@PY.TOP_CMD
async def trending_movies(client, message):
    """Film trending hari ini"""
    msg = await message.reply("📊 Mengambil data film trending...")
    
    try:
        # Pake TMDB API
        response = requests.get(
            f"{TMDB_API}/trending/movie/week?{TMDB_KEY}",
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data.get('results'):
            return await msg.edit("❌ Tidak ada data trending")
        
        text = "<b>📈 FILM TRENDING MINGGU INI</b>\n\n"
        
        for i, movie in enumerate(data['results'][:10], 1):
            title = movie.get('title', 'N/A')
            year = movie.get('release_date', 'N/A')[:4] if movie.get('release_date') else 'N/A'
            rating = movie.get('vote_average', 0)
            overview = movie.get('overview', 'N/A')[:50] + "..." if len(movie.get('overview', '')) > 50 else movie.get('overview', 'N/A')
            
            text += f"{i}. <b>{title}</b> ({year}) - ⭐{rating}/10\n"
            text += f"   {overview}\n\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("upcoming")
@PY.TOP_CMD
async def upcoming_movies(client, message):
    """Film yang akan datang"""
    msg = await message.reply("📅 Mengambil data film mendatang...")
    
    try:
        # Pake TMDB API
        response = requests.get(
            f"{TMDB_API}/movie/upcoming?{TMDB_KEY}",
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data.get('results'):
            return await msg.edit("❌ Tidak ada data film mendatang")
        
        text = "<b>📅 FILM MENDATANG</b>\n\n"
        
        for i, movie in enumerate(data['results'][:10], 1):
            title = movie.get('title', 'N/A')
            release = movie.get('release_date', 'TBA')
            overview = movie.get('overview', 'N/A')[:50] + "..." if len(movie.get('overview', '')) > 50 else movie.get('overview', 'N/A')
            
            text += f"{i}. <b>{title}</b> - 📅 {release}\n"
            text += f"   {overview}\n\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== STREAMING ====================

@PY.UBOT("watch")
@PY.TOP_CMD
async def watch_online(client, message):
    """Cari link streaming"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul film/series!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🔍 Mencari link streaming: {query}...")
    
    try:
        # Pake API utelly (butuh API key) - ini cuma contoh
        # Kalo ga punya API key, bisa pake scraping atau redirect ke situs streaming
        
        await msg.edit(
            f"<b>🎬 STREAMING LINK FOR: {query}</b>\n\n"
            f"🔗 <a href='https://vidsrc.to/embed/movie?q={query.replace(' ', '+')}'>VidSrc</a>\n"
            f"🔗 <a href='https://www.2embed.cc/embed?q={query.replace(' ', '+')}'>2Embed</a>\n"
            f"🔗 <a href='https://moviesapi.club/search/{query.replace(' ', '-')}'>MoviesAPI</a>\n\n"
            f"<i>⚠️ Klik link di atas untuk streaming</i>"
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("subs")
@PY.TOP_CMD
async def find_subtitles(client, message):
    """Cari subtitle"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul film/series!")
    
    query = ' '.join(message.command[1:])
    
    await message.reply(
        f"<b>📝 SUBTITLE FOR: {query}</b>\n\n"
        f"🔗 <a href='https://www.opensubtitles.org/en/search2?s={query.replace(' ', '+')}'>OpenSubtitles</a>\n"
        f"🔗 <a href='https://subscene.com/subtitles/search?q={query.replace(' ', '+')}'>SubScene</a>\n"
        f"🔗 <a href='https://yifysubtitles.org/search?q={query.replace(' ', '+')}'>YIFY Subtitles</a>\n\n"
        f"<i>Pilih subtitle sesuai bahasa</i>"
    )

@PY.UBOT("rating")
@PY.TOP_CMD
async def movie_rating(client, message):
    """Rating film dari berbagai sumber"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul film!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"⭐ Mencari rating: {query}...")
    
    try:
        # Cari di OMDb
        response = requests.get(
            f"{OMDB_API}?{OMDB_KEY}&t={query}&plot=short",
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if data.get('Response') == 'False':
            return await msg.edit(f"❌ Film '{query}' tidak ditemukan")
        
        title = data.get('Title', 'N/A')
        year = data.get('Year', 'N/A')
        
        text = f"<b>⭐ RATINGS: {title} ({year})</b>\n\n"
        
        for rating in data.get('Ratings', []):
            source = rating.get('Source')
            value = rating.get('Value')
            if source == 'Internet Movie Database':
                text += f"🎬 <b>IMDb:</b> {value}\n"
            elif source == 'Rotten Tomatoes':
                text += f"🍅 <b>Rotten Tomatoes:</b> {value}\n"
            elif source == 'Metacritic':
                text += f"📊 <b>Metacritic:</b> {value}\n"
        
        if not data.get('Ratings'):
            text += "Tidak ada data rating"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== LIVE TV ====================

@PY.UBOT("tvindo")
@PY.TOP_CMD
async def tv_indonesia(client, message):
    """Daftar channel TV Indonesia"""
    tv_channels = {
        "📺 TV NASIONAL": "RCTI, MNCTV, GTV, iNews, SCTV, Indosiar, TransTV, Trans7, MetroTV, KompasTV, TVRI, NET.",
        "📡 TV DIGITAL": "Nusantara TV, Bhayangkara TV, Jawa Pos TV, JTV, RTV, Daai TV, MNC News, BeritaSatu",
        "🎬 TV BERBAYAR": "HBO, Cinemax, Fox Movies, Star Movies, Fox Sports, BeIN Sports, Discovery Channel, National Geographic"
    }
    
    text = "<b>🇮🇩 CHANNEL TV INDONESIA</b>\n\n"
    for category, channels in tv_channels.items():
        text += f"{category}\n{channels}\n\n"
    
    text += "<i>Gunakan /livetv [channel] untuk link streaming</i>"
    
    await message.reply(text)

@PY.UBOT("livetv")
@PY.TOP_CMD
async def live_tv(client, message):
    """Link live streaming TV"""
    if len(message.command) < 2:
        return await message.reply("Masukkan nama channel!\nContoh: <code>livetv rcti</code>")
    
    channel = message.command[1].lower()
    
    # Database link streaming (bisa ditambah)
    tv_links = {
        'rcti': 'https://www.rcti.tv/live',
        'mnctv': 'https://www.mnctv.com/live',
        'gtv': 'https://www.gtv.id/live',
        'inews': 'https://www.inews.id/live',
        'sctv': 'https://www.sctv.co.id/live',
        'indosiar': 'https://www.indosiar.com/live',
        'transtv': 'https://www.transtv.co.id/live',
        'trans7': 'https://www.trans7.co.id/live',
        'metrotv': 'https://www.metrotvnews.com/live',
        'kompastv': 'https://www.kompas.tv/live',
        'tvri': 'https://www.tvri.go.id/live',
        'net': 'https://www.netmedia.co.id/live',
        'hbo': 'https://www.hboasia.com/live',
        'fox': 'https://www.foxmovies.com/live'
    }
    
    if channel not in tv_links:
        return await message.reply(f"Channel '{channel}' tidak ditemukan. Gunakan /tvindo untuk daftar channel")
    
    await message.reply(
        f"<b>📺 LIVE TV: {channel.upper()}</b>\n\n"
        f"🔗 <a href='{tv_links[channel]}'>Klik untuk streaming</a>\n\n"
        f"<i>⚠️ Mungkin perlu VPN untuk beberapa channel</i>"
    )

# ==================== MUSIC ====================

@PY.UBOT("lyrics")
@PY.TOP_CMD
async def song_lyrics(client, message):
    """Cari lirik lagu"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul lagu!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"📝 Mencari lirik: {query}...")
    
    try:
        # Pake API lyrics.ovh
        response = requests.get(
            f"https://api.lyrics.ovh/v1/{query}",
            timeout=10
        )
        
        if response.status_code != 200:
            # Fallback ke search
            response = requests.get(
                f"https://api.lyrics.ovh/suggest/{query}",
                timeout=10
            )
            data = response.json()
            
            if data.get('data'):
                song = data['data'][0]
                artist = song['artist']['name']
                title = song['title']
                
                # Coba ambil lyrics
                lyrics_response = requests.get(
                    f"https://api.lyrics.ovh/v1/{artist}/{title}",
                    timeout=10
                )
                
                if lyrics_response.status_code == 200:
                    lyrics_data = lyrics_response.json()
                    lyrics = lyrics_data.get('lyrics', 'Lirik tidak ditemukan')
                    
                    if len(lyrics) > 1000:
                        lyrics = lyrics[:1000] + "...\n\n(Lirik terpotong, terlalu panjang)"
                    
                    await msg.edit(
                        f"<b>🎵 LYRICS: {title} - {artist}</b>\n\n"
                        f"{lyrics}"
                    )
                else:
                    await msg.edit(
                        f"<b>🎵 Lagu ditemukan:</b>\n"
                        f"{title} - {artist}\n\n"
                        f"Gunakan format: <code>/lyrics {artist} {title}</code>"
                    )
            else:
                await msg.edit(f"❌ Lirik untuk '{query}' tidak ditemukan")
        else:
            data = response.json()
            lyrics = data.get('lyrics', 'Lirik tidak ditemukan')
            
            if len(lyrics) > 1000:
                lyrics = lyrics[:1000] + "...\n\n(Lirik terpotong, terlalu panjang)"
            
            await msg.edit(
                f"<b>🎵 LYRICS</b>\n\n"
                f"{lyrics}"
            )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("chord")
@PY.TOP_CMD
async def guitar_chord(client, message):
    """Cari chord gitar"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul lagu!")
    
    query = ' '.join(message.command[1:])
    
    # Redirect ke situs chord
    await message.reply(
        f"<b>🎸 CHORD GITAR: {query}</b>\n\n"
        f"🔗 <a href='https://www.chordtela.com/search?q={query.replace(' ', '+')}'>ChordTela</a>\n"
        f"🔗 <a href='https://www.chordfrenzy.com/search?q={query.replace(' ', '+')}'>ChordFrenzy</a>\n"
        f"🔗 <a href='https://www.ultimate-guitar.com/search.php?search_type=title&value={query.replace(' ', '+')}'>Ultimate Guitar</a>\n\n"
        f"<i>Klik link untuk melihat chord</i>"
    )

@PY.UBOT("album")
@PY.TOP_CMD
async def album_info(client, message):
    """Info album musik"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul album!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"💿 Mencari info album: {query}...")
    
    try:
        # Pake Last.fm API (butuh API key) - ini simulasi aja
        # Kalo ga punya API key, pake web scraping atau database lokal
        
        await msg.edit(
            f"<b>💿 ALBUM INFO: {query}</b>\n\n"
            f"🔍 <a href='https://www.last.fm/music/+search?q={query.replace(' ', '+')}'>Cari di Last.fm</a>\n"
            f"🔍 <a href='https://www.discogs.com/search/?q={query.replace(' ', '+')}'>Cari di Discogs</a>\n"
            f"🔍 <a href='https://musicbrainz.org/search?query={query.replace(' ', '+')}&type=release'>Cari di MusicBrainz</a>\n\n"
            f"<i>Klik link untuk melihat info album</i>"
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== GAMING ====================

@PY.UBOT("game")
@PY.TOP_CMD
async def game_info(client, message):
    """Info game"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul game!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🎮 Mencari info game: {query}...")
    
    try:
        # Pake RAWG API (butuh API key) - ini simulasi
        # Atau pake web scraping
        
        await msg.edit(
            f"<b>🎮 GAME INFO: {query}</b>\n\n"
            f"🔍 <a href='https://www.igdb.com/search?q={query.replace(' ', '+')}'>Cari di IGDB</a>\n"
            f"🔍 <a href='https://www.metacritic.com/search/game/{query.replace(' ', '+')}/results'>Cari di Metacritic</a>\n"
            f"🔍 <a href='https://store.steampowered.com/search/?term={query.replace(' ', '+')}'>Cari di Steam</a>\n\n"
            f"📊 <b>Rating:</b> Gunakan /ratinggame [judul] untuk rating"
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("system")
@PY.TOP_CMD
async def system_requirements(client, message):
    """System requirements game"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul game!")
    
    query = ' '.join(message.command[1:])
    
    # Database system requirements sederhana (bisa ditambah)
    game_requirements = {
        'gta v': {
            'min': 'OS: Windows 7 64-bit, CPU: Intel Core 2 Quad Q6600, RAM: 4GB, GPU: NVIDIA 9800 GT, Storage: 72GB',
            'rec': 'OS: Windows 10 64-bit, CPU: Intel Core i5-3470, RAM: 8GB, GPU: NVIDIA GTX 660, Storage: 72GB'
        },
        'cyberpunk 2077': {
            'min': 'OS: Windows 10 64-bit, CPU: Intel Core i5-3570K, RAM: 8GB, GPU: NVIDIA GTX 780, Storage: 70GB',
            'rec': 'OS: Windows 10 64-bit, CPU: Intel Core i7-4790, RAM: 12GB, GPU: NVIDIA GTX 1060, Storage: 70GB SSD'
        },
        'red dead rmption 2': {
            'min': 'OS: Windows 10 64-bit, CPU: Intel Core i5-2500K, RAM: 8GB, GPU: NVIDIA GTX 770, Storage: 150GB',
            'rec': 'OS: Windows 10 64-bit, CPU: Intel Core i7-4770K, RAM: 12GB, GPU: NVIDIA GTX 1060, Storage: 150GB'
        }
    }
    
    query_lower = query.lower()
    found = False
    
    for game, specs in game_requirements.items():
        if game in query_lower:
            text = f"<b>⚙️ SYSTEM REQUIREMENTS: {query}</b>\n\n"
            text += f"<b>MINIMUM:</b>\n{specs['min']}\n\n"
            text += f"<b>RECOMMENDED:</b>\n{specs['rec']}"
            await message.reply(text)
            found = True
            break
    
    if not found:
        await message.reply(
            f"<b>⚙️ SYSTEM REQUIREMENTS: {query}</b>\n\n"
            f"🔍 <a href='https://www.systemrequirementslab.com/search?q={query.replace(' ', '+')}'>Cek di System Requirements Lab</a>\n"
            f"🔍 <a href='https://www.game-debate.com/search?q={query.replace(' ', '+')}'>Cek di Game-Debate</a>\n\n"
            f"<i>Atau cek langsung di situs resmi game</i>"
        )

@PY.UBOT("review")
@PY.TOP_CMD
async def game_review(client, message):
    """Review game"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul game!")
    
    query = ' '.join(message.command[1:])
    
    await message.reply(
        f"<b>📝 GAME REVIEW: {query}</b>\n\n"
        f"🔍 <a href='https://www.metacritic.com/search/game/{query.replace(' ', '+')}/results'>Metacritic</a>\n"
        f"🔍 <a href='https://www.ign.com/search?q={query.replace(' ', '+')}'>IGN</a>\n"
        f"🔍 <a href='https://www.gamespot.com/search/?q={query.replace(' ', '+')}'>GameSpot</a>\n\n"
        f"⭐ <b>Rating:</b> Gunakan /ratinggame [judul]"
    )

@PY.UBOT("ratinggame")
@PY.TOP_CMD
async def game_rating(client, message):
    """Rating game dari berbagai sumber"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul game!")
    
    query = ' '.join(message.command[1:])
    
    # Database rating sederhana
    game_ratings = {
        'gta v': {'metacritic': 97, 'ign': 10, 'gamespot': 9},
        'cyberpunk 2077': {'metacritic': 86, 'ign': 9, 'gamespot': 7},
        'red dead redemption 2': {'metacritic': 97, 'ign': 10, 'gamespot': 9},
        'elden ring': {'metacritic': 96, 'ign': 10, 'gamespot': 10},
        'god of war': {'metacritic': 94, 'ign': 10, 'gamespot': 9}
    }
    
    query_lower = query.lower()
    
    for game, ratings in game_ratings.items():
        if game in query_lower:
            text = f"<b>⭐ GAME RATINGS: {query}</b>\n\n"
            text += f"📊 <b>Metacritic:</b> {ratings['metacritic']}/100\n"
            text += f"🎮 <b>IGN:</b> {ratings['ign']}/10\n"
            text += f"🕹️ <b>GameSpot:</b> {ratings['gamespot']}/10"
            await message.reply(text)
            return
    
    await message.reply(
        f"<b>⭐ GAME RATINGS: {query}</b>\n\n"
        f"🔍 <a href='https://www.metacritic.com/search/game/{query.replace(' ', '+')}/results'>Cek di Metacritic</a>\n"
        f"🔍 <a href='https://www.ign.com/search?q={query.replace(' ', '+')}'>Cek di IGN</a>\n\n"
        f"<i>Klik link untuk melihat rating</i>"
    )

# ==================== BOOKS ====================

@PY.UBOT("book")
@PY.TOP_CMD
async def book_info(client, message):
    """Cari info buku"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul buku!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"📚 Mencari buku: {query}...")
    
    try:
        # Pake Open Library API
        response = requests.get(
            f"https://openlibrary.org/search.json",
            params={"q": query, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data.get('docs'):
            return await msg.edit(f"❌ Buku '{query}' tidak ditemukan")
        
        book = data['docs'][0]
        
        title = book.get('title', 'N/A')
        author = book.get('author_name', ['Unknown'])[0]
        year = book.get('first_publish_year', 'N/A')
        pages = book.get('number_of_pages_median', 'N/A')
        isbn = book.get('isbn', ['N/A'])[0]
        language = book.get('language', ['N/A'])[0]
        publisher = book.get('publisher', ['N/A'])[0]
        
        # Dapatkan cover
        cover_url = f"https://covers.openlibrary.org/b/isbn/{isbn}-L.jpg" if isbn != 'N/A' else None
        
        text = f"<b>📚 BOOK INFO</b>\n\n"
        text += f"<b>{title}</b>\n"
        text += f"✍️ <b>Author:</b> {author}\n"
        text += f"📅 <b>First Published:</b> {year}\n"
        text += f"📖 <b>Pages:</b> {pages}\n"
        text += f"🏷️ <b>ISBN:</b> {isbn}\n"
        text += f"🗣️ <b>Language:</b> {language}\n"
        text += f"📌 <b>Publisher:</b> {publisher}\n\n"
        text += f"🔗 <a href='https://openlibrary.org/isbn/{isbn}'>Open Library Page</a>"
        
        await msg.edit(text, disable_web_page_preview=False)
        
        # Kirim cover kalo ada
        if cover_url:
            await client.send_photo(
                chat_id=message.chat.id,
                photo=cover_url,
                reply_to_message_id=message.id
            )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("author")
@PY.TOP_CMD
async def author_info(client, message):
    """Info penulis"""
    if len(message.command) < 2:
        return await message.reply("Masukkan nama penulis!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"✍️ Mencari penulis: {query}...")
    
    try:
        # Pake Open Library API
        response = requests.get(
            f"https://openlibrary.org/search/authors.json",
            params={"q": query, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data.get('docs'):
            return await msg.edit(f"❌ Penulis '{query}' tidak ditemukan")
        
        author = data['docs'][0]
        
        name = author.get('name', 'N/A')
        birth = author.get('birth_date', 'N/A')
        death = author.get('death_date', 'N/A')
        top_work = author.get('top_work', 'N/A')
        work_count = author.get('work_count', 'N/A')
        key = author.get('key', '')
        
        text = f"<b>✍️ AUTHOR INFO</b>\n\n"
        text += f"<b>{name}</b>\n"
        if birth != 'N/A':
            text += f"📅 <b>Born:</b> {birth}\n"
        if death != 'N/A':
            text += f"⚰️ <b>Died:</b> {death}\n"
        text += f"📚 <b>Top Work:</b> {top_work}\n"
        text += f"📖 <b>Total Works:</b> {work_count}\n\n"
        
        if key:
            text += f"🔗 <a href='https://openlibrary.org{key}'>Open Library Page</a>"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("quote")
@PY.TOP_CMD
async def random_book_quote(client, message):
    """Random quote dari buku"""
    try:
        # API quotes (pake ZenQuotes atau lainnya)
        response = requests.get("https://zenquotes.io/api/random", timeout=10)
        
        if response.status_code != 200:
            # Fallback ke quotes dari database lokal
            quotes = [
                {"q": "The only way to do great work is to love what you do.", "a": "Steve Jobs"},
                {"q": "Life is what happens when you're busy making other plans.", "a": "John Lennon"},
                {"q": "The future belongs to those who believe in the beauty of their dreams.", "a": "Eleanor Roosevelt"},
                {"q": "It does not matter how slowly you go as long as you do not stop.", "a": "Confucius"},
                {"q": "Everything you can imagine is real.", "a": "Pablo Picasso"},
                {"q": "Simplicity is the ultimate sophistication.", "a": "Leonardo da Vinci"},
                {"q": "Whoever is happy will make others happy too.", "a": "Anne Frank"},
                {"q": "The secret of getting ahead is getting started.", "a": "Mark Twain"}
            ]
            quote = random.choice(quotes)
            text = f"<b>💬 RANDOM QUOTE</b>\n\n"
            text += f"<i>\"{quote['q']}\"</i>\n\n"
            text += f"— {quote['a']}"
        else:
            data = response.json()
            text = f"<b>💬 RANDOM QUOTE</b>\n\n"
            text += f"<i>\"{data[0]['q']}\"</i>\n\n"
            text += f"— {data[0]['a']}"
        
        await message.reply(text)
        
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")
