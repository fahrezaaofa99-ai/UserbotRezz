from PyroUbot import *

__MODULE__ = "𝐅𝐚𝐤𝐭𝐨𝐫"
__HELP__ = """
<blockquote><b>🔢 𝐅𝐚𝐤𝐭𝐨𝐫 𝐁𝐢𝐥𝐚𝐧𝐠𝐚𝐧</b>

 • <code>{0}faktor &lt;angka></code> - Cari faktor bilangan</blockquote>
"""

@PY.UBOT("faktor")
@PY.TOP_CMD
async def faktor_bilangan(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .faktor <angka>")
    angka = int(args[1])
    faktor = [i for i in range(1, angka+1) if angka % i == 0]
    await message.reply(f"🔢 **Faktor dari {angka}:**\n{', '.join(map(str, faktor))}")
