from PyroUbot import *
import math

__MODULE__ = "𝐏𝐫𝐢𝐦𝐚𝐂𝐡𝐞𝐜𝐤"
__HELP__ = """
<blockquote><b>🔢 𝐂𝐞𝐤 𝐁𝐢𝐥𝐚𝐧𝐠𝐚𝐧 𝐏𝐫𝐢𝐦𝐚</b>

 • <code>{0}prima &lt;angka></code> - Cek bilangan prima</blockquote>
"""

def is_prime(n):
    if n < 2: return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0: return False
    return True

@PY.UBOT("prima")
@PY.TOP_CMD
async def prima_check(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .prima <angka>")
    angka = int(args[1])
    if is_prime(angka):
        await message.reply(f"✅ {angka} adalah **BILANGAN PRIMA**")
    else:
        await message.reply(f"❌ {angka} **BUKAN** bilangan prima")
