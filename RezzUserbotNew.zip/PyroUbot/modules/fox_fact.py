from PyroUbot import *
import requests

__MODULE__ = "𝐅𝐨𝐱 𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🦊 𝐅𝐨𝐱 𝐅𝐚𝐜𝐭</b>

 • <code>{0}foxfact</code> - Fakta tentang rubah
 • <code>{0}foximg</code> - Gambar rubah random</blockquote>
"""

@PY.UBOT("foxfact")
@PY.TOP_CMD
async def fox_fact(client, message):
    try:
        r = requests.get("https://randomfox.ca/floof/")
        if r.status_code == 200:
            fact = r.json()['image'].split('/')[-1].replace('.jpg', '').replace('_', ' ')
            await message.reply(f"🦊 **Fox Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("foximg")
@PY.TOP_CMD
async def fox_image(client, message):
    msg = await message.reply("🦊 Mencari gambar...")
    try:
        r = requests.get("https://randomfox.ca/floof/")
        if r.status_code == 200:
            img_url = r.json()['image']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
