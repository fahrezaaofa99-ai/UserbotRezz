from PyroUbot import *

__MODULE__ = "𝐏𝐚𝐥𝐢𝐧𝐝𝐫𝐨𝐦𝐞"
__HELP__ = """
<blockquote><b>🔄 𝐏𝐚𝐥𝐢𝐧𝐝𝐫𝐨𝐦𝐞</b>

 • <code>{0}palindrome &lt;teks></code> - Cek palindrome</blockquote>
"""

@PY.UBOT("palindrome")
@PY.TOP_CMD
async def check_palindrome(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .palindrome <teks>")
    text = args[1].replace(" ", "").lower()
    if text == text[::-1]:
        await message.reply(f"✅ '{args[1]}' adalah palindrome!")
    else:
        await message.reply(f"❌ '{args[1]}' BUKAN palindrome")
