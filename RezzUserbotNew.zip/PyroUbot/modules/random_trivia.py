from PyroUbot import *
import requests

__MODULE__ = "𝐓𝐫𝐢𝐯𝐢𝐚"
__HELP__ = """
<blockquote><b>❓ 𝐑𝐚𝐧𝐝𝐨𝐦 𝐓𝐫𝐢𝐯𝐢𝐚</b>

 • <code>{0}trivia</code> - Trivia random</blockquote>
"""

@PY.UBOT("trivia")
@PY.TOP_CMD
async def random_trivia(client, message):
    try:
        r = requests.get("https://opentdb.com/api.php?amount=1&type=multiple")
        if r.status_code == 200:
            data = r.json()['results'][0]
            await message.reply(f"❓ **Trivia:** {data['question']}\n\nKategori: {data['category']}\nDifficulty: {data['difficulty']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
