from PyroUbot import *
import requests

__MODULE__ = "𝐒𝐡𝐨𝐫𝐭𝐋𝐢𝐧𝐤"
__HELP__ = """
<blockquote><b>🔗 𝐒𝐡𝐨𝐫𝐭 𝐋𝐢𝐧𝐤</b>

 • <code>{0}short &lt;url></code> - Pendekin link</blockquote>
"""

@PY.UBOT("short")
@PY.TOP_CMD
async def short_link(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .short <url>")
    msg = await message.reply("🔗 Memendekkan...")
    try:
        r = requests.get(f"https://tinyurl.com/api-create.php?url={args[1]}")
        if r.status_code == 200:
            await msg.edit(f"🔗 **Short URL:** {r.text}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
