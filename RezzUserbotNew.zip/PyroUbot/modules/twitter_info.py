from PyroUbot import *
import requests

__MODULE__ = "𝐓𝐰𝐢𝐭𝐭𝐞𝐫"
__HELP__ = """
<blockquote><b>🐦 𝐓𝐰𝐢𝐭𝐭𝐞𝐫 𝐈𝐧𝐟𝐨</b>

 • <code>{0}twitter &lt;username></code> - Info Twitter</blockquote>
"""

@PY.UBOT("twitter")
@PY.TOP_CMD
async def twitter_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .twitter <username>")
    msg = await message.reply("🐦 Mencari...")
    try:
        r = requests.get(f"https://api.twitter.com/1.1/users/show.json?screen_name={args[1]}")
        if r.status_code == 200:
            data = r.json()
            text = f"""
╭──〔 🐦 TWITTER 〕
│
│ 📌 @{data.get('screen_name', 'N/A')}
│ 👤 Name: {data.get('name', 'N/A')}
│ 📝 Tweets: {data.get('statuses_count', 0)}
│ 👥 Followers: {data.get('followers_count', 0)}
│
╰── ✨ Twitter ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ User tidak ditemukan")
    except:
        await msg.edit("❌ Error")
