from PyroUbot import *
import requests

__MODULE__ = "𝐓𝐕𝐒𝐞𝐫𝐢𝐞𝐬"
__HELP__ = """
<blockquote><b>📺 𝐓𝐕 𝐒𝐞𝐫𝐢𝐞𝐬</b>

 • <code>{0}tv &lt;judul></code> - Cari series TV</blockquote>
"""

@PY.UBOT("tv")
@PY.TOP_CMD
async def tv_series(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tv <judul>")
    msg = await message.reply("📺 Mencari...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?t={args[1]}&type=series&apikey=trilogy")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                await msg.edit(f"📺 **{data['Title']}**\n⭐ {data['imdbRating']}/10\n📊 {data.get('totalSeasons', 'N/A')} Seasons\n🎭 {data['Genre']}")
            else:
                await msg.edit("❌ Tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
