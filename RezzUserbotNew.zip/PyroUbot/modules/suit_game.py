from PyroUbot import *
import random

__MODULE__ = "𝐒𝐮𝐢𝐭"
__HELP__ = """
<blockquote><b>✊ 𝐒𝐮𝐢𝐭 𝐆𝐚𝐦𝐞</b>

 • <code>{0}suit &lt;batu/kertas/gunting></code> - Main suit</blockquote>
"""

@PY.UBOT("suit")
@PY.TOP_CMD
async def suit_game(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .suit <batu/kertas/gunting>")
    pilihan = args[1].lower()
    if pilihan not in ['batu', 'kertas', 'gunting']:
        return await message.reply("❌ Pilih: batu, kertas, atau gunting")
    bot = random.choice(['batu', 'kertas', 'gunting'])
    if pilihan == bot:
        hasil = "DRAW 🤝"
    elif (pilihan == 'batu' and bot == 'gunting') or (pilihan == 'gunting' and bot == 'kertas') or (pilihan == 'kertas' and bot == 'batu'):
        hasil = "KAMU MENANG! 🎉"
    else:
        hasil = "KAMU KALAH! 😢"
    await message.reply(f"✊ **SUIT GAME**\n\nKamu: {pilihan}\nBot: {bot}\n\n{hasil}")
