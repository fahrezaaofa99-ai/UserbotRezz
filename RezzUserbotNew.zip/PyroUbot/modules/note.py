from PyroUbot import *
import json
import os

__MODULE__ = "𝐍𝐨𝐭𝐞"
__HELP__ = """
<blockquote><b>📝 𝐍𝐨𝐭𝐞</b>

 • <code>{0}note &lt;nama> &lt;isi></code> - Simpan note
 • <code>{0}get &lt;nama></code> - Ambil note
 • <code>{0}notes</code> - List note
 • <code>{0}delnote &lt;nama></code> - Hapus note</blockquote>
"""

NOTES_FILE = "notes.json"

def load_notes():
    if os.path.exists(NOTES_FILE):
        with open(NOTES_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_notes(notes):
    with open(NOTES_FILE, 'w') as f:
        json.dump(notes, f, indent=2)

@PY.UBOT("note")
@PY.TOP_CMD
async def save_note(client, message):
    args = message.text.split(maxsplit=2)
    if len(args) < 3:
        return await message.reply("❌ .note <nama> <isi>")
    notes = load_notes()
    notes[args[1]] = args[2]
    save_notes(notes)
    await message.reply(f"✅ Note '{args[1]}' disimpan!")

@PY.UBOT("get")
@PY.TOP_CMD
async def get_note(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .get <nama>")
    notes = load_notes()
    if args[1] in notes:
        await message.reply(f"📝 **{args[1]}:**\n\n{notes[args[1]]}")
    else:
        await message.reply("❌ Note tidak ditemukan!")

@PY.UBOT("notes")
@PY.TOP_CMD
async def list_notes(client, message):
    notes = load_notes()
    if not notes:
        return await message.reply("📭 Belum ada note!")
    text = "📝 **DAFTAR NOTE**\n\n"
    for i, nama in enumerate(notes.keys(), 1):
        text += f"{i}. {nama}\n"
    await message.reply(text)

@PY.UBOT("delnote")
@PY.TOP_CMD
async def delete_note(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .delnote <nama>")
    notes = load_notes()
    if args[1] in notes:
        del notes[args[1]]
        save_notes(notes)
        await message.reply(f"✅ Note '{args[1]}' dihapus!")
    else:
        await message.reply("❌ Note tidak ditemukan!")
