from PyroUbot import *

__MODULE__ = "𝐊𝐨𝐧𝐯𝐞𝐫𝐬𝐢𝐇𝐚𝐫𝐢"
__HELP__ = """
<blockquote><b>📅 𝐊𝐨𝐧𝐯𝐞𝐫𝐬𝐢 𝐇𝐚𝐫𝐢</b>

 • <code>{0}hari &lt;tahun> &lt;bulan> &lt;tanggal></code> - Cek hari</blockquote>
"""

from datetime import datetime

@PY.UBOT("hari")
@PY.TOP_CMD
async def cek_hari(client, message):
    args = message.text.split()
    if len(args) < 4:
        return await message.reply("❌ .hari <tahun> <bulan> <tanggal>")
    try:
        tgl = datetime(int(args[1]), int(args[2]), int(args[3]))
        hari = tgl.strftime("%A")
        await message.reply(f"📅 {args[3]}-{args[2]}-{args[1]} adalah hari **{hari}**")
    except:
        await message.reply("❌ Tanggal tidak valid!")
