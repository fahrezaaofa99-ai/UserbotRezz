from PyroUbot import *
import colorsys
import random

__MODULE__ = "𝐂𝐨𝐥𝐨𝐫 𝐏𝐢𝐜𝐤𝐞𝐫"
__HELP__ = """
<blockquote><b>🎨 𝐂𝐨𝐥𝐨𝐫 𝐏𝐢𝐜𝐤𝐞𝐫</b>

 • <code>{0}randomcolor</code> - Warna random
 • <code>{0}hexcolor</code> - Hex color random
 • <code>{0}rgbcolor</code> - RGB color random
 • <code>{0}colorinfo &lt;hex></code> - Info warna</blockquote>
"""

@PY.UBOT("randomcolor")
@PY.TOP_CMD
async def random_color(client, message):
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)
    hex_color = f"#{r:02x}{g:02x}{b:02x}"
    await message.reply(f"🎨 **Warna Random:** {hex_color}\nRGB: ({r},{g},{b})")

@PY.UBOT("hexcolor")
@PY.TOP_CMD
async def hex_color(client, message):
    hex_color = "#" + ''.join([random.choice('0123456789ABCDEF') for _ in range(6)])
    await message.reply(f"🎨 **Hex Color:** {hex_color}")

@PY.UBOT("rgbcolor")
@PY.TOP_CMD
async def rgb_color(client, message):
    r = random.randint(0,255)
    g = random.randint(0,255)
    b = random.randint(0,255)
    await message.reply(f"🎨 **RGB Color:** rgb({r},{g},{b})")

@PY.UBOT("colorinfo")
@PY.TOP_CMD
async def color_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .colorinfo <hex> Contoh: #FF0000")
    hex_color = args[1].lstrip('#')
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    h, l, s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    await message.reply(f"🎨 **Info Warna:** {args[1]}\nRGB: ({r},{g},{b})\nHSL: ({h:.2f}, {s:.2f}, {l:.2f})")
