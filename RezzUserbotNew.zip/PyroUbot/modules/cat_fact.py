from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐚𝐭𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🐱 𝐂𝐚𝐭 𝐅𝐚𝐜𝐭</b>

 • <code>{0}catfact</code> - Fakta tentang kucing</blockquote>
"""

@PY.UBOT("catfact")
@PY.TOP_CMD
async def cat_fact(client, message):
    try:
        r = requests.get("https://catfact.ninja/fact")
        if r.status_code == 200:
            await message.reply(f"🐱 **Cat Fact:**\n\n{r.json()['fact']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
