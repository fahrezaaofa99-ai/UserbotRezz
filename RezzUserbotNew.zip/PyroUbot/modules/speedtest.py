from PyroUbot import *
import speedtest

__MODULE__ = "𝐒𝐩𝐞𝐞𝐝𝐭𝐞𝐬𝐭"
__HELP__ = """
<blockquote><b>📡 𝐒𝐩𝐞𝐞𝐝𝐭𝐞𝐬𝐭</b>

 • <code>{0}speed</code> - Test kecepatan internet</blockquote>
"""

@PY.UBOT("speed")
@PY.TOP_CMD
async def speed_test(client, message):
    msg = await message.reply("📡 Testing speed...")
    try:
        st = speedtest.Speedtest()
        st.get_best_server()
        download = st.download() / 1_000_000
        upload = st.upload() / 1_000_000
        ping = st.results.ping
        await msg.edit(f"📡 **SPEEDTEST**\n\n⬇️ Download: {download:.2f} Mbps\n⬆️ Upload: {upload:.2f} Mbps\n📶 Ping: {ping:.0f} ms")
    except:
        await msg.edit("❌ Install speedtest-cli: pip install speedtest-cli")
