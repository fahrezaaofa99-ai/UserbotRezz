from PyroUbot import *

__MODULE__ = "𝐖𝐨𝐫𝐝𝐂𝐨𝐮𝐧𝐭"
__HELP__ = """
<blockquote><b>📝 𝐖𝐨𝐫𝐝 𝐂𝐨𝐮𝐧𝐭𝐞𝐫</b>

 • <code>{0}wordcount &lt;teks></code> - Hitung kata</blockquote>
"""

@PY.UBOT("wordcount")
@PY.TOP_CMD
async def word_count(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .wordcount <teks>")
    kata = len(args[1].split())
    karakter = len(args[1])
    spasi = args[1].count(' ')
    await message.reply(f"📝 **Statistik Teks**\n\n📖 Kata: {kata}\n🔤 Karakter: {karakter}\n␣ Spasi: {spasi}")
