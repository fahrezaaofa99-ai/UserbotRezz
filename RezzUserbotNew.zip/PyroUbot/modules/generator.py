# Nama file: /root/RezzUserbot/PyroUbot/modules/generator.py
# Fitur: Generate random stuff

from PyroUbot import *
import random
import string
import uuid

__MODULE__ = "ɢᴇɴᴇʀᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b>🎲 RANDOM GENERATORS</b>

<b>PASSWORD</b>
 • <code>{0}genpass</code> [panjang] - Generate password
 • <code>{0}genpin</code> [digit] - Generate PIN (4-6 digit)
 • <code>{0}genkey</code> [panjang] - Generate API key

<b>ID & TOKEN</b>
 • <code>{0}genuuid</code> - Generate UUID v4
 • <code>{0}genid</code> - Generate random ID (16 digit)
 • <code>{0}gentoken</code> [panjang] - Generate token

<b>TEXT</b>
 • <code>{0}genname</code> - Generate random name
 • <code>{0}genemail</code> - Generate random email
 • <code>{0}genusername</code> - Generate random username
 • <code>{0}genlorem</code> - Generate lorem ipsum

<b>NUMBER</b>
 • <code>{0}gennik</code> - Generate NIK palsu
 • <code>{0}gennorek</code> - Generate no rekening palsu
 • <code>{0}gennohp</code> - Generate no HP palsu
 • <code>{0}genkode</code> [panjang] - Generate kode OTP</blockquote>
"""

@PY.UBOT("genpass")
@PY.TOP_CMD
async def gen_password(client, message):
    length = 12
    if len(message.command) > 1:
        try:
            length = int(message.command[1])
            if length < 4:
                length = 4
            if length > 32:
                length = 32
        except:
            pass
    
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(random.choice(chars) for _ in range(length))
    
    await message.reply(f"<b>🔐 PASSWORD GENERATED</b>\n\n<code>{password}</code>")

@PY.UBOT("genpin")
@PY.TOP_CMD
async def gen_pin(client, message):
    digit = 6
    if len(message.command) > 1:
        try:
            digit = int(message.command[1])
            if digit < 4:
                digit = 4
            if digit > 8:
                digit = 8
        except:
            pass
    
    pin = ''.join(random.choice(string.digits) for _ in range(digit))
    
    await message.reply(f"<b>🔢 PIN GENERATED</b>\n\n<code>{pin}</code>")

@PY.UBOT("genkey")
@PY.TOP_CMD
async def gen_api_key(client, message):
    length = 32
    if len(message.command) > 1:
        try:
            length = int(message.command[1])
            if length < 16:
                length = 16
            if length > 64:
                length = 64
        except:
            pass
    
    key = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    formatted = f"{key[:8]}-{key[8:12]}-{key[12:16]}-{key[16:]}"
    
    await message.reply(f"<b>🔑 API KEY GENERATED</b>\n\n<code>{formatted}</code>")

@PY.UBOT("genuuid")
@PY.TOP_CMD
async def gen_uuid(client, message):
    uid = str(uuid.uuid4())
    await message.reply(f"<b>🆔 UUID GENERATED</b>\n\n<code>{uid}</code>")

@PY.UBOT("genid")
@PY.TOP_CMD
async def gen_id(client, message):
    id_num = ''.join(random.choices(string.digits, k=16))
    await message.reply(f"<b>🆔 RANDOM ID</b>\n\n<code>{id_num}</code>")

@PY.UBOT("gentoken")
@PY.TOP_CMD
async def gen_token(client, message):
    length = 32
    if len(message.command) > 1:
        try:
            length = int(message.command[1])
            if length < 16:
                length = 16
            if length > 64:
                length = 64
        except:
            pass
    
    token = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    await message.reply(f"<b>🎟️ TOKEN GENERATED</b>\n\n<code>{token}</code>")

@PY.UBOT("genname")
@PY.TOP_CMD
async def gen_name(client, message):
    first_names = ["Budi", "Agus", "Siti", "Rina", "Andi", "Dewi", "Joko", "Maya", "Rudi", "Dian"]
    last_names = ["Santoso", "Wijaya", "Kusuma", "Pratiwi", "Hidayat", "Ningsih", "Saputra", "Lestari"]
    
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    await message.reply(f"<b>👤 RANDOM NAME</b>\n\n{name}")

@PY.UBOT("genemail")
@PY.TOP_CMD
async def gen_email(client, message):
    domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "proton.me"]
    name = ''.join(random.choices(string.ascii_lowercase, k=8))
    domain = random.choice(domains)
    email = f"{name}@{domain}"
    
    await message.reply(f"<b>📧 RANDOM EMAIL</b>\n\n<code>{email}</code>")

@PY.UBOT("genusername")
@PY.TOP_CMD
async def gen_username(client, message):
    prefixes = ["user", "admin", "member", "guest", "player"]
    numbers = ''.join(random.choices(string.digits, k=4))
    username = f"{random.choice(prefixes)}_{numbers}"
    
    await message.reply(f"<b>👤 RANDOM USERNAME</b>\n\n@{username}")

@PY.UBOT("genlorem")
@PY.TOP_CMD
async def gen_lorem(client, message):
    lorem = [
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
        "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.",
        "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.",
        "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia."
    ]
    
    text = ' '.join(random.sample(lorem, 3))
    await message.reply(f"<b>📝 LOREM IPSUM</b>\n\n{text}")

@PY.UBOT("gennik")
@PY.TOP_CMD
async def gen_nik(client, message):
    # Format: 2 digit provinsi + 2 digit kab/kota + 2 digit kec + 6 digit tgl lahir + 4 digit unik
    prov = random.choice(["32", "33", "35", "36", "12"])  # Jawa dll
    kab = ''.join(random.choices(string.digits, k=2))
    kec = ''.join(random.choices(string.digits, k=2))
    tgl = ''.join(random.choices(string.digits, k=6))
    unik = ''.join(random.choices(string.digits, k=4))
    
    nik = prov + kab + kec + tgl + unik
    await message.reply(f"<b>🆔 NIK GENERATED</b>\n\n<code>{nik}</code> (TEST ONLY)")
