from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐉𝐨𝐤𝐞"
__HELP__ = """
<blockquote><b>😂 𝐑𝐚𝐧𝐝𝐨𝐦 𝐉𝐨𝐤𝐞</b>

 • <code>{0}joke</code> - Joke random</blockquote>
"""

jokes = [
    "Kenapa ayam berkokok sambil merem? Udah hafal teksnya!",
    "Kenapa air laut asin? Karena ikannya pada kencing",
    "Kenapa motor gak bisa mundur? Nanti ketabrak masa lalu"
]

@PY.UBOT("joke")
@PY.TOP_CMD
async def random_joke_func(client, message):
    await message.reply(f"😂 **Joke:**\n\n{random.choice(jokes)}")
