from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐀𝐧𝐠𝐤𝐚"
__HELP__ = """
<blockquote><b>🔢 𝐑𝐚𝐧𝐝𝐨𝐦 𝐀𝐧𝐠𝐤𝐚</b>

 • <code>{0}angka &lt;min> &lt;max></code> - Random angka</blockquote>
"""

@PY.UBOT("angka")
@PY.TOP_CMD
async def random_number_range(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .angka <min> <max>")
    hasil = random.randint(int(args[1]), int(args[2]))
    await message.reply(f"🎲 **Random Angka:** {hasil}")
