from PyroUbot import *

__MODULE__ = "𝐓𝐢𝐜 𝐓𝐚𝐜 𝐓𝐨𝐞"
__HELP__ = """
<blockquote><b>🎮 𝐓𝐢𝐜 𝐓𝐚𝐜 𝐓𝐨𝐞</b>

 • <code>{0}ttt</code> - Mulai game Tic Tac Toe</blockquote>
"""

TTT_GAMES = {}

@PY.UBOT("ttt")
@PY.TOP_CMD
async def tic_tac_toe(client, message):
    chat_id = message.chat.id
    if chat_id in TTT_GAMES:
        return await message.reply("❌ Game sedang berjalan!")
    
    board = ["⬜"] * 9
    TTT_GAMES[chat_id] = {"board": board, "turn": "❌", "player1": message.from_user.id}
    
    text = "🎮 **TIC TAC TOE**\n\n"
    for i in range(0, 9, 3):
        text += "".join(board[i:i+3]) + "\n"
    text += f"\nGiliran: {TTT_GAMES[chat_id]['turn']}\nReply angka 1-9 untuk bermain"
    
    await message.reply(text)

@PY.INLINE
async def ttt_move(client, inline_query):
    message = inline_query.message
    if not message:
        return
    
    chat_id = message.chat.id
    if chat_id not in TTT_GAMES:
        return
    
    if not message.text or not message.text.isdigit():
        return
    
    pos = int(message.text) - 1
    if pos < 0 or pos > 8:
        return
    
    game = TTT_GAMES[chat_id]
    
    if game["board"][pos] != "⬜":
        return await message.reply("❌ Posisi sudah diisi!")
    
    game["board"][pos] = game["turn"]
    
    # Cek menang
    win = False
    wins = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
    for a,b,c in wins:
        if game["board"][a] == game["board"][b] == game["board"][c] != "⬜":
            win = True
            break
    
    text = "🎮 **TIC TAC TOE**\n\n"
    for i in range(0, 9, 3):
        text += "".join(game["board"][i:i+3]) + "\n"
    
    if win:
        text += f"\n🏆 **{game['turn']} MENANG!**"
        del TTT_GAMES[chat_id]
    elif "⬜" not in game["board"]:
        text += "\n🤝 **DRAW!**"
        del TTT_GAMES[chat_id]
    else:
        game["turn"] = "⭕" if game["turn"] == "❌" else "❌"
        text += f"\nGiliran: {game['turn']}\nReply angka 1-9"
    
    await message.reply(text)

