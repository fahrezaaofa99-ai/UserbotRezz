from PyroUbot import *
import requests

__MODULE__ = "𝐄𝐓𝐇"
__HELP__ = """
<blockquote><b>💰 𝐄𝐭𝐡𝐞𝐫𝐞𝐮𝐦</b>

 • <code>{0}eth</code> - Harga Ethereum</blockquote>
"""

@PY.UBOT("eth")
@PY.TOP_CMD
async def eth_price(client, message):
    msg = await message.reply("💰 Mengambil harga ETH...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd,idr")
        if r.status_code == 200:
            data = r.json()
            usd = data['ethereum']['usd']
            idr = data['ethereum']['idr']
            await msg.edit(f"💰 **Ethereum (ETH)**\n\n💵 USD: ${usd:,.0f}\n🇮🇩 IDR: Rp{idr:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
