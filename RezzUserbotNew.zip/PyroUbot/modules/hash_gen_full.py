from PyroUbot import *
import hashlib

__MODULE__ = "𝐇𝐚𝐬𝐡𝐅𝐮𝐥𝐥"
__HELP__ = """
<blockquote><b>🔐 𝐇𝐚𝐬𝐡 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}hash &lt;teks></code> - Generate MD5, SHA1, SHA256</blockquote>
"""

@PY.UBOT("hash")
@PY.TOP_CMD
async def generate_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .hash <teks>")
    text = args[1]
    md5 = hashlib.md5(text.encode()).hexdigest()
    sha1 = hashlib.sha1(text.encode()).hexdigest()
    sha256 = hashlib.sha256(text.encode()).hexdigest()
    await message.reply(f"🔐 **Hash dari:** `{text}`\n\n📌 MD5: `{md5}`\n📌 SHA1: `{sha1}`\n📌 SHA256: `{sha256}`")
