from PyroUbot import *

__MODULE__ = "𝐕𝐨𝐰𝐞𝐥"
__HELP__ = """
<blockquote><b>🔤 𝐕𝐨𝐰𝐞𝐥 𝐂𝐨𝐮𝐧𝐭𝐞𝐫</b>

 • <code>{0}vokal &lt;teks></code> - Hitung huruf vokal</blockquote>
"""

@PY.UBOT("vokal")
@PY.TOP_CMD
async def vowel_count(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .vokal <teks>")
    vokal = sum(1 for c in args[1].lower() if c in 'aeiou')
    konsonan = sum(1 for c in args[1].lower() if c.isalpha() and c not in 'aeiou')
    await message.reply(f"🔤 **Hitung Huruf**\n\n📝 Teks: {args[1]}\n🔊 Vokal: {vokal}\n🔇 Konsonan: {konsonan}")
