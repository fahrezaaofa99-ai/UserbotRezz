from PyroUbot import *
import asyncio

__MODULE__ = "𝐀𝐥𝐚𝐫𝐦"
__HELP__ = """
<blockquote><b>⏰ 𝐀𝐥𝐚𝐫𝐦</b>

 • <code>{0}alarm &lt;detik> &lt;pesan></code> - Set alarm</blockquote>
"""

@PY.UBOT("alarm")
@PY.TOP_CMD
async def alarm(client, message):
    args = message.text.split(maxsplit=2)
    if len(args) < 3:
        return await message.reply("❌ .alarm <detik> <pesan>")
    try:
        detik = int(args[1])
        pesan = args[2]
        await message.reply(f"⏰ Alarm akan berbunyi dalam {detik} detik")
        await asyncio.sleep(detik)
        await message.reply(f"🔔 **ALARM!**\n\n{pesan}")
    except:
        await message.reply("❌ Error")
