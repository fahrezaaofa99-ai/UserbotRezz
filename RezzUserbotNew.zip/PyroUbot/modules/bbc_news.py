from PyroUbot import *
import requests
from bs4 import BeautifulSoup

__MODULE__ = "𝐁𝐁𝐂𝐍𝐞𝐰𝐬"
__HELP__ = """
<blockquote><b>📰 𝐁𝐁𝐂 𝐍𝐞𝐰𝐬</b>

 • <code>{0}bbc</code> - Berita terbaru BBC</blockquote>
"""

@PY.UBOT("bbc")
@PY.TOP_CMD
async def bbc_news(client, message):
    msg = await message.reply("📰 Mengambil berita BBC...")
    try:
        r = requests.get("https://www.bbc.com/news")
        soup = BeautifulSoup(r.text, 'html.parser')
        headlines = soup.find_all('h3', class_='gs-c-promo-heading__title')
        text = "📰 **BBC NEWS TERBARU**\n\n"
        for i, h in enumerate(headlines[:5], 1):
            text += f"{i}. {h.text.strip()}\n"
        await msg.edit(text)
    except:
        await msg.edit("❌ Gagal")
