from PyroUbot import *
import datetime

__MODULE__ = "𝐙𝐨𝐝𝐢𝐚𝐤"
__HELP__ = """
<blockquote><b>♈ 𝐙𝐨𝐝𝐢𝐚𝐤</b>

 • <code>{0}zodiak &lt;tanggal-lahir></code> - Cek zodiak</blockquote>
"""

zodiaks = [
    (1, 20, "♒ Aquarius"), (2, 19, "♓ Pisces"), (3, 21, "♈ Aries"),
    (4, 20, "♉ Taurus"), (5, 21, "♊ Gemini"), (6, 21, "♋ Cancer"),
    (7, 23, "♌ Leo"), (8, 23, "♍ Virgo"), (9, 23, "♎ Libra"),
    (10, 23, "♏ Scorpio"), (11, 22, "♐ Sagitarius"), (12, 22, "♑ Capricorn")
]

def get_zodiak(month, day):
    for m, d, z in zodiaks:
        if month == m and day >= d or month == m+1 and day < d:
            return z
    return "♑ Capricorn"

@PY.UBOT("zodiak")
@PY.TOP_CMD
async def zodiak(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .zodiak DD-MM-YYYY")
    try:
        tgl = args[1].split('-')
        day, month = int(tgl[0]), int(tgl[1])
        zodiak = get_zodiak(month, day)
        await message.reply(f"♈ **Zodiak kamu:** {zodiak}")
    except:
        await message.reply("❌ Format salah! Contoh: 15-08-2000")
