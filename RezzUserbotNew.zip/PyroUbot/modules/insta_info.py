from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐧𝐬𝐭𝐚"
__HELP__ = """
<blockquote><b>📷 𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦 𝐈𝐧𝐟𝐨</b>

 • <code>{0}insta &lt;username></code> - Info Instagram</blockquote>
"""

@PY.UBOT("insta")
@PY.TOP_CMD
async def insta_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .insta <username>")
    msg = await message.reply("📷 Mencari...")
    try:
        r = requests.get(f"https://instagram.com/{args[1]}/?__a=1&__d=1")
        if r.status_code == 200:
            data = r.json()
            user = data['graphql']['user']
            text = f"""
╭──〔 📷 INSTAGRAM 〕
│
│ 📌 @{user.get('username', 'N/A')}
│ 👤 Name: {user.get('full_name', 'N/A')}
│ 📸 Posts: {user.get('edge_owner_to_timeline_media', {}).get('count', 0)}
│ 👥 Followers: {user.get('edge_followed_by', {}).get('count', 0)}
│
╰── ✨ Instagram ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ User tidak ditemukan")
    except:
        await msg.edit("❌ Error atau username private")
