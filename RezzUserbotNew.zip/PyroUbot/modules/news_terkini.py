from PyroUbot import *
import requests

__MODULE__ = "𝐍𝐞𝐰𝐬𝐓𝐞𝐫𝐤𝐢𝐧𝐢"
__HELP__ = """
<blockquote><b>📰 𝐍𝐞𝐰𝐬 𝐓𝐞𝐫𝐤𝐢𝐧𝐢</b>

 • <code>{0}news</code> - Berita terkini Indonesia</blockquote>
"""

@PY.UBOT("news")
@PY.TOP_CMD
async def news_terkini(client, message):
    msg = await message.reply("📰 Mengambil berita...")
    try:
        r = requests.get("https://berita-indo-api.vercel.app/v1/cnn-news/terbaru")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **BERITA TERKINI**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
