from PyroUbot import *
import requests

__MODULE__ = "𝐍𝐞𝐰𝐬"
__HELP__ = """
<blockquote><b>📰 𝐍𝐞𝐰𝐬</b>

 • <code>{0}news</code> - Berita terbaru</blockquote>
"""

@PY.UBOT("news")
@PY.TOP_CMD
async def news(client, message):
    msg = await message.reply("📰 Mengambil berita...")
    try:
        r = requests.get("https://berita-indo-api.vercel.app/v1/cnn-news/terbaru", timeout=10)
        if r.status_code == 200:
            data = r.json()
            text = "📰 **BERITA TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal mengambil berita")
    except:
        await msg.edit("❌ Error")
