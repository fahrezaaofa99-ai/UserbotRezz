from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐨𝐯𝐢𝐝"
__HELP__ = """
<blockquote><b>🦠 𝐂𝐨𝐯𝐢𝐝</b>

 • <code>{0}covid</code> - Data Covid Indonesia</blockquote>
"""

@PY.UBOT("covid")
@PY.TOP_CMD
async def covid_info(client, message):
    msg = await message.reply("🦠 Mengambil data Covid...")
    try:
        r = requests.get("https://data.covid19.go.id/public/api/update.json", timeout=10)
        if r.status_code == 200:
            data = r.json()
            update = data['update']['harian']['terbaru']
            text = f"""
╭──〔 🦠 COVID INDONESIA 〕
│
│ 📅 {update.get('key_as_string', 'N/A')[:10]}
│ 🟢 Positif: {update.get('jumlah_positif', 0):,}
│ 🔴 Meninggal: {update.get('jumlah_meninggal', 0):,}
│ ✅ Sembuh: {update.get('jumlah_sembuh', 0):,}
│
╰── ✨ Data Covid ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
