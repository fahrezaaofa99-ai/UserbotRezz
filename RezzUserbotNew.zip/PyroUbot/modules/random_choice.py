from PyroUbot import *
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐂𝐡𝐨𝐢𝐜𝐞"
__HELP__ = """
<blockquote><b>🎲 𝐑𝐚𝐧𝐝𝐨𝐦 𝐂𝐡𝐨𝐢𝐜𝐞</b>

 • <code>{0}choose &lt;opsi1,opsi2,opsi3></code> - Pilih random</blockquote>
"""

@PY.UBOT("choose")
@PY.TOP_CMD
async def random_choose(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .choose <opsi1,opsi2,opsi3>")
    items = [x.strip() for x in args[1].split(',')]
    if len(items) < 2:
        return await message.reply("❌ Minimal 2 opsi, pisahkan dengan koma")
    hasil = random.choice(items)
    await message.reply(f"🎲 **Hasil pilihan:** {hasil}")
