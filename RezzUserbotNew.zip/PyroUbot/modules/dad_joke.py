from PyroUbot import *
import requests

__MODULE__ = "𝐃𝐚𝐝𝐉𝐨𝐤𝐞"
__HELP__ = """
<blockquote><b>👨 𝐃𝐚𝐝 𝐉𝐨𝐤𝐞</b>

 • <code>{0}dadjoke</code> - Joke bapak-bapak</blockquote>
"""

@PY.UBOT("dadjoke")
@PY.TOP_CMD
async def dad_joke(client, message):
    try:
        r = requests.get("https://icanhazdadjoke.com/", headers={"Accept": "text/plain"})
        if r.status_code == 200:
            await message.reply(f"👨 **Dad Joke:**\n\n{r.text}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
