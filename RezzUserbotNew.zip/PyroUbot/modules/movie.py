from PyroUbot import *
import requests

__MODULE__ = "𝐌𝐨𝐯𝐢𝐞"
__HELP__ = """
<blockquote><b>🎬 𝐌𝐨𝐯𝐢𝐞</b>

 • <code>{0}movie &lt;judul></code> - Cari info film</blockquote>
"""

@PY.UBOT("movie")
@PY.TOP_CMD
async def movie_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .movie <judul>")
    msg = await message.reply("🎬 Mencari film...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?t={args[1]}&apikey=trilogy", timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = f"""
╭──〔 🎬 INFO FILM 〕
│
│ 📌 {data.get('Title', 'N/A')}
│ 📅 {data.get('Year', 'N/A')}
│ ⭐ {data.get('imdbRating', 'N/A')}/10
│ 🎭 {data.get('Genre', 'N/A')}
│ 🎬 {data.get('Director', 'N/A')}
│
╰── ✨ Movie Info ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Film tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
