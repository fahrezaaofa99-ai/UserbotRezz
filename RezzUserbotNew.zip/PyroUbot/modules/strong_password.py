from PyroUbot import *
import random
import string

__MODULE__ = "𝐒𝐭𝐫𝐨𝐧𝐠𝐏𝐚𝐬𝐬"
__HELP__ = """
<blockquote><b>🔐 𝐒𝐭𝐫𝐨𝐧𝐠 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝</b>

 • <code>{0}strongpass &lt;panjang></code> - Generate password kuat</blockquote>
"""

@PY.UBOT("strongpass")
@PY.TOP_CMD
async def strong_password(client, message):
    args = message.text.split()
    length = int(args[1]) if len(args) > 1 else 16
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    password = ''.join(random.choice(chars) for _ in range(length))
    await message.reply(f"🔐 **Strong Password:** `{password}`")
