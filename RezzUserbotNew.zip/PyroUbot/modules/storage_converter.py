from PyroUbot import *

__MODULE__ = "𝐒𝐭𝐨𝐫𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>💾 𝐒𝐭𝐨𝐫𝐚𝐠𝐞 𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐞𝐫</b>

 • <code>{0}mb_gb &lt;mb></code> - MB ke GB
 • <code>{0}gb_mb &lt;gb></code> - GB ke MB
 • <code>{0}kb_mb &lt;kb></code> - KB ke MB</blockquote>
"""

@PY.UBOT("mb_gb")
@PY.TOP_CMD
async def mb_to_gb(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .mb_gb <mb>")
    mb = float(args[1])
    gb = mb / 1024
    await message.reply(f"💾 {mb} MB = {gb:.2f} GB")

@PY.UBOT("gb_mb")
@PY.TOP_CMD
async def gb_to_mb(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .gb_mb <gb>")
    gb = float(args[1])
    mb = gb * 1024
    await message.reply(f"💾 {gb} GB = {mb} MB")

@PY.UBOT("kb_mb")
@PY.TOP_CMD
async def kb_to_mb(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .kb_mb <kb>")
    kb = float(args[1])
    mb = kb / 1024
    await message.reply(f"💾 {kb} KB = {mb:.2f} MB")
