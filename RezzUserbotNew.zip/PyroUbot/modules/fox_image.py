from PyroUbot import *
import requests

__MODULE__ = "𝐅𝐨𝐱𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🦊 𝐅𝐨𝐱 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}fox</code> - Gambar rubah random</blockquote>
"""

@PY.UBOT("fox")
@PY.TOP_CMD
async def fox_image(client, message):
    msg = await message.reply("🦊 Mencari gambar...")
    try:
        r = requests.get("https://randomfox.ca/floof/")
        if r.status_code == 200:
            img_url = r.json()['image']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
