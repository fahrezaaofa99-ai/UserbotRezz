from PyroUbot import *
import wikipedia

__MODULE__ = "𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚"
__HELP__ = """
<blockquote><b>📚 𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚</b>

 • <code>{0}wiki &lt;keyword></code> - Cari di Wikipedia</blockquote>
"""

@PY.UBOT("wiki")
@PY.TOP_CMD
async def wiki_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .wiki <keyword>")
    msg = await message.reply("🔍 Mencari...")
    try:
        wikipedia.set_lang("id")
        result = wikipedia.summary(args[1], sentences=3)
        await msg.edit(f"📚 **Wikipedia: {args[1]}**\n\n{result}")
    except:
        await msg.edit("❌ Tidak ditemukan")
