from PyroUbot import *
import requests

__MODULE__ = "𝐖𝐞𝐛𝐒𝐭𝐚𝐭𝐮𝐬"
__HELP__ = """
<blockquote><b>🌐 𝐖𝐞𝐛𝐬𝐢𝐭𝐞 𝐒𝐭𝐚𝐭𝐮𝐬</b>

 • <code>{0}status &lt;url></code> - Cek status website</blockquote>
"""

@PY.UBOT("status")
@PY.TOP_CMD
async def website_status(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .status <url>")
    msg = await message.reply("🌐 Memeriksa...")
    try:
        url = args[1] if args[1].startswith('http') else f"https://{args[1]}"
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            await msg.edit(f"✅ **{args[1]}** ONLINE (Status: {r.status_code})")
        else:
            await msg.edit(f"⚠️ **{args[1]}** RESPON {r.status_code}")
    except:
        await msg.edit(f"❌ **{args[1]}** OFFLINE")
