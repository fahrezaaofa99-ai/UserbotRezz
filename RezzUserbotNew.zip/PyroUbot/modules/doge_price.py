from PyroUbot import *
import requests

__MODULE__ = "𝐃𝐎𝐆𝐄"
__HELP__ = """
<blockquote><b>💰 𝐃𝐨𝐠𝐞𝐜𝐨𝐢𝐧</b>

 • <code>{0}doge</code> - Harga Dogecoin</blockquote>
"""

@PY.UBOT("doge")
@PY.TOP_CMD
async def doge_price(client, message):
    msg = await message.reply("💰 Mengambil harga DOGE...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd,idr")
        if r.status_code == 200:
            data = r.json()
            usd = data['dogecoin']['usd']
            idr = data['dogecoin']['idr']
            await msg.edit(f"💰 **Dogecoin (DOGE)**\n\n💵 USD: ${usd}\n🇮🇩 IDR: Rp{idr:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
