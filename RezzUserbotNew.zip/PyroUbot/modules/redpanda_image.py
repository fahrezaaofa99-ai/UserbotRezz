from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐞𝐝𝐏𝐚𝐧𝐝𝐚"
__HELP__ = """
<blockquote><b>🦝 𝐑𝐞𝐝 𝐏𝐚𝐧𝐝𝐚 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}redpanda</code> - Gambar red panda random</blockquote>
"""

@PY.UBOT("redpanda")
@PY.TOP_CMD
async def redpanda_image(client, message):
    msg = await message.reply("🦝 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/redpanda")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
