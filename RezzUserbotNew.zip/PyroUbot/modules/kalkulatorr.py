# Nama file: /root/RezzUserbot/PyroUbot/modules/kalkulator.py
# Fitur: Kalkulator & Konverter

from PyroUbot import *
import math
import random

__MODULE__ = "ᴋᴀʟᴋᴜʟᴀᴛᴏʀ"
__HELP__ = """
<blockquote><b>🧮 KALKULATOR & KONVERTER</b>

<b>KALKULATOR</b>
 • <code>{0}calc</code> [rumus] - Kalkulator sederhana
 • <code>{0}math</code> [operasi] [a] [b] - Operasi matematika
 • <code>{0}akar</code> [angka] - Akar kuadrat
 • <code>{0}pangkat</code> [angka] [pangkat] - Pangkat
 • <code>{0}log</code> [angka] - Logaritma
 • <code>{0}sin</code> [angka] - Sinus
 • <code>{0}cos</code> [angka] - Cosinus
 • <code>{0}tan</code> [angka] - Tangen

<b>KONVERTER</b>
 • <code>{0}km</code> [km] [m/cm/mm] - Konversi km
 • <code>{0}m</code> [m] [km/cm/mm] - Konversi meter
 • <code>{0}cm</code> [cm] [m/km/mm] - Konversi cm
 • <code>{0}kg</code> [kg] [g/mg/ton] - Konversi kg
 • <code>{0}liter</code> [liter] [ml/galon] - Konversi liter
 • <code>{0}celcius</code> [c] [f/k] - Konversi suhu
 • <code>{0}fahrenheit</code> [f] [c/k] - Konversi suhu

<b>BILANGAN</b>
 • <code>{0}prima</code> [angka] - Cek bilangan prima
 • <code>{0}faktor</code> [angka] - Faktor bilangan
 • <code>{0}fibonacci</code> [n] - Deret Fibonacci
 • <code>{0}random</code> [min] [max] - Angka random</blockquote>
"""

@PY.UBOT("calc")
@PY.TOP_CMD
async def kalkulator(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>calc 2+2*5</code>")
    
    expr = ' '.join(message.command[1:])
    allowed = set('0123456789+-*/.() ')
    
    if any(c not in allowed for c in expr):
        return await message.reply("❌ Ekspresi tidak valid!")
    
    try:
        result = eval(expr, {"__builtins__": {}}, {"math": math})
        await message.reply(f"<b>🧮 HASIL</b>\n\n{expr} = {result}")
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("prima")
@PY.TOP_CMD
async def cek_prima(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>prima 17</code>")
    
    try:
        n = int(message.command[1])
        if n < 2:
            return await message.reply(f"{n} BUKAN bilangan prima")
        
        prima = True
        for i in range(2, int(math.sqrt(n)) + 1):
            if n % i == 0:
                prima = False
                break
        
        status = "✅ PRIMA" if prima else "❌ BUKAN PRIMA"
        await message.reply(f"<b>🔢 {n}</b> : {status}")
        
    except ValueError:
        await message.reply("Masukkan angka!")

@PY.UBOT("faktor")
@PY.TOP_CMD
async def faktor_bilangan(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>faktor 12</code>")
    
    try:
        n = int(message.command[1])
        faktor = [i for i in range(1, n+1) if n % i == 0]
        await message.reply(f"<b>🔢 FAKTOR {n}</b>\n\n{', '.join(map(str, faktor))}")
    except ValueError:
        await message.reply("Masukkan angka!")

@PY.UBOT("fibonacci")
@PY.TOP_CMD
async def fibonacci(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>fibonacci 10</code>")
    
    try:
        n = int(message.command[1])
        if n > 50:
            return await message.reply("Maksimal 50 (biar ga kepanjangan)")
        
        fib = [0, 1]
        for i in range(2, n):
            fib.append(fib[i-1] + fib[i-2])
        
        await message.reply(f"<b>🔢 FIBONACCI {n}</b>\n\n{', '.join(map(str, fib[:n]))}")
    except ValueError:
        await message.reply("Masukkan angka!")

@PY.UBOT("random")
@PY.TOP_CMD
async def random_angka(client, message):
    if len(message.command) < 3:
        return await message.reply("Contoh: <code>random 1 100</code>")
    
    try:
        min_val = int(message.command[1])
        max_val = int(message.command[2])
        hasil = random.randint(min_val, max_val)
        await message.reply(f"<b>🎲 RANDOM</b>\n\n{min_val} - {max_val} ➜ {hasil}")
    except ValueError:
        await message.reply("Masukkan angka!")
