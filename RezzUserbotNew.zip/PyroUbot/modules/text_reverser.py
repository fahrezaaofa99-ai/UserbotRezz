from PyroUbot import *

__MODULE__ = "𝐑𝐞𝐯𝐞𝐫𝐬𝐞"
__HELP__ = """
<blockquote><b>🔄 𝐓𝐞𝐱𝐭 𝐑𝐞𝐯𝐞𝐫𝐬𝐞𝐫</b>

 • <code>{0}reverse &lt;teks></code> - Balik teks</blockquote>
"""

@PY.UBOT("reverse")
@PY.TOP_CMD
async def text_reverse(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .reverse <teks>")
    await message.reply(f"🔄 **Teks Terbalik:**\n\n{args[1][::-1]}")
