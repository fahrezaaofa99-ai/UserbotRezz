from PyroUbot import *
import requests

__MODULE__ = "𝐖𝐚𝐥𝐥𝐩𝐚𝐩𝐞𝐫"
__HELP__ = """
<blockquote><b>🖼️ 𝐑𝐚𝐧𝐝𝐨𝐦 𝐖𝐚𝐥𝐥𝐩𝐚𝐩𝐞𝐫</b>

 • <code>{0}wallpaper</code> - Wallpaper random
 • <code>{0}wall &lt;kategori></code> - Wallpaper kategori</blockquote>
"""

@PY.UBOT("wallpaper")
@PY.TOP_CMD
async def random_wallpaper(client, message):
    msg = await message.reply("🖼️ Mencari wallpaper...")
    try:
        r = requests.get("https://picsum.photos/1920/1080")
        if r.status_code == 200:
            await message.reply_photo(r.url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
