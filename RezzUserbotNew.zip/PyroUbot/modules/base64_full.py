from PyroUbot import *
import base64

__MODULE__ = "𝐁𝐚𝐬𝐞𝟔𝟒𝐅𝐮𝐥𝐥"
__HELP__ = """
<blockquote><b>🔢 𝐁𝐚𝐬𝐞𝟔𝟒 𝐓𝐨𝐨𝐥</b>

 • <code>{0}b64e &lt;teks></code> - Encode Base64
 • <code>{0}b64d &lt;teks></code> - Decode Base64</blockquote>
"""

@PY.UBOT("b64e")
@PY.TOP_CMD
async def b64_encode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .b64e <teks>")
    encoded = base64.b64encode(args[1].encode()).decode()
    await message.reply(f"🔐 **Base64 Encode:** `{encoded}`")

@PY.UBOT("b64d")
@PY.TOP_CMD
async def b64_decode(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .b64d <teks>")
    try:
        decoded = base64.b64decode(args[1]).decode()
        await message.reply(f"📝 **Base64 Decode:** `{decoded}`")
    except:
        await message.reply("❌ Gagal decode")
