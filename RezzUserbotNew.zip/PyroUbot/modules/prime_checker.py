from PyroUbot import *
import math

__MODULE__ = "𝐏𝐫𝐢𝐦𝐞"
__HELP__ = """
<blockquote><b>🔢 𝐏𝐫𝐢𝐦𝐞 𝐍𝐮𝐦𝐛𝐞𝐫</b>

 • <code>{0}prime &lt;angka></code> - Cek bilangan prima
 • <code>{0}primes &lt;max></code> - Deret bilangan prima</blockquote>
"""

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

@PY.UBOT("prime")
@PY.TOP_CMD
async def check_prime(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .prime <angka>")
    try:
        n = int(args[1])
        if is_prime(n):
            await message.reply(f"✅ {n} adalah bilangan PRIMA")
        else:
            await message.reply(f"❌ {n} BUKAN bilangan prima")
    except:
        await message.reply("❌ Masukkan angka valid")

@PY.UBOT("primes")
@PY.TOP_CMD
async def list_primes(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .primes <max>")
    try:
        max_n = int(args[1])
        primes = [str(i) for i in range(2, max_n+1) if is_prime(i)]
        await message.reply(f"🔢 Bilanga prima sampai {max_n}:\n{', '.join(primes[:20])}")
    except:
        await message.reply("❌ Error")
