from PyroUbot import *
import requests

__MODULE__ = "𝐊𝐨𝐚𝐥𝐚𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🐨 𝐊𝐨𝐚𝐥𝐚 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}koala</code> - Gambar koala random</blockquote>
"""

@PY.UBOT("koala")
@PY.TOP_CMD
async def koala_image(client, message):
    msg = await message.reply("🐨 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/koala")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
