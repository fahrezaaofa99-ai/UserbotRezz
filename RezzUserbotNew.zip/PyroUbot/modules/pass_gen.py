from PyroUbot import *
import random
import string

__MODULE__ = "𝐏𝐚𝐬𝐬𝐆𝐞𝐧"
__HELP__ = """
<blockquote><b>🔐 𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}pass &lt;panjang></code> - Generate password</blockquote>
"""

@PY.UBOT("pass")
@PY.TOP_CMD
async def generate_pass(client, message):
    args = message.text.split()
    length = int(args[1]) if len(args) > 1 else 12
    chars = string.ascii_letters + string.digits + "!@#$%"
    password = ''.join(random.choice(chars) for _ in range(length))
    await message.reply(f"🔐 **Password:** `{password}`")
