from PyroUbot import *
import pyotp
import qrcode
import os

__MODULE__ = "𝐓𝐎𝐓𝐏"
__HELP__ = """
<blockquote><b>🔐 𝐓𝐎𝐓𝐏 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}totp &lt;secret></code> - Generate TOTP
 • <code>{0}totpsecret</code> - Buat secret baru
 • <code>{0}totpqr &lt;secret></code> - QR Code TOTP</blockquote>
"""

@PY.UBOT("totp")
@PY.TOP_CMD
async def totp_generate(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .totp <secret>")
    try:
        totp = pyotp.TOTP(args[1])
        code = totp.now()
        await message.reply(f"🔐 **TOTP Code:** `{code}`")
    except:
        await message.reply("❌ Error install pyotp: pip install pyotp")

@PY.UBOT("totpsecret")
@PY.TOP_CMD
async def totp_secret(client, message):
    secret = pyotp.random_base32()
    await message.reply(f"🔐 **Secret Baru:** `{secret}`")

@PY.UBOT("totpqr")
@PY.TOP_CMD
async def totp_qr(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .totpqr <secret>")
    try:
        totp = pyotp.TOTP(args[1])
        uri = totp.provisioning_uri("Userbot", issuer_name="RezzUserbot")
        img = qrcode.make(uri)
        img.save(f"totp_{message.id}.png")
        await message.reply_photo(f"totp_{message.id}.png")
        os.remove(f"totp_{message.id}.png")
    except:
        await message.reply("❌ Error")
