from PyroUbot import *
import asyncio
import os
import sys

__MODULE__ = "ANTIKILL"
__HELP__ = """
<b>⚡ ANTI KILL & AUTO RESTART</b>

• <code>{0}antikillon</code> - Aktifkan anti kill
• <code>{0}antikilloff</code> - Matikan anti kill
• <code>{0}restart</code> - Restart userbot
• <code>{0}update</code> - Update userbot
"""

antikill_status = {}

@PY.UBOT("antikillon")
@PY.TOP_CMD
async def antikill_on(client, message):
    user_id = str(message.from_user.id)
    antikill_status[user_id] = True
    
    await message.reply("✅ Anti kill diaktifkan!\n\nUserbot akan restart otomatis jika mati.")
    
    while antikill_status.get(user_id, False):
        await asyncio.sleep(30)
        if not client.is_connected:
            os.execl(sys.executable, sys.executable, *sys.argv)

@PY.UBOT("antikilloff")
@PY.TOP_CMD
async def antikill_off(client, message):
    user_id = str(message.from_user.id)
    antikill_status[user_id] = False
    await message.reply("❌ Anti kill dimatikan!")

@PY.UBOT("restart")
@PY.TOP_CMD
async def restart_bot(client, message):
    await message.reply("🔄 Restarting userbot...")
    os.execl(sys.executable, sys.executable, *sys.argv)

@PY.UBOT("update")
@PY.TOP_CMD
async def update_bot(client, message):
    msg = await message.reply("🔄 Updating userbot...")
    
    os.system("cd /root/RezzUserbot && git pull")
    await msg.edit("✅ Update selesai! Restarting...")
    os.execl(sys.executable, sys.executable, *sys.argv)
