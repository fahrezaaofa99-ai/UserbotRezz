from PyroUbot import *
import asyncio

__MODULE__ = "𝐂𝐨𝐮𝐧𝐭𝐝𝐨𝐰𝐧"
__HELP__ = """
<blockquote><b>⏱️ 𝐂𝐨𝐮𝐧𝐭𝐝𝐨𝐰𝐧</b>

 • <code>{0}countdown &lt;detik></code> - Hitung mundur</blockquote>
"""

@PY.UBOT("countdown")
@PY.TOP_CMD
async def countdown_timer(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .countdown <detik>")
    try:
        detik = int(args[1])
        msg = await message.reply(f"⏱️ Countdown dimulai: {detik} detik")
        for i in range(detik, 0, -1):
            await asyncio.sleep(1)
            if i % 5 == 0 or i <= 3:
                await msg.edit(f"⏱️ {i} detik lagi...")
        await msg.edit("🔔 **WAKTU HABIS!**")
    except:
        await message.reply("❌ Error")
