from PyroUbot import *
import math

__MODULE__ = "𝐊𝐏𝐊𝐅𝐏𝐁"
__HELP__ = """
<blockquote><b>🔢 𝐊𝐏𝐊 & 𝐅𝐏𝐁</b>

 • <code>{0}kpk &lt;a> &lt;b></code> - Hitung KPK
 • <code>{0}fpb &lt;a> &lt;b></code> - Hitung FPB</blockquote>
"""

@PY.UBOT("kpk")
@PY.TOP_CMD
async def hitung_kpk(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .kpk <a> <b>")
    a, b = int(args[1]), int(args[2])
    kpk = abs(a*b) // math.gcd(a, b)
    await message.reply(f"🔢 **KPK dari {a} dan {b}:** {kpk}")

@PY.UBOT("fpb")
@PY.TOP_CMD
async def hitung_fpb(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .fpb <a> <b>")
    a, b = int(args[1]), int(args[2])
    fpb = math.gcd(a, b)
    await message.reply(f"🔢 **FPB dari {a} dan {b}:** {fpb}")
