from PyroUbot import *
import math

__MODULE__ = "𝐆𝐂𝐃_𝐋𝐂𝐌"
__HELP__ = """
<blockquote><b>🔢 𝐆𝐂𝐃 & 𝐋𝐂𝐌</b>

 • <code>{0}gcd &lt;a> &lt;b></code> - FPB
 • <code>{0}lcm &lt;a> &lt;b></code> - KPK</blockquote>
"""

@PY.UBOT("gcd")
@PY.TOP_CMD
async def gcd_calc(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .gcd <a> <b>")
    try:
        a, b = int(args[1]), int(args[2])
        hasil = math.gcd(a, b)
        await message.reply(f"🔢 FPB dari {a} dan {b} = {hasil}")
    except:
        await message.reply("❌ Error")

@PY.UBOT("lcm")
@PY.TOP_CMD
async def lcm_calc(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .lcm <a> <b>")
    try:
        a, b = int(args[1]), int(args[2])
        hasil = abs(a*b) // math.gcd(a, b)
        await message.reply(f"🔢 KPK dari {a} dan {b} = {hasil}")
    except:
        await message.reply("❌ Error")
