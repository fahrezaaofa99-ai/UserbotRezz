from PyroUbot import *
import random
import json
import os

__MODULE__ = "𝐆𝐨𝐦𝐛𝐚𝐥 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫"
__HELP__ = """
<blockquote><b>💘 𝐆𝐨𝐦𝐛𝐚𝐥 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

<b>💌 GENERATE GOMBAL</b>
 • <code>{0}gombal</code> - Gombal random
 • <code>{0}gombal &lt;nama></code> - Gombal untuk nama
 • <code>{0}gombaljadian</code> - Gombal jadian
 • <code>{0}gombalgalau</code> - Gombal galau

<b>📝 TAMBAH KOLEKSI</b>
 • <code>{0}addgombal &lt;teks></code> - Tambah gombal biasa
 • <code>{0}addjadian &lt;teks></code> - Tambah gombal jadian
 • <code>{0}addgalau &lt;teks></code> - Tambah gombal galau

<b>📋 LIST KOLEKSI</b>
 • <code>{0}listgombal</code> - List gombal biasa
 • <code>{0}listjadian</code> - List gombal jadian
 • <code>{0}listgalau</code> - List gombal galau

<b>🗑️ HAPUS KOLEKSI</b>
 • <code>{0}delgombal &lt;nomor></code> - Hapus gombal biasa
 • <code>{0}deljadian &lt;nomor></code> - Hapus gombal jadian
 • <code>{0}delgalau &lt;nomor></code> - Hapus gombal galau

<b>📊 STATISTIK</b>
 • <code>{0}statsgombal</code> - Statistik koleksi</blockquote>
"""

DATA_FILE = "gombal_data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    return {
        "gombal": [
            "Kamu tau gak kenapa aku suka sama kamu? Karena kamu kayak kopi, bikin aku melek setiap malem",
            "Aku bukan pelukis, tapi aku bisa gambar senyuman di wajah kamu",
            "Kamu kayak bintang, walau jauh tetap bersinar di hatiku",
            "Cuma kamu yang bisa bikin aku lupa sama pacar aku, soalnya aku gak punya pacar",
            "Kamu tau bedanya aku sama kamu? Aku ada di sini, kamu ada di hati aku"
        ],
        "jadian": [
            "Kamu kayak indomie, aku suka kalo kamu udah mateng",
            "Mau jadi baju aku? Biar kamu selalu nempel di aku",
            "Kamu kayak sambel, bikin lidah aku pedas-pedas sayang",
            "Kamu tau gak? Kalo kamu jadi kontol, aku jadi memek"
        ],
        "galau": [
            "Aku bukan apa-apa buat kamu, tapi kamu segalanya buat aku",
            "Sakitnya bukan saat dia pergi, tapi saat aku harus lupa",
            "Kenapa ya aku suka sama orang yang salah terus?",
            "Jangan tanya aku kenapa galau, karena jawabannya adalah kamu"
        ]
    }

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)

@PY.UBOT("gombal")
@PY.TOP_CMD
async def gombal(client, message):
    args = message.text.split(maxsplit=1)
    data = load_data()
    
    if len(args) > 1:
        nama = args[1]
        gombal_text = random.choice(data["gombal"])
        text = f"╭──〔 💘 *GOMBAL UNTUK {nama.upper()}* 〕\n│\n│ {gombal_text}\n│\n╰── ✨ *~ {nama} ~* ✨"
    else:
        gombal_text = random.choice(data["gombal"])
        text = f"╭──〔 💘 *GOMBALAN SPESIAL* 〕\n│\n│ {gombal_text}\n│\n╰── ✨ *Gombal Untukmu* ✨"
    
    await message.reply(text)

@PY.UBOT("gombaljadian")
@PY.TOP_CMD
async def gombal_jadian(client, message):
    data = load_data()
    gombal = random.choice(data["jadian"])
    
    await message.reply(
        f"╭──〔 😜 *GOMBAL JADIAN* 〕\n│\n│ {gombal}\n│\n╰── 🙏 *Maaf kalo receh*"
    )

@PY.UBOT("gombalgalau")
@PY.TOP_CMD
async def gombal_galau(client, message):
    data = load_data()
    gombal = random.choice(data["galau"])
    
    await message.reply(
        f"╭──〔 😢 *GOMBAL GALAU* 〕\n│\n│ {gombal}\n│\n╰── 💔 *Tetap semangat ya*"
    )

@PY.UBOT("addgombal")
@PY.TOP_CMD
async def add_gombal(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.addgombal <kata gombal>`")
    
    data = load_data()
    data["gombal"].append(args[1])
    save_data(data)
    
    await message.reply(f"✅ *Berhasil tambah gombal!*\n\n`{args[1][:100]}`")

@PY.UBOT("addjadian")
@PY.TOP_CMD
async def add_jadian(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.addjadian <kata jadian>`")
    
    data = load_data()
    data["jadian"].append(args[1])
    save_data(data)
    
    await message.reply(f"✅ *Berhasil tambah gombal jadian!*\n\n`{args[1][:100]}`")

@PY.UBOT("addgalau")
@PY.TOP_CMD
async def add_galau(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.addgalau <kata galau>`")
    
    data = load_data()
    data["galau"].append(args[1])
    save_data(data)
    
    await message.reply(f"✅ *Berhasil tambah gombal galau!*\n\n`{args[1][:100]}`")

@PY.UBOT("listgombal")
@PY.TOP_CMD
async def list_gombal(client, message):
    data = load_data()
    
    if not data["gombal"]:
        return await message.reply("📭 *Belum ada gombal tersimpan*")
    
    text = "📋 *LIST GOMBALAN*\n\n"
    for i, g in enumerate(data["gombal"], 1):
        text += f"`{i}.` {g[:60]}...\n"
        if i >= 10:
            text += f"\n_*Total {len(data['gombal'])} gombal_*"
            break
    
    await message.reply(text)

@PY.UBOT("listjadian")
@PY.TOP_CMD
async def list_jadian(client, message):
    data = load_data()
    
    if not data["jadian"]:
        return await message.reply("📭 *Belum ada gombal jadian*")
    
    text = "😜 *LIST GOMBAL JADIAN*\n\n"
    for i, g in enumerate(data["jadian"], 1):
        text += f"`{i}.` {g[:60]}...\n"
        if i >= 10:
            text += f"\n_*Total {len(data['jadian'])} gombal jadian_*"
            break
    
    await message.reply(text)

@PY.UBOT("listgalau")
@PY.TOP_CMD
async def list_galau(client, message):
    data = load_data()
    
    if not data["galau"]:
        return await message.reply("📭 *Belum ada gombal galau*")
    
    text = "😢 *LIST GOMBAL GALAU*\n\n"
    for i, g in enumerate(data["galau"], 1):
        text += f"`{i}.` {g[:60]}...\n"
        if i >= 10:
            text += f"\n_*Total {len(data['galau'])} gombal galau_*"
            break
    
    await message.reply(text)

@PY.UBOT("delgombal")
@PY.TOP_CMD
async def del_gombal(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.delgombal <nomor>`\n*Cek nomor pake:* `.listgombal`")
    
    try:
        idx = int(args[1]) - 1
        data = load_data()
        
        if idx < 0 or idx >= len(data["gombal"]):
            return await message.reply("❌ *Nomor tidak valid!*")
        
        deleted = data["gombal"].pop(idx)
        save_data(data)
        
        await message.reply(f"✅ *Berhasil hapus gombal:*\n`{deleted[:100]}...`")
    except ValueError:
        await message.reply("❌ *Masukkan nomor yang valid!*")

@PY.UBOT("deljadian")
@PY.TOP_CMD
async def del_jadian(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.deljadian <nomor>`\n*Cek nomor pake:* `.listjadian`")
    
    try:
        idx = int(args[1]) - 1
        data = load_data()
        
        if idx < 0 or idx >= len(data["jadian"]):
            return await message.reply("❌ *Nomor tidak valid!*")
        
        deleted = data["jadian"].pop(idx)
        save_data(data)
        
        await message.reply(f"✅ *Berhasil hapus gombal jadian:*\n`{deleted[:100]}...`")
    except ValueError:
        await message.reply("❌ *Masukkan nomor yang valid!*")

@PY.UBOT("delgalau")
@PY.TOP_CMD
async def del_galau(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ *Format:* `.delgalau <nomor>`\n*Cek nomor pake:* `.listgalau`")
    
    try:
        idx = int(args[1]) - 1
        data = load_data()
        
        if idx < 0 or idx >= len(data["galau"]):
            return await message.reply("❌ *Nomor tidak valid!*")
        
        deleted = data["galau"].pop(idx)
        save_data(data)
        
        await message.reply(f"✅ *Berhasil hapus gombal galau:*\n`{deleted[:100]}...`")
    except ValueError:
        await message.reply("❌ *Masukkan nomor yang valid!*")

@PY.UBOT("statsgombal")
@PY.TOP_CMD
async def stats_gombal(client, message):
    data = load_data()
    
    text = f"""
╭──〔 📊 *STATISTIK GOMBAL* 〕
│
│ 💘 Gombal biasa: {len(data['gombal'])}
│ 😜 Gombal jadian: {len(data['jadian'])}
│ 😢 Gombal galau: {len(data['galau'])}
│
│ 📦 Total koleksi: {len(data['gombal']) + len(data['jadian']) + len(data['galau'])}
│
╰── ✨ *Gombalin terus!* ✨
"""
    await message.reply(text)

