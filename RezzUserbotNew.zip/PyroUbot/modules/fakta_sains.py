from PyroUbot import *
import random

__MODULE__ = "𝐅𝐚𝐤𝐭𝐚𝐒𝐚𝐢𝐧𝐬"
__HELP__ = """
<blockquote><b>🔬 𝐅𝐚𝐤𝐭𝐚 𝐒𝐚𝐢𝐧𝐬</b>

 • <code>{0}faktasains</code> - Fakta sains random</blockquote>
"""

fakta_sains_list = [
    "Air mendidih di gunung lebih cepat karena tekanan udara rendah",
    "Kilat lebih panas dari permukaan matahari",
    "Setahun di Venus = 225 hari di Bumi",
    "Hujan di Jupiter terbuat dari berlian cair"
]

@PY.UBOT("faktasains")
@PY.TOP_CMD
async def fakta_sains_func(client, message):
    await message.reply(f"🔬 **Fakta Sains:**\n\n{random.choice(fakta_sains_list)}")
