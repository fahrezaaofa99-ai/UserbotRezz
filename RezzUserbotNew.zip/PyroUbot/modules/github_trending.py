from PyroUbot import *
import requests
from bs4 import BeautifulSoup

__MODULE__ = "𝐆𝐢𝐭𝐓𝐫𝐞𝐧𝐝"
__HELP__ = """
<blockquote><b>🐙 𝐆𝐢𝐭𝐇𝐮𝐛 𝐓𝐫𝐞𝐧𝐝𝐢𝐧𝐠</b>

 • <code>{0}trending</code> - Repository trending</blockquote>
"""

@PY.UBOT("trending")
@PY.TOP_CMD
async def github_trending(client, message):
    msg = await message.reply("🐙 Mengambil trending...")
    try:
        r = requests.get("https://github.com/trending")
        soup = BeautifulSoup(r.text, 'html.parser')
        repos = soup.find_all('h2', class_='h3 lh-condensed')
        text = "🐙 **GITHUB TRENDING**\n\n"
        for i, repo in enumerate(repos[:5], 1):
            name = repo.text.strip()
            text += f"{i}. {name}\n"
        await msg.edit(text)
    except:
        await msg.edit("❌ Error")
