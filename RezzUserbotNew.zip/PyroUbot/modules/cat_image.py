from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐚𝐭𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🐱 𝐂𝐚𝐭 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}cat</code> - Gambar kucing random</blockquote>
"""

@PY.UBOT("cat")
@PY.TOP_CMD
async def cat_image(client, message):
    msg = await message.reply("🐱 Mencari gambar...")
    try:
        r = requests.get("https://api.thecatapi.com/v1/images/search")
        if r.status_code == 200:
            img_url = r.json()[0]['url']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
