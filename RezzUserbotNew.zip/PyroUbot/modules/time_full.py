from PyroUbot import *

__MODULE__ = "𝐓𝐢𝐦𝐞𝐅𝐮𝐥𝐥"
__HELP__ = """
<blockquote><b>⏱️ 𝐓𝐢𝐦𝐞 𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐞𝐫</b>

 • <code>{0}jam_menit &lt;jam></code> - Jam ke Menit
 • <code>{0}menit_detik &lt;menit></code> - Menit ke Detik
 • <code>{0}hari_jam &lt;hari></code> - Hari ke Jam</blockquote>
"""

@PY.UBOT("jam_menit")
@PY.TOP_CMD
async def jam_to_menit_full(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("ERROR: .jam_menit <jam>")
    jam = float(args[1])
    menit = jam * 60
    await message.reply(f"⏱️ {jam} jam = {menit} menit")

@PY.UBOT("menit_detik")
@PY.TOP_CMD
async def menit_to_detik_full(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("ERROR: .menit_detik <menit>")
    menit = float(args[1])
    detik = menit * 60
    await message.reply(f"⏱️ {menit} menit = {detik} detik")

@PY.UBOT("hari_jam")
@PY.TOP_CMD
async def hari_to_jam_full(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("ERROR: .hari_jam <hari>")
    hari = float(args[1])
    jam = hari * 24
    await message.reply(f"⏱️ {hari} hari = {jam} jam")
