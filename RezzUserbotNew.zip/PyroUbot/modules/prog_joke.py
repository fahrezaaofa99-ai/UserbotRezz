from PyroUbot import *
import requests

__MODULE__ = "𝐏𝐫𝐨𝐠𝐉𝐨𝐤𝐞"
__HELP__ = """
<blockquote><b>💻 𝐏𝐫𝐨𝐠𝐫𝐚𝐦𝐦𝐢𝐧𝐠 𝐉𝐨𝐤𝐞</b>

 • <code>{0}progjoke</code> - Joke programmer</blockquote>
"""

@PY.UBOT("progjoke")
@PY.TOP_CMD
async def prog_joke(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Programming")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"💻 **Joke:**\n\n{data['joke']}")
            else:
                await message.reply(f"💻 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
