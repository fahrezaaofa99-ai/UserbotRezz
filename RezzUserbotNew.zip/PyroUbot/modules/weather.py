from PyroUbot import *
import requests

__MODULE__ = "𝐖𝐞𝐚𝐭𝐡𝐞𝐫"
__HELP__ = """
<blockquote><b>🌤️ 𝐖𝐞𝐚𝐭𝐡𝐞𝐫</b>

 • <code>{0}weather &lt;kota></code> - Cek cuaca</blockquote>
"""

@PY.UBOT("weather")
@PY.TOP_CMD
async def weather(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .weather <kota>")
    msg = await message.reply(f"🌤️ Mencari cuaca di {args[1]}...")
    try:
        r = requests.get(f"https://wttr.in/{args[1]}?format=%C+%t+%w+%h", timeout=10)
        if r.status_code == 200:
            await msg.edit(f"🌤️ **Cuaca di {args[1]}**\n\n{r.text}")
        else:
            await msg.edit("❌ Gagal mengambil cuaca")
    except:
        await msg.edit("❌ Error")
