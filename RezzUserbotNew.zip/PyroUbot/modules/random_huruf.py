from PyroUbot import *
import random
import string

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐇𝐮𝐫𝐮𝐟"
__HELP__ = """
<blockquote><b>🔤 𝐑𝐚𝐧𝐝𝐨𝐦 𝐇𝐮𝐫𝐮𝐟</b>

 • <code>{0}huruf &lt;n></code> - Random huruf sebanyak n</blockquote>
"""

@PY.UBOT("huruf")
@PY.TOP_CMD
async def random_letters(client, message):
    args = message.text.split()
    n = int(args[1]) if len(args) > 1 else 5
    huruf = ''.join(random.choice(string.ascii_letters) for _ in range(n))
    await message.reply(f"🔤 **Random Huruf:** `{huruf}`")
