from PyroUbot import *
import time

__MODULE__ = "𝐔𝐩𝐭𝐢𝐦𝐞"
__HELP__ = """
<blockquote><b>⏱️ 𝐔𝐩𝐭𝐢𝐦𝐞</b>

 • <code>{0}uptime</code> - Lama bot aktif</blockquote>
"""

START_TIME = time.time()

@PY.UBOT("uptime")
@PY.TOP_CMD
async def uptime_bot(client, message):
    uptime_seconds = int(time.time() - START_TIME)
    days = uptime_seconds // 86400
    hours = (uptime_seconds % 86400) // 3600
    minutes = (uptime_seconds % 3600) // 60
    seconds = uptime_seconds % 60
    await message.reply(f"⏱️ **Uptime:** {days}d {hours}h {minutes}m {seconds}s")
