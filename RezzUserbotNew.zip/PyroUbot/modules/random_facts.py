from PyroUbot import *
import requests
import random

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦 𝐅𝐚𝐜𝐭𝐬"
__HELP__ = """
<blockquote><b>📢 𝐑𝐚𝐧𝐝𝐨𝐦 𝐅𝐚𝐜𝐭𝐬</b>

 • <code>{0}fakta</code> - Fakta random
 • <code>{0}faktasains</code> - Fakta sains
 • <code>{0}faktaunik</code> - Fakta unik
 • <code>{0}faktahewan</code> - Fakta hewan
 • <code>{0}faktamanusia</code> - Fakta tentang manusia</blockquote>
"""

facts = {
    "umum": [
        "Hidung manusia bisa mengingat 50.000 bau berbeda",
        "Mata kita tidak berubah ukuran sejak lahir",
        "Jantung wanita berdetak lebih cepat dari pria",
        "Kuku jari tumbuh 2x lebih cepat dari kuku kaki",
        "Tulang terkuat di tubuh adalah tulang paha"
    ],
    "sains": [
        "Air mendidih di gunung lebih cepat karena tekanan udara rendah",
        "Kilat lebih panas dari permukaan matahari",
        "Setahun di Venus = 225 hari di Bumi",
        "Hujan di Jupiter terbuat dari berlian cair"
    ],
    "unik": [
        "Kangguru tidak bisa jalan mundur",
        "Kuda nil susunya berwarna pink",
        "Bau pisang sama dengan molekul isoamyl acetate"
    ],
    "hewan": [
        "Gurita punya 3 jantung",
        "Burung unta punya mata lebih besar dari otaknya",
        "Lumba-lumba bisa tidur dengan satu mata terbuka"
    ],
    "manusia": [
        "Manusia bisa tidur 3 menit tanpa bernafas",
        "Jantung manusia berdetak 100.000 kali sehari",
        "Kulit manusia berganti setiap 27 hari"
    ]
}

@PY.UBOT("fakta")
@PY.TOP_CMD
async def random_fact(client, message):
    fact = random.choice(facts["umum"])
    await message.reply(f"📢 **FAKTA RANDOM**\n\n{fact}")

@PY.UBOT("faktasains")
@PY.TOP_CMD
async def sains_fact(client, message):
    fact = random.choice(facts["sains"])
    await message.reply(f"🔬 **FAKTA SAINS**\n\n{fact}")

@PY.UBOT("faktaunik")
@PY.TOP_CMD
async def unik_fact(client, message):
    fact = random.choice(facts["unik"])
    await message.reply(f"✨ **FAKTA UNIK**\n\n{fact}")

@PY.UBOT("faktahewan")
@PY.TOP_CMD
async def hewan_fact(client, message):
    fact = random.choice(facts["hewan"])
    await message.reply(f"🐾 **FAKTA HEWAN**\n\n{fact}")

@PY.UBOT("faktamanusia")
@PY.TOP_CMD
async def manusia_fact(client, message):
    fact = random.choice(facts["manusia"])
    await message.reply(f"👤 **FAKTA MANUSIA**\n\n{fact}")
