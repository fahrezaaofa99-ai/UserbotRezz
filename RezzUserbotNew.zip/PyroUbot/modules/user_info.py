from PyroUbot import *

__MODULE__ = "𝐔𝐬𝐞𝐫𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>👤 𝐔𝐬𝐞𝐫 𝐈𝐧𝐟𝐨</b>

 • <code>{0}userinfo &lt;reply/userid></code> - Info user</blockquote>
"""

@PY.UBOT("userinfo")
@PY.TOP_CMD
async def user_info(client, message):
    user = None
    if message.reply_to_message:
        user = message.reply_to_message.from_user
    elif message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else None:
        try:
            user = await client.get_users(message.text.split()[1])
        except:
            pass
    else:
        user = message.from_user
    
    if user:
        text = f"""
╭──〔 👤 USER INFO 〕
│
│ 📌 **ID:** `{user.id}`
│ 👤 **Nama:** {user.first_name}
│ 🔗 **Username:** @{user.username if user.username else 'Tidak ada'}
│ 🤖 **Bot:** {'Ya' if user.is_bot else 'Tidak'}
│
╰── ✨ User Info ✨"""
        await message.reply(text)
    else:
        await message.reply("❌ User tidak ditemukan!")
