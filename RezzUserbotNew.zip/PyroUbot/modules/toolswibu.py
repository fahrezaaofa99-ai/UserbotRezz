# Nama file: /root/RezzUserbot/PyroUbot/modules/anime.py
# Fitur: Anime & Manga Database

from PyroUbot import *
import requests
import random
from datetime import datetime

__MODULE__ = "ᴀɴɪᴍᴇ"
__HELP__ = """
<blockquote><b>🎌 ANIME & WEEB STUFF</b>

<b>🔍 ANIME INFO</b>
 • <code>{0}anime</code> [judul] - Cari info anime
   Contoh: <code>{0}anime naruto</code>

 • <code>{0}manga</code> [judul] - Cari info manga
   Contoh: <code>{0}manga one piece</code>

 • <code>{0}character</code> [nama] - Cari karakter anime
   Contoh: <code>{0}character gojo</code>

<b>📅 SCHEDULE</b>
 • <code>{0}season</code> [tahun] [musim] - Anime season tertentu
   Musim: winter, spring, summer, fall
   Contoh: <code>{0}season 2024 winter</code>

 • <code>{0}airing</code> - Anime yang sedang tayang

<b>🎲 RANDOM</b>
 • <code>{0}randomanime</code> - Random anime
 • <code>{0}randomchar</code> - Random karakter
 • <code>{0}randomquote</code> - Random quote anime

<b>📊 RANKING</b>
 • <code>{0}topanime</code> - Top 10 anime terpopuler
 • <code>{0}topmanga</code> - Top 10 manga terpopuler
 • <code>{0}topchar</code> - Top 10 karakter favorit

<b>🖼️ WAIFU</b>
 • <code>{0}waifu</code> - Random waifu image
 • <code>{0}neko</code> - Random neko image
 • <code>{0}husbu</code> - Random husbu image
 • <code>{0}shinobu</code> - Random shinobu image
 • <code>{0}megumin</code> - Random megumin image</blockquote>
"""

# Jikan API (MyAnimeList unofficial API)
BASE_URL = "https://api.jikan.moe/v4"

@PY.UBOT("anime")
@PY.TOP_CMD
async def search_anime(client, message):
    """Cari info anime"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul anime!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🔍 Mencari anime: {query}...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/anime",
            params={"q": query, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit(f"❌ Anime '{query}' tidak ditemukan")
        
        anime = data['data'][0]
        
        # Ambil data
        title = anime['title']
        title_jp = anime['title_japanese']
        episodes = anime.get('episodes', '?')
        status = anime['status']
        score = anime.get('score', 'N/A')
        synopsis = anime['synopsis'][:300] + "..." if anime['synopsis'] else "No synopsis"
        url = anime['url']
        image = anime['images']['jpg']['image_url']
        
        await msg.edit(
            f"<b>🎌 ANIME INFO</b>\n\n"
            f"<b>{title}</b> ({title_jp})\n\n"
            f"📺 <b>Episodes:</b> {episodes}\n"
            f"📊 <b>Status:</b> {status}\n"
            f"⭐ <b>Score:</b> {score}\n\n"
            f"📝 <b>Synopsis:</b> {synopsis}\n\n"
            f"🔗 <a href='{url}'>MyAnimeList</a>",
            disable_web_page_preview=False
        )
        
        # Kirim gambar
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("manga")
@PY.TOP_CMD
async def search_manga(client, message):
    """Cari info manga"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul manga!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🔍 Mencari manga: {query}...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/manga",
            params={"q": query, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit(f"❌ Manga '{query}' tidak ditemuan")
        
        manga = data['data'][0]
        
        title = manga['title']
        title_jp = manga['title_japanese']
        chapters = manga.get('chapters', '?')
        volumes = manga.get('volumes', '?')
        status = manga['status']
        score = manga.get('score', 'N/A')
        synopsis = manga['synopsis'][:300] + "..." if manga['synopsis'] else "No synopsis"
        url = manga['url']
        image = manga['images']['jpg']['image_url']
        
        await msg.edit(
            f"<b>📚 MANGA INFO</b>\n\n"
            f"<b>{title}</b> ({title_jp})\n\n"
            f"📖 <b>Chapters:</b> {chapters}\n"
            f"📚 <b>Volumes:</b> {volumes}\n"
            f"📊 <b>Status:</b> {status}\n"
            f"⭐ <b>Score:</b> {score}\n\n"
            f"📝 <b>Synopsis:</b> {synopsis}\n\n"
            f"🔗 <a href='{url}'>MyAnimeList</a>",
            disable_web_page_preview=False
        )
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("character")
@PY.TOP_CMD
async def search_character(client, message):
    """Cari karakter anime"""
    if len(message.command) < 2:
        return await message.reply("Masukkan nama karakter!")
    
    query = ' '.join(message.command[1:])
    msg = await message.reply(f"🔍 Mencari karakter: {query}...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/characters",
            params={"q": query, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit(f"❌ Karakter '{query}' tidak ditemukan")
        
        char = data['data'][0]
        
        name = char['name']
        name_jp = char.get('name_kanji', 'N/A')
        about = char['about'][:400] + "..." if char['about'] else "No description"
        url = char['url']
        image = char['images']['jpg']['image_url']
        
        # Ambil anime appearances
        anime_list = []
        for anime in char.get('anime', [])[:3]:
            anime_list.append(anime['anime']['name'])
        
        anime_str = "\n".join([f"• {a}" for a in anime_list]) if anime_list else "Tidak ada data"
        
        await msg.edit(
            f"<b>👤 CHARACTER INFO</b>\n\n"
            f"<b>{name}</b> ({name_jp})\n\n"
            f"📺 <b>Appearances:</b>\n{anime_str}\n\n"
            f"📝 <b>About:</b> {about}\n\n"
            f"🔗 <a href='{url}'>MyAnimeList</a>",
            disable_web_page_preview=False
        )
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("season")
@PY.TOP_CMD
async def season_anime(client, message):
    """Anime per season"""
    if len(message.command) < 3:
        return await message.reply(
            "Format: <code>season [tahun] [musim]</code>\n"
            "Musim: winter, spring, summer, fall\n"
            "Contoh: <code>season 2024 winter</code>"
        )
    
    year = message.command[1]
    season = message.command[2].lower()
    
    valid_seasons = ['winter', 'spring', 'summer', 'fall']
    if season not in valid_seasons:
        return await message.reply(f"Musim harus: {', '.join(valid_seasons)}")
    
    msg = await message.reply(f"📅 Mencari anime {season} {year}...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/seasons/{year}/{season}",
            params={"limit": 10},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit(f"❌ Tidak ada anime di {season} {year}")
        
        text = f"<b>📅 ANIME {season.upper()} {year}</b>\n\n"
        
        for i, anime in enumerate(data['data'][:10], 1):
            title = anime['title']
            score = anime.get('score', 'N/A')
            episodes = anime.get('episodes', '?')
            text += f"{i}. <b>{title}</b> | ⭐{score} | 📺{episodes} eps\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("airing")
@PY.TOP_CMD
async def airing_anime(client, message):
    """Anime yang sedang tayang"""
    msg = await message.reply("📺 Mencari anime yang sedang tayang...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/seasons/now",
            params={"limit": 10},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        text = "<b>📺 ANIME SEDANG TAYANG</b>\n\n"
        
        for i, anime in enumerate(data['data'][:10], 1):
            title = anime['title']
            score = anime.get('score', 'N/A')
            episodes = anime.get('episodes', '?')
            text += f"{i}. <b>{title}</b> | ⭐{score} | 📺{episodes} eps\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("randomanime")
@PY.TOP_CMD
async def random_anime(client, message):
    """Random anime"""
    msg = await message.reply("🎲 Mencari anime random...")
    
    try:
        # Dapatkan random page
        page = random.randint(1, 50)
        
        response = requests.get(
            f"{BASE_URL}/top/anime",
            params={"page": page, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit("❌ Tidak dapat anime random")
        
        anime = random.choice(data['data'])
        
        title = anime['title']
        title_jp = anime['title_japanese']
        episodes = anime.get('episodes', '?')
        status = anime['status']
        score = anime.get('score', 'N/A')
        synopsis = anime['synopsis'][:300] + "..." if anime['synopsis'] else "No synopsis"
        url = anime['url']
        image = anime['images']['jpg']['image_url']
        
        await msg.edit(
            f"<b>🎲 RANDOM ANIME</b>\n\n"
            f"<b>{title}</b> ({title_jp})\n\n"
            f"📺 <b>Episodes:</b> {episodes}\n"
            f"📊 <b>Status:</b> {status}\n"
            f"⭐ <b>Score:</b> {score}\n\n"
            f"📝 <b>Synopsis:</b> {synopsis}\n\n"
            f"🔗 <a href='{url}'>MyAnimeList</a>",
            disable_web_page_preview=False
        )
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("randomchar")
@PY.TOP_CMD
async def random_character(client, message):
    """Random karakter"""
    msg = await message.reply("🎲 Mencari karakter random...")
    
    try:
        # Dapatkan random page
        page = random.randint(1, 50)
        
        response = requests.get(
            f"{BASE_URL}/top/characters",
            params={"page": page, "limit": 1},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        if not data['data']:
            return await msg.edit("❌ Tidak dapat karakter random")
        
        char = random.choice(data['data'])
        
        name = char['name']
        name_jp = char.get('name_kanji', 'N/A')
        about = char['about'][:400] + "..." if cha['about'] else "No description"
        url = char['url']
        image = char['images']['jpg']['image_url']
        
        await msg.edit(
            f"<b>🎲 RANDOM CHARACTER</b>\n\n"
            f"<b>{name}</b> ({name_jp})\n\n"
            f"📝 <b>About:</b> {about}\n\n"
            f"🔗 <a href='{url}'>MyAnimeList</a>",
            disable_web_page_preview=False
        )
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("randomquote")
@PY.TOP_CMD
async def random_quote(client, message):
    """Random anime quote"""
    try:
        # AnimeChan API
        response = requests.get("https://animechan.xyz/api/random", timeout=10)
        
        if response.status_code != 200:
            return await message.reply("❌ Gagal mengambil quote")
        
        data = response.json()
        
        quote = data['quote']
        character = data['character']
        anime = data['anime']
        
        await message.reply(
            f"<b>💬 RANDOM ANIME QUOTE</b>\n\n"
            f"<i>\"{quote}\"</i>\n\n"
            f"— {character} ({anime})"
        )
        
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("topanime")
@PY.TOP_CMD
async def top_anime(client, message):
    """Top 10 anime terpopuler"""
    msg = await message.reply("📊 Mengambil data top anime...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/top/anime",
            params={"limit": 10},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        text = "<b>📊 TOP 10 ANIME</b>\n\n"
        
        for i, anime in enumerate(data['data'], 1):
            title = anime['title']
            score = anime.get('score', 'N/A')
            episodes = anime.get('episodes', '?')
            text += f"{i}. <b>{title}</b>\n   ⭐{score} | 📺{episodes} eps\n\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("topmanga")
@PY.TOP_CMD
async def top_manga(client, message):
    """Top 10 manga terpopuler"""
    msg = await message.reply("📊 Mengambil data top manga...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/top/manga",
            params={"limit": 10},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        text = "<b>📊 TOP 10 MANGA</b>\n\n"
        
        for i, manga in enumerate(data['data'], 1):
            title = manga['title']
            score = manga.get('score', 'N/A')
            chapters = manga.get('chapters', '?')
            text += f"{i}. <b>{title}</b>\n   ⭐{score} | 📖{chapters} chapter\n\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("topchar")
@PY.TOP_CMD
async def top_characters(client, message):
    """Top 10 karakter favorit"""
    msg = await message.reply("📊 Mengambil data top karakter...")
    
    try:
        response = requests.get(
            f"{BASE_URL}/top/characters",
            params={"limit": 10},
            timeout=10
        )
        
        if response.status_code != 200:
            return await msg.edit("❌ Gagal mengambil data")
        
        data = response.json()
        
        text = "<b>📊 TOP 10 KARAKTER</b>\n\n"
        
        for i, char in enumerate(data['data'], 1):
            name = char['name']
            anime_count = len(char.get('anime', []))
            text += f"{i}. <b>{name}</b>\n   📺 Muncul di {anime_count} anime\n\n"
        
        await msg.edit(text)
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== WAIFU IMAGES ====================

@PY.UBOT("waifu")
@PY.TOP_CMD
async def waifu_image(client, message):
    """Random waifu image"""
    msg = await message.reply("🔍 Mencari waifu...")
    
    try:
        # Waifu.im API
        response = requests.get(
            "https://waifu.im/api",
            params={
                "tag": "waifu",
                "is_nsfw": "false"
            },
            timeout=10
        )
        
        if response.status_code != 200:
            # Fallback ke waifu.pics
            response = requests.get("https://api.waifu.pics/sfw/waifu", timeout=10)
            data = response.json()
            image_url = data['url']
        else:
            data = response.json()
            image_url = data['images'][0]['url']
        
        await msg.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image_url,
            caption="✨ <b>Waifu untukmu</b>",
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("neko")
@PY.TOP_CMD
async def neko_image(client, message):
    """Random neko image"""
    msg = await message.reply("🔍 Mencari neko...")
    
    try:
        response = requests.get("https://api.waifu.pics/sfw/neko", timeout=10)
        data = response.json()
        image_url = data['url']
        
        await msg.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image_url,
            caption="🐱 <b>Neko untukmu</b>",
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("husbu")
@PY.TOP_CMD
async def husbu_image(client, message):
    """Random husbu image"""
    msg = await message.reply("🔍 Mencari husbu...")
    
    try:
        response = requests.get("https://api.waifu.pics/sfw/husbu", timeout=10)
        data = response.json()
        image_url = data['url']
        
        await msg.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image_url,
            caption="💙 <b>Husbu untukmu</b>",
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("shinobu")
@PY.TOP_CMD
async def shinobu_image(client, message):
    """Random shinobu image"""
    msg = await message.reply("🔍 Mencari shinobu...")
    
    try:
        response = requests.get("https://api.waifu.pics/sfw/shinobu", timeout=10)
        data = response.json()
        image_url = data['url']
        
        await msg.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image_url,
            caption="👘 <b>Shinobu</b>",
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("megumin")
@PY.TOP_CMD
async def megumin_image(client, message):
    """Random megumin image"""
    msg = await message.reply("🔍 Mencari megumin...")
    
    try:
        response = requests.get("https://api.waifu.pics/sfw/megumin", timeout=10)
        data = response.json()
        image_url = data['url']
        
        await msg.delete()
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=image_url,
            caption="🔥 <b>EXPLOSION!</b>",
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")
