from PyroUbot import *
import requests

__MODULE__ = "𝐉𝐨𝐤𝐞 𝐀𝐏𝐈"
__HELP__ = """
<blockquote><b>😂 𝐉𝐨𝐤𝐞 𝐀𝐏𝐈</b>

 • <code>{0}programmingjoke</code> - Joke programmer
 • <code>{0}randomjoke</code> - Joke random
 • <code>{0}punjoke</code> - Pun joke
 • <code>{0}spookyjoke</code> - Joke horor</blockquote>
"""

@PY.UBOT("programmingjoke")
@PY.TOP_CMD
async def programming_joke(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Programming")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"💻 **Joke:**\n\n{data['joke']}")
            else:
                await message.reply(f"💻 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("randomjoke")
@PY.TOP_CMD
async def random_joke_api(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Any")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"😂 **Joke:**\n\n{data['joke']}")
            else:
                await message.reply(f"😂 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("punjoke")
@PY.TOP_CMD
async def pun_joke_api(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Pun")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"😄 **Pun:**\n\n{data['joke']}")
            else:
                await message.reply(f"😄 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("spookyjoke")
@PY.TOP_CMD
async def spooky_joke(client, message):
    try:
        r = requests.get("https://v2.jokeapi.dev/joke/Dark")
        if r.status_code == 200:
            data = r.json()
            if data['type'] == 'single':
                await message.reply(f"👻 **Spooky:**\n\n{data['joke']}")
            else:
                await message.reply(f"👻 **{data['setup']}**\n\n👉 {data['delivery']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
