import os
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter, ImageEnhance
from pyrogram import Client
from pyrogram.types import Message, User, Chat
from PyroUbot import *
import random
from datetime import datetime
import math
import asyncio
import textwrap

__MODULE__ = "ᴄᴇᴋ ɪᴅ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴇᴋ ɪᴅ ⦫</b>
<blockquote>⎆ perintah :
ᚗ <code>{0}cekid</code>
⊶ Untuk Mengambil Data User/Channel/Grup.
</blockquote>
"""

# Font setup
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
DEFAULT_PROFILE_PATH = "storage/default.jpg"

# Warna-warna KTP
KTP_COLORS = {
    'bg': (245, 245, 245),  # Putih gading
    'header': (25, 55, 110),  # Biru tua
    'text': (30, 30, 30),  # Hitam
    'border': (200, 45, 45),  # Merah
    'nik_bg': (240, 240, 240),  # Abu-abu muda
    'gold': (255, 215, 0),  # Emas
}

def hex_to_rgb(hex_color):
    """Konversi hex ke RGB"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def create_ktp_background(width, height):
    """Membuat background kertas KTP"""
    img = Image.new('RGB', (width, height), KTP_COLORS['bg'])
    draw = ImageDraw.Draw(img)
    
    # Border merah khas KTP
    draw.rectangle([(0, 0), (width-1, height-1)], outline=KTP_COLORS['border'], width=3)
    draw.rectangle([(5, 5), (width-6, height-6)], outline=KTP_COLORS['border'], width=1)
    
    # Header biru
    draw.rectangle([(10, 10), (width-10, 70)], fill=KTP_COLORS['header'])
    
    # Garis emas di header
    draw.line([(10, 40), (width-10, 40)], fill=KTP_COLORS['gold'], width=2)
    
    return img, draw

async def get_profile_photo(client, user_id):
    """Mendapatkan foto profil user"""
    try:
        profile_photo_path = f"downloads/profile_{user_id}.jpg"
        os.makedirs("downloads", exist_ok=True)
        
        async for photo in client.get_chat_photos(user_id, limit=1):
            await client.download_media(photo.file_id, file_name=profile_photo_path)
            return profile_photo_path
    except:
        return None
    return None

def create_default_ktp_photo():
    """Membuat foto default ala KTP"""
    img = Image.new('RGB', (180, 220), (200, 200, 200))
    draw = ImageDraw.Draw(img)
    
    # Background abu-abu
    draw.rectangle([(0, 0), (180, 220)], fill=(220, 220, 220))
    
    # Siluet orang
    draw.ellipse([40, 20, 140, 100], fill=(150, 150, 150), outline=(100, 100, 100), width=2)
    draw.rectangle([30, 100, 150, 180], fill=(150, 150, 150), outline=(100, 100, 100), width=2)
    
    # Text "FOTO"
    try:
        font = ImageFont.truetype(FONT_PATH, 20)
    except:
        font = ImageFont.load_default()
    draw.text((60, 190), "FOTO", fill=(100, 100, 100), font=font)
    
    return img

def wrap_text(text, font, max_width, draw):
    """Membungkus teks agar tidak melebihi lebar"""
    lines = []
    words = text.split()
    current_line = []
    
    for word in words:
        test_line = ' '.join(current_line + [word])
        bbox = draw.textbbox((0, 0), test_line, font=font)
        width = bbox[2] - bbox[0]
        
        if width <= max_width:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    
    if current_line:
        lines.append(' '.join(current_line))
    
    return lines

async def generate_ktp_card(client, user, chat):
    """Generate KTP keren"""
    
    # Ukuran KTP (standar KTP: 85.6mm x 53.98mm, kita scale)
    width, height = 900, 570
    
    # Buat background KTP
    img, draw = create_ktp_background(width, height)
    
    # Header text
    try:
        font_header = ImageFont.truetype(FONT_PATH, 28)
        font_provinsi = ImageFont.truetype(FONT_PATH, 22)
        font_nik = ImageFont.truetype(FONT_PATH, 26)
        font_label = ImageFont.truetype(FONT_REGULAR, 18)
        font_value = ImageFont.truetype(FONT_PATH, 18)
        font_small = ImageFont.truetype(FONT_REGULAR, 14)
    except:
        font_header = ImageFont.load_default()
        font_provinsi = ImageFont.load_default()
        font_nik = ImageFont.load_default()
        font_label = ImageFont.load_default()
        font_value = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Header provinsi
    draw.text((30, 20), "PROVINSI DKI JAKARTA", fill=(255, 255, 255), font=font_provinsi)
    draw.text((30, 45), "KOTA JAKARTA", fill=(255, 255, 255), font=font_header)
    
    # Dapatkan data user
    first_name = user.first_name or "User"
    last_name = user.last_name or ""
    full_name = f"{first_name} {last_name}".strip().upper()
    if len(full_name) > 30:
        full_name = full_name[:27] + "..."
    
    username = user.username or ""
    user_id = str(user.id)
    dc_id = str(getattr(user, 'dc_id', '5'))
    is_premium = getattr(user, 'is_premium', False)
    
    # Generate NIK dari user_id (15 digit, kalo kurang ditambah random)
    nik = user_id.zfill(16)[:16]
    if len(nik) < 16:
        nik = nik + str(random.randint(100, 999))[:16-len(nik)]
    
    # Download foto profil
    photo_path = await get_profile_photo(client, user.id)
    
    if photo_path and os.path.exists(photo_path):
        try:
            # Crop foto jadi persegi
            photo = Image.open(photo_path).convert('RGB')
            photo = ImageOps.fit(photo, (180, 220), Image.LANCZOS)
        except:
            photo = create_default_ktp_photo()
    else:
        photo = create_default_ktp_photo()
    
    # Taruh foto di sisi kanan
    img.paste(photo, (680, 85))
    
    # Garis pembatas foto
    draw.rectangle([(678, 83), (862, 307)], outline=KTP_COLORS['border'], width=2)
    
    # NIK
    draw.text((30, 90), "NIK", fill=KTP_COLORS['text'], font=font_label)
    
    # Background NIK
    nik_bbox = draw.textbbox((0, 0), nik, font=font_nik)
    nik_width = nik_bbox[2] - nik_bbox[0]
    draw.rectangle([(30, 110), (30 + nik_width + 20, 145)], fill=KTP_COLORS['nik_bg'], outline=KTP_COLORS['border'], width=1)
    draw.text((40, 115), nik, fill=KTP_COLORS['text'], font=font_nik)
    
    # Data diri (kiri)
    y_start = 165
    line_height = 32
    
    data_kiri = [
        ("Nama", full_name),
        ("Tempat/Tgl Lahir", f"JAKARTA, {random.randint(1,28):02d}-{random.randint(1,12):02d}-{random.randint(1980,2000)}"),
        ("Jenis Kelamin", "LAKI-LAKI" if random.choice([True, False]) else "PEREMPUAN"),
        ("Gol. Darah", random.choice(["A", "B", "O", "AB"])),
    ]
    
    for i, (label, value) in enumerate(data_kiri):
        y = y_start + (i * line_height)
        draw.text((30, y), label + " :", fill=KTP_COLORS['text'], font=font_label)
        
        # Wrap text if too long
        if len(value) > 25:
            value = value[:22] + "..."
        draw.text((170, y), value, fill=KTP_COLORS['text'], font=font_value)
    
    # Alamat (bisa multi-line)
    alamat = f"JL. {username.upper() or 'USER'} NO. {random.randint(1,999)}"
    draw.text((30, y_start + (4 * line_height)), "Alamat", fill=KTP_COLORS['text'], font=font_label)
    draw.text((30, y_start + (4 * line_height) + 5), ":", fill=KTP_COLORS['text'], font=font_label)
    
    # Wrap alamat
    alamat_lines = wrap_text(alamat, font_value, 400, draw)
    for j, line in enumerate(alamat_lines[:2]):
        draw.text((170, y_start + (4 * line_height) + (j * 25)), line, fill=KTP_COLORS['text'], font=font_value)
    
    # Data kanan (setelah alamat)
    y_kanan = y_start + (6 * line_height) + 30
    
    data_kanan = [
        ("RT/RW", f"{random.randint(1,20):03d}/{random.randint(1,20):03d}"),
        ("Kel/Desa", "RAGUNAN"),
        ("Kecamatan", "PASAR MINGGU"),
        ("Agama", random.choice(["ISLAM", "KRISTEN", "KATHOLIK", "HINDU", "BUDHA"])),
        ("Status Perkawinan", random.choice(["BELUM KAWIN", "KAWIN", "DUDA", "JANDA"])),
        ("Pekerjaan", random.choice(["PELAJAR", "KARYAWAN", "WIRAUSAHA", "GURU", "PETANI"])),
        ("Kewarganegaraan", "WNI"),
    ]
    
    for i, (label, value) in enumerate(data_kanan):
        y = y_kanan + (i * line_height)
        draw.text((30, y), label + " :", fill=KTP_COLORS['text'], font=font_label)
        draw.text((170, y), value, fill=KTP_COLORS['text'], font=font_value)
    
    # Berlaku hingga
    y_akhir = y_kanan + (len(data_kanan) * line_height) + 10
    draw.text((30, y_akhir), "Berlaku Hingga", fill=KTP_COLORS['text'], font=font_label)
    draw.text((30, y_akhir + 5), ":", fill=KTP_COLORS['text'], font=font_label)
    draw.text((170, y_akhir), "SEUMUR HIDUP", fill=KTP_COLORS['text'], font=font_value)
    
    # Footer
    today = datetime.now().strftime("%d-%m-%Y")
    draw.text((30, height-45), "JAKARTA", fill=KTP_COLORS['text'], font=font_provinsi)
    draw.text((30, height-25), today, fill=KTP_COLORS['text'], font=font_small)
    
    # Data Center dan Premium di pojok kanan bawah
    dc_text = f"DC: {dc_id}"
    premium_text = "⭐ PREMIUM" if is_premium else "FREE"
    
    draw.text((750, height-45), dc_text, fill=KTP_COLORS['header'], font=font_small)
    premium_color = KTP_COLORS['gold'] if is_premium else (100, 100, 100)
    draw.text((750, height-25), premium_text, fill=premium_color, font=font_small)
    
    # Simpan gambar
    output_path = f"downloads/ktp_{user.id}_{random.randint(1000, 9999)}.jpg"
    os.makedirs("downloads", exist_ok=True)
    img.save(output_path, "JPEG", quality=95)
    
    # Bersihin file temporary
    if photo_path and os.path.exists(photo_path):
        try:
            os.remove(photo_path)
        except:
            pass
    
    return output_path

@PY.UBOT("cekid")
async def cekid_command(client, message: Message):
    """Handler untuk perintah cekid"""
    
    # Tentukan target user
    target_user = message.from_user
    
    if message.reply_to_message:
        if message.reply_to_message.from_user:
            target_user = message.reply_to_message.from_user
    
    if len(message.text.split()) > 1:
        try:
            target = message.text.split()[1]
            target_user = await client.get_users(target)
        except:
            return await message.reply("<b>❌ User tidak ditemukan!</b>")
    
    # Kirim loading message
    loading = await message.reply("**⏳ Membuat KTP keren...**")
    
    try:
        # Generate KTP
        card_path = await generate_ktp_card(client, target_user, message.chat)
        
        # Siapkan caption dengan blockquote
        name_link = f'<a href="tg://user?id={target_user.id}">{target_user.first_name}</a>'
        username = f"@{target_user.username}" if target_user.username else "─"
        premium = "✅ PREMIUM" if getattr(target_user, 'is_premium', False) else "❌ FREE"
        dc = getattr(target_user, 'dc_id', '?')
        
        caption = f"""
<blockquote>
╔═══════════════════════╗
║     𝐊𝐀𝐑𝐓𝐔 𝐓𝐀𝐍𝐃𝐀 𝐏𝐄𝐍𝐃𝐔𝐃𝐔𝐊     ║
║      𝐑𝐄𝐏𝐔𝐁𝐋𝐈𝐊 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌      ║
╚═══════════════════════╝

👤 Nama: {name_link}
🆔 User ID: <code>{target_user.id}</code>
🔗 Username: {username}
📡 Data Center: <code>DC{dc}</code>
✨ Status: {premium}
💬 Chat ID: <code>{message.chat.id}</code>

╔═══════════════════════╗
║  Generated by @{client.me.username}  ║
╚═══════════════════════╝
</blockquote>
"""
        
        # Kirim hasil
        await loading.delete()
        await message.reply_photo(
            photo=card_path,
            caption=caption,
            quote=True
        )
        
        # Hapus file setelah dikirim
        try:
            os.remove(card_path)
        except:
            pass
            
    except Exception as e:
        await loading.edit_text(f"<b>❌ Error: {str(e)}</b>")
