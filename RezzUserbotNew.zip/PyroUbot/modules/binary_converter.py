from PyroUbot import *

__MODULE__ = "𝐁𝐢𝐧𝐚𝐫𝐲"
__HELP__ = """
<blockquote><b>🔢 𝐁𝐢𝐧𝐚𝐫𝐲 𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐞𝐫</b>

 • <code>{0}bin &lt;angka></code> - Decimal ke Binary
 • <code>{0}debin &lt;binary></code> - Binary ke Decimal</blockquote>
"""

@PY.UBOT("bin")
@PY.TOP_CMD
async def decimal_to_binary(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .bin <angka>")
    try:
        angka = int(args[1])
        binary = bin(angka)[2:]
        await message.reply(f"🔢 {angka} = {binary} (binary)")
    except:
        await message.reply("❌ Masukkan angka valid")

@PY.UBOT("debin")
@PY.TOP_CMD
async def binary_to_decimal(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .debin <binary>")
    try:
        decimal = int(args[1], 2)
        await message.reply(f"🔢 {args[1]} = {decimal} (decimal)")
    except:
        await message.reply("❌ Masukkan binary valid")
