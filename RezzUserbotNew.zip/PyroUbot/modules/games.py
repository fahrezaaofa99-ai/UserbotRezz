# Nama file: /root/RezzUserbot/PyroUbot/modules/games.py
# Fitur: ALL GAMES COMPLETE - Tebak, Suit, Dadu, Slot, Blackjack, Roulette

from PyroUbot import *
import random
import asyncio
from datetime import datetime, timedelta

__MODULE__ = "ɢᴀᴍᴇs"
__HELP__ = """
<blockquote><b>🎮 GAMES COLLECTION</b>

<b>💰 SALDO & STATS</b>
 • <code>{0}saldo</code> - Cek saldo game kamu
 • <code>{0}topup</code> [jumlah] - Top up saldo (fake)
 • <code>{0}leaderboard</code> - Papan peringkat

<b>🎯 GAME TEBAK ANGKA</b>
 • <code>{0}tebak</code> - Main tebak angka (1-100)
   Hadiah: 150 | Biaya: 50

<b>✊ GAME SUIT</b>
 • <code>{0}suit</code> [batu/gunting/kertas] - Main suit sama bot
   Hadiah: 60 | Biaya: 30

<b>🎲 GAME DADU</b>
 • <code>{0}dadu</code> - Lempar dadu vs bot
   Hadiah: 100 | Biaya: 0 (gratis)

<b>🎰 GAME SLOT</b>
 • <code>{0}slot</code> [taruhan] - Main slot machine
   Minimal taruhan: 10

<b>♠️ GAME BLACKJACK</b>
 • <code>{0}bj</code> [taruhan] - Main blackjack vs dealer
   Minimal taruhan: 50

<b>🎡 GAME ROULETTE</b>
 • <code>{0}roulette</code> [warna/angka] [taruhan] - Main roulette
   Contoh: <code>{0}roulette merah 100</code>
   Pilihan: merah, hitam, hijau, atau angka 0-36

<b>📊 PAYTABLE SLOT:</b>
 • 7️⃣7️⃣7️⃣ = JACKPOT! (x10)
 • 💎💎💎 = x5
 • 🍒🍒🍒 = x3
 • 🍋🍋🍋 = x2
 • 🍊🍊🍊 = x1.5
 • 2 match = x0.5
 • No match = kalah</blockquote>
"""

# Database
player_balances = {}
player_stats = {}
game_sessions = {}
blackjack_games = {}
roulette_bets = {}

def get_balance(user_id):
    return player_balances.get(str(user_id), 1000)

def update_balance(user_id, amount):
    player_balances[str(user_id)] = amount

def get_stats(user_id):
    if str(user_id) not in player_stats:
        player_stats[str(user_id)] = {'win': 0, 'lose': 0, 'jackpot': 0, 'bj_win': 0, 'bj_lose': 0}
    return player_stats[str(user_id)]

# ==================== CEK SALDO ====================

@PY.UBOT("saldo")
@PY.TOP_CMD
async def cek_saldo(client, message):
    user_id = str(message.from_user.id)
    saldo = get_balance(user_id)
    stats = get_stats(user_id)
    
    await message.reply(
        f"<b>💰 SALDO GAME</b>\n\n"
        f"💳 Saldo: <b>{saldo}</b>\n\n"
        f"<b>📊 STATISTIK:</b>\n"
        f"   ✅ Menang: {stats['win']}\n"
        f"   ❌ Kalah: {stats['lose']}\n"
        f"   🎰 Jackpot: {stats['jackpot']}\n"
        f"   ♠️ Blackjack Menang: {stats['bj_win']}\n"
        f"   ♠️ Blackjack Kalah: {stats['bj_lose']}\n\n"
        f"<i>Saldo awal: 1000</i>"
    )

@PY.UBOT("topup")
@PY.TOP_CMD
async def topup_saldo(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>topup [jumlah]</code>")
    
    try:
        jumlah = int(message.command[1])
        if jumlah < 1:
            return await message.reply("Jumlah minimal 1!")
        if jumlah > 100000:
            return await message.reply("Maksimal topup 100000 (demo)")
    except ValueError:
        return await message.reply("Jumlah harus angka!")
    
    user_id = str(message.from_user.id)
    saldo = get_balance(user_id)
    saldo_baru = saldo + jumlah
    update_balance(user_id, saldo_baru)
    
    await message.reply(
        f"<b>✅ TOPUP BERHASIL</b>\n\n"
        f"💰 Jumlah: +{jumlah}\n"
        f"💳 Saldo lama: {saldo}\n"
        f"💳 Saldo baru: {saldo_baru}\n\n"
        f"<i>⚠️ Ini cuma demo ya bang!</i>"
    )

@PY.UBOT("leaderboard")
@PY.TOP_CMD
async def game_leaderboard(client, message):
    # Sort player by balance
    sorted_players = sorted(player_balances.items(), key=lambda x: x[1], reverse=True)[:10]
    
    text = "<b>🏆 GAME LEADERBOARD</b>\n\n"
    
    if not sorted_players:
        text += "Belum ada pemain"
    else:
        for i, (user_id, balance) in enumerate(sorted_players, 1):
            try:
                user = await client.get_users(int(user_id))
                name = user.first_name or "Unknown"
            except:
                name = f"User{user_id[:5]}"
            
            stats = get_stats(user_id)
            text += f"{i}. {name} - 💰{balance} (W:{stats['win']} L:{stats['lose']})\n"
    
    await message.reply(text)

# ==================== TEBAK ANGKA ====================

@PY.UBOT("tebak")
@PY.TOP_CMD
async def tebak_angka(client, message):
    user_id = str(message.from_user.id)
    
    if f"tebak_{user_id}" in game_sessions:
        return await message.reply("❌ Kamu masih punya game tebak angka yang belum selesai!")
    
    saldo = get_balance(user_id)
    
    if saldo < 50:
        return await message.reply("💰 Saldo kamu kurang! Minimal 50 buat main.")
    
    saldo -= 50
    update_balance(user_id, saldo)
    
    angka_rahasia = random.randint(1, 100)
    
    game_sessions[f"tebak_{user_id}"] = {
        'angka': angka_rahasia,
        'chance': 3,
        'chat_id': message.chat.id,
        'user_id': message.from_user.id
    }
    
    await message.reply(
        f"<b>🎯 TEBAK ANGKA</b>\n\n"
        f"💰 Hadiah: 150\n"
        f"💸 Biaya main: 50\n"
        f"💳 Sisa saldo: {saldo}\n\n"
        f"Kamu punya 3 kali kesempatan!\n"
        f"Ketik <b>jawab [angka]</b> untuk menjawab\n"
        f"Contoh: <code>jawab 50</code>"
    )

# ==================== SUIT ====================

@PY.UBOT("suit")
@PY.TOP_CMD
async def suit_game(client, message):
    if len(message.command) < 2:
        return await message.reply("Pilih: <code>batu</code>/<code>gunting</code>/<code>kertas</code>")
    
    user_id = str(message.from_user.id)
    saldo = get_balance(user_id)
    
    if saldo < 30:
        return await message.reply("💰 Saldo kurang! Minimal 30 buat main suit.")
    
    user_choice = message.command[1].lower()
    if user_choice not in ['batu', 'gunting', 'kertas']:
        return await message.reply("Pilihan harus: batu/gunting/kertas")
    
    # Potong biaya main
    saldo -= 30
    update_balance(user_id, saldo)
    
    bot_choice = random.choice(['batu', 'gunting', 'kertas'])
    emoji = {'batu': '🗻', 'gunting': '✂️', 'kertas': '📄'}
    
    # Rules
    if user_choice == bot_choice:
        hasil = "🤝 SERI"
        menang = 30  # Balik modal
        stats_update = 'draw'
    elif (user_choice == 'batu' and bot_choice == 'gunting') or \
         (user_choice == 'gunting' and bot_choice == 'kertas') or \
         (user_choice == 'kertas' and bot_choice == 'batu'):
        hasil = "✅ MENANG"
        menang = 60
        stats = get_stats(user_id)
        stats['win'] += 1
    else:
        hasil = "❌ KALAH"
        menang = 0
        stats = get_stats(user_id)
        stats['lose'] += 1
    
    saldo_baru = saldo + menang
    update_balance(user_id, saldo_baru)
    
    await message.reply(
        f"<b>✊✌️✋ SUIT</b>\n\n"
        f"{emoji[user_choice]} Kamu: <b>{user_choice.upper()}</b>\n"
        f"{emoji[bot_choice]} Bot: <b>{bot_choice.upper()}</b>\n"
        f"📊 Hasil: <b>{hasil}</b>\n\n"
        f"💰 Hadiah: +{menang}\n"
        f"💳 Saldo sekarang: {saldo_baru}"
    )

# ==================== DADU ====================

@PY.UBOT("dadu")
@PY.TOP_CMD
async def dadu_game(client, message):
    user_id = str(message.from_user.id)
    
    user_dadu = random.randint(1, 6)
    bot_dadu = random.randint(1, 6)
    
    emoji_dadu = {
        1: "⚀", 2: "⚁", 3: "⚂",
        4: "⚃", 5: "⚄", 6: "⚅"
    }
    
    if user_dadu > bot_dadu:
        hasil = "✅ MENANG"
        menang = 100
        stats = get_stats(user_id)
        stats['win'] += 1
    elif user_dadu < bot_dadu:
        hasil = "❌ KALAH"
        menang = 0
        stats = get_stats(user_id)
        stats['lose'] += 1
    else:
        hasil = "🤝 SERI"
        menang = 50  # Balik modal setengah
    
    saldo = get_balance(user_id)
    saldo_baru = saldo + menang
    update_balance(user_id, saldo_baru)
    
    await message.reply(
        f"<b>🎲 DADU</b>\n\n"
        f"Kamu: {emoji_dadu[user_dadu]} {user_dadu}\n"
        f"Bot: {emoji_dadu[bot_dadu]} {bot_dadu}\n"
        f"Hasil: <b>{hasil}</b>\n\n"
        f"💰 Hadiah: +{menng}\n"
        f"💳 Saldo sekarang: {saldo_baru}"
    )

# ==================== SLOT MACHINE ====================

@PY.UBOT("slot")
@PY.TOP_CMD
async def slot_machine(client, message):
    if len(message.command) < 2:
        return await message.reply(
            "<b>🎰 SLOT MACHINE</b>\n\n"
            "Format: <code>slot [taruhan]</code>\n"
            "Contoh: <code>slot 100</code>\n\n"
            "<b>💎 PAYTABLE:</b>\n"
            "7️⃣7️⃣7️⃣ = JACKPOT! (x10)\n"
            "💎💎💎 = x5\n"
            "🍒🍒🍒 = x3\n"
            "🍋🍋🍋 = x2\n"
            "🍊🍊🍊 = x1.5\n"
            "2 match = x0.5\n"
            "No match = kalah"
        )
    
    user_id = str(message.from_user.id)
    saldo = get_balance(user_id)
    
    try:
        taruhan = int(message.command[1])
        if taruhan < 10:
            return await message.reply("Minimal taruhan 10!")
        if taruhan > saldo:
            return await message.reply(f"Saldo kamu cuma {saldo}, kurang!")
    except ValueError:
        return await message.reply("Taruhan harus angka!")
    
    # Kurangi saldo
    saldo -= taruhan
    update_balance(user_id, saldo)
    
    # Slot symbols
    symbols = ['7️⃣', '💎', '🍒', '🍋', '🍊']
    weights = [5, 10, 25, 30, 30]
    
    result = random.choices(symbols, weights=weights, k=3)
    
    # Hitung multiplier
    if result[0] == result[1] == result[2]:
        if result[0] == '7️⃣':
            multiplier = 10
            stats = get_stats(user_id)
            stats['jackpot'] += 1
            stats['win'] += 1
            status = "🎉 JACKPOT! 🎉"
        elif result[0] == '💎':
            multiplier = 5
            stats = get_stats(user_id)
            stats['win'] += 1
            status = "✅ MENANG"
        elif result[0] == '🍒':
            multiplier = 3
            stats = get_stats(user_id)
            stats['win'] += 1
            status = "✅ MENANG"
        elif result[0] == '🍋':
            multiplier = 2
            stats = get_stats(user_id)
            stats['win'] += 1
            status = "✅ MENANG"
        else:
            multiplier = 1.5
            stats = get_stats(user_id)
            stats['win'] += 1
            status = "✅ MENANG"
    elif result[0] == result[1] or result[1] == result[2] or result[0] == result[2]:
        multiplier = 0.5
        stats = get_stats(user_id)
        stats['win'] += 1
        status = "⚠️ HAMPIR"
    else:
        multiplier = 0
        stats = get_stats(user_id)
        stats['lose'] += 1
        status = "❌ KALAH"
    
    hadiah = int(taruhan * multiplier)
    saldo_baru = saldo + hadiah
    update_balance(user_id, saldo_baru)
    
    slot_display = f"""
╔══════════╗
║  🎰 SLOT  ║
╠══════════╣
║  ┏━━━┓   ║
║  ┃{result[0]}┃   ║
║  ┗━━━┛   ║
║  ┏━━━┓   ║
║  ┃{result[1]}┃   ║
║  ┗━━━┛   ║
║  ┏━━━┓   ║
║  ┃{result[2]}┃   ║
║  ┗━━━┛   ║
╚══════════╝
"""
    
    await message.reply(
        f"<b>{slot_display}</b>\n\n"
        f"📊 <b>Status:</b> {status}\n"
        f"💰 <b>Taruhan:</b> {taruhan}\n"
        f"💎 <b>Multiplier:</b> {multiplier}x\n"
        f"🎁 <b>Hadiah:</b> +{hadiah}\n"
        f"💳 <b>Saldo akhir:</b> {saldo_baru}"
    )

# ==================== BLACKJACK ====================

def create_deck():
    suits = ['♠️', '♥️', '♣️', '♦️']
    cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
    deck = [f"{suit}{card}" for suit in suits for card in cards]
    random.shuffle(deck)
    return deck

def card_value(card):
    value = card[2:] if card[1] in ['0', 'J', 'Q', 'K'] else card[2]
    if value in ['J', 'Q', 'K']:
        return 10
    elif value == 'A':
        return 11
    else:
        return int(value)

def calculate_hand(hand):
    total = sum(card_value(card) for card in hand)
    aces = sum(1 for card in hand if card[2:] == 'A')
    
    while total > 21 and aces:
        total -= 10
        aces -= 1
    
    return total

def hand_display(hand):
    return ' '.join(hand)

@PY.UBOT("bj")
@PY.TOP_CMD
async def blackjack(client, message):
    if len(message.command) < 2:
        return await message.reply(
            "<b>♠️ BLACKJACK</b>\n\n"
            "Format: <code>bj [taruhan]</code>\n"
            "Contoh: <code>bj 100</code>\n\n"
            "Perintah saat main:\n"
            "<code>hit</code> - Ambil kartu\n"
            "<code>stand</code> - Berhenti\n"
            "<code>double</code> - Gandakan taruhan"
        )
    
    user_id = str(message.from_user.id)
    
    if user_id in blackjack_games:
        return await message.reply("❌ Kamu masih punya game blackjack yang belum selesai!")
    
    saldo = get_balance(user_id)
    
    try:
        taruhan = int(message.command[1])
        if taruhan < 50:
            return await message.reply("Minimal taruhan 50!")
        if taruhan > saldo:
            return await message.reply(f"Saldo kamu cuma {saldo}, kurang!")
    except ValueError:
        return await message.reply("Taruhan harus angka!")
    
    # Kurangi saldo
    saldo -= taruhan
    update_balance(user_id, saldo)
    
    # Setup game
    deck = create_deck()
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]
    
    blackjack_games[user_id] = {
        'deck': deck,
        'player': player_hand,
        'dealer': dealer_hand,
        'bet': taruhan,
        'doubled': False,
        'chat_id': message.chat.id
    }
    
    player_total = calculate_hand(player_hand)
    dealer_total = calculate_hand([dealer_hand[0]])
    
    # Cek blackjack
    if player_total == 21:
        return await blackjack_selesai(client, message, user_id, 'blackjack')
    
    await message.reply(
        f"<b>♠️ BLACKJACK</b>\n\n"
        f"💰 Taruhan: {taruhan}\n"
        f"💳 Sisa saldo: {saldo}\n\n"
        f"<b>Kartu kamu:</b> {hand_display(player_hand)} (Total: {player_total})\n"
        f"<b>Kartu dealer:</b> {hand_display([dealer_hand[0]])} 🂠\n\n"
        f"<b>Perintah:</b> <code>hit</code>, <code>stand</code>, <code>double</code>"
    )

@PY.UBOT("hit")
async def blackjack_hit(client, message):
    user_id = str(message.from_user.id)
    
    if user_id not in blackjack_games:
        return
    
    game = blackjack_games[user_id]
    
    if message.chat.id != game['chat_id']:
        return
    
    deck = game['deck']
    player_hand = game['player']
    
    player_hand.append(deck.pop())
    player_total = calculate_hand(player_hand)
    
    if player_total > 21:
        await blackjack_selesai(client, message, user_id, 'bust')
        return
    
    game['player'] = player_hand
    
    await message.reply(
        f"<b>♠️ HIT</b>\n\n"
        f"Kartu kamu sekarang: {hand_display(player_hand)} (Total: {player_total})\n\n"
        f"<b>Perintah:</b> <code>hit</code>, <code>stand</code>"
    )

@PY.UBOT("stand")
async def blackjack_stand(client, message):
    user_id = str(message.from_user.id)
    
    if user_id not in blackjack_games:
        return
    
    game = blackjack_games[user_id]
    
    if message.chat.id != game['chat_id']:
        return
    
    await blackjack_selesai(client, message, user_id, 'stand')

@PY.UBOT("double")
async def blackjack_double(client, message):
    user_id = str(message.from_user.id)
    
    if user_id not in blackjack_games:
        return
    
    game = blackjack_games[user_id]
    
    if message.chat.id != game['chat_id']:
        return
    
    if game['doubled']:
        return await message.reply("Kamu sudah double sebelumnya!")
    
    saldo = get_balance(user_id)
    if saldo < game['bet']:
        return await message.reply("Saldo tidak cukup untuk double!")
    
    # Double taruhan
    saldo -= game['bet']
    game['bet'] *= 2
    game['doubled'] = True
    update_balance(user_id, saldo)
    
    # Hit satu kartu
    deck = game['deck']
    player_hand = game['player']
    player_hand.append(deck.pp())
    player_total = calculate_hand(player_hand)
    
    if player_total > 21:
        await blackjack_selesai(client, message, user_id, 'bust')
    else:
        await blackjack_selesai(client, message, user_id, 'stand')

async def blackjack_selesai(client, message, user_id, result):
    game = blackjack_games[user_id]
    player_hand = game['player']
    dealer_hand = game['dealer']
    bet = game['bet']
    
    player_total = calculate_hand(player_hand)
    
    # Dealer main
    dealer_total = calculate_hand(dealer_hand)
    deck = game['deck']
    
    while dealer_total < 17:
        dealer_hand.append(deck.pop())
        dealer_total = calculate_hand(dealer_hand)
    
    # Tentukan hasil
    if result == 'blackjack':
        hasil = "♠️ BLACKJACK! 🎉"
        multiplier = 2.5
        stats = get_stats(user_id)
        stats['bj_win'] += 1
        stats['win'] += 1
    elif result == 'bust':
        hasil = "❌ BUST! KALAH"
        multiplier = 0
        stats = get_stats(user_id)
        stats['bj_lose'] += 1
        stats['lose'] += 1
    elif player_total > 21:
        hasil = "❌ BUST! KALAH"
        multiplier = 0
        stats = get_stats(user_id)
        stats['bj_lose'] += 1
        stats['lose'] += 1
    elif dealer_total > 21:
        hasil = "✅ DEALER BUST! MENANG"
        multiplier = 2
        stats = get_stats(user_id)
        stats['bj_win'] += 1
        stats['win'] += 1
    elif player_total > dealer_total:
        hasil = "✅ MENANG"
        multiplier = 2
        stats = get_stats(user_id)
        stats['bj_win'] += 1
        stats['win'] += 1
    elif player_total < dealer_total:
        hasil = "❌ KALAH"
        multiplier = 0
        stats = get_stats(user_id)
        stats['bj_lose'] += 1
        stats['lose'] += 1
    else:
        hasil = "🤝 SERI (Push)"
        multiplier = 1
        stats = get_stats(user_id)
    
    hadiah = int(bet * multiplier)
    saldo = get_balance(user_id)
    saldo_baru = saldo + hadiah
    update_balance(user_id, saldo_baru)
    
    await message.reply(
        f"<b>♠️ BLACKJACK - {hasil}</b>\n\n"
        f"<b>Kartu kamu:</b> {hand_display(player_hand)} (Total: {player_total})\n"
        f"<b>Kartu dealer:</b> {hand_display(dealer_hand)} (Total: {dealer_total})\n\n"
        f"💰 Taruhan: {bet}\n"
        f"🎁 Hadiah: +{hadiah}\n"
        f"💳 Saldo akhir: {saldo_baru}"
    )
    
    del blackjack_games[user_id]

# ==================== ROULETTE ====================

@PY.UBOT("roulette")
@PY.TOP_CMD
async def roulette_game(client, message):
    if len(message.command) < 3:
        return await message.reply(
            "<b>🎡 ROULETTE</b>\n\n"
            "Format: <code>roulette [pilihan] [taruhan]</code>\n"
            "Contoh: <code>roulette merah 100</code>\n\n"
            "<b>Pilihan:</b>\n"
            "• warna: merah, hitam, hijau (0)\n"
            "• angka: 0-36\n\n"
            "<b>Pembayaran:</b>\n"
            "• Warna: x2 (kecuali hijau x36)\n"
            "• Angka: x36"
        )
    
    user_id = str(message.from_user.id)
    saldo = get_balance(user_id)
    
    pilihan = message.command[1].lower()
    
    try:
        taruhan = int(message.command[2])
        if taruhan < 10:
            return await message.reply("Minimal taruhan 10!")
        if taruhan > saldo:
            return await message.reply(f"Saldo kamu cuma {saldo}, kurang!")
    except ValueError:
        return await message.reply("Taruhan harus angka!")
    
    # Validasi pilihan
    angka_merah = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]
    angka_hitam = [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35]
    
    if pilihan == 'merah':
        valid = True
        bet_type = 'warna'
    elif pilihan == 'hitam':
        valid = True
        bet_type = 'warna'
    elif pilihan == 'hijau' or pilihan == '0':
        pilihan = '0'
        valid = True
        bet_type = 'angka'
    else:
        try:
            angka = int(pilihan)
            if 0 <= angka <= 36:
                valid = True
                bet_type = 'angka'
                if angka == 0:
                    pilihan = '0'
            else:
                valid = False
        except:
            valid = False
    
    if not valid:
        return await message.reply("Pilihan tidak valid! Pilih: merah/hitam/hijau atau angka 0-36")
    
    # Kurangi saldo
    saldo -= taruhan
    update_balance(user_id, saldo)
    
    # Putar roulette
    result_number = random.randint(0, 36)
    
    if result_number == 0:
        result_color = 'hijau'
    elif result_number in angka_merah:
        result_color = 'merah'
    else:
        result_color = 'hitam'
    
    # Hitung hadiah
    if bet_type == 'warna':
        if pilihan == result_color:
            if pilihan == 'hijau':
                multiplier = 36
            else:
                multiplier = 2
            hasil = "✅ MENANG"
            stats = get_stats(user_id)
            stats['win'] += 1
        else:
            multiplier = 0
            hasil = "❌ KALAH"
            stats = get_stats(user_id)
            stats['lose'] += 1
    else:  # bet_type == 'angka'
        if int(pilihan) == result_number:
            multiplier = 36
            hasil = "🎉 JACKPOT! 🎉"
            stats = get_stats(user_id)
            stats['win'] += 1
        else:
            multiplier = 0
            hasil = "❌ KALAH"
            stats = get_stats(user_id)
            stats['lose'] += 1
    
    hadiah = int(taruhan * multiplier)
    saldo_baru = saldo + hadiah
    update_balance(user_id, saldo_baru)
    
    # Emoji untuk hasil
    if result_color == 'merah':
        warna_emoji = '🔴'
    elif result_color == 'hitam':
        warna_emoji = '⚫'
    else:
        warna_emoji = '💚'
    
    await message.reply(
        f"<b>🎡 ROULETTE</b>\n\n"
        f"🎯 Hasil: {warna_emoji} {result_number} ({result_color})\n"
        f"📊 Pilihanmu: {pilihan.upper()}\n"
        f"📈 Hasil: <b>{hasil}</b>\n\n"
        f"💰 Taruhan: {taruhan}\n"
        f"💎 Multiplier: {multiplier}x\n"
        f"🎁 Hadiah: +{hadiah}\n"
        f"💳 Saldo akhir: {saldo_baru}"
    )

# ==================== HANDLER JAWAB TEBAK ====================

@PY.UBOT("jawab")
async def jawab_tebak(client, message):
    if len(message.command) < 2:
        return
    
    user_id = str(message.from_user.id)
    
    if f"tebak_{user_id}" not in game_sessions:
        return
    
    game = game_sessions[f"tebak_{user_id}"]
    
    if message.chat.id != game['chat_id']:
        return
    
    try:
        tebakan = int(message.command[1])
    except ValueError:
        await message.reply("❌ Ketik ANGKA yang bener!")
        return
    
    if tebakan < 1 or tebakan > 100:
        await message.reply("❌ Angka harus antara 1-100!")
        return
    
    game['chance'] -= 1
    
    if tebakan == game['angka']:
        menang = 150
        saldo_baru = get_balance(user_id) + menang
        update_balance(user_id, saldo_baru)
        
        stats = get_stats(user_id)
        stats['win'] += 1
        
        await message.reply(
            f"<b>🎉 SELAMAT! KAMU MENANG!</b>\n\n"
            f"🔢 Angka: {game['angka']}\n"
            f"💰 Hadiah: +{menang}\n"
            f"💳 Saldo sekarang: {saldo_baru}"
        )
        
        del game_sessions[f"tebak_{user_id}"]
        
    elif game['chance'] == 0:
        stats = get_stats(user_id)
        stats['lose'] += 1
        
        await message.reply(
            f"<b>🏁 GAME OVER</b>\n\n"
            f"Angka yang benar: {game['angka']}\n"
            f"💸 Saldo terpotong 50\n"
            f"💳 Sisa saldo: {get_balance(user_id)}"
        )
        
        del game_sessions[f"tebak_{user_id}"]
        
    elif tebakan < game['angka']:
        await message.reply(f"⬆️ Lebih gede! Kesempatan: {game['chance']}x")
    else:
        await message.reply(f"⬇️ Lebih kecil! Kesempatan: {game['chance']}x")
