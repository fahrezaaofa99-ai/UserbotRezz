from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐒𝐒"
__HELP__ = """
<blockquote><b>🛰️ 𝐈𝐒𝐒 𝐋𝐨𝐜𝐚𝐭𝐢𝐨𝐧</b>

 • <code>{0}iss</code> - Lokasi ISS saat ini</blockquote>
"""

@PY.UBOT("iss")
@PY.TOP_CMD
async def iss_location(client, message):
    msg = await message.reply("🛰️ Mengambil lokasi ISS...")
    try:
        r = requests.get("http://api.open-notify.org/iss-now.json")
        if r.status_code == 200:
            data = r.json()
            lat = data['iss_position']['latitude']
            lon = data['iss_position']['longitude']
            await msg.edit(f"🛰️ **ISS Location**\n\n📍 Latitude: {lat}\n📍 Longitude: {lon}\n🌍 https://maps.google.com/?q={lat},{lon}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
