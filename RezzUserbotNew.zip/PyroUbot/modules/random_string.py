from PyroUbot import *
import random
import string

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐒𝐭𝐫𝐢𝐧𝐠"
__HELP__ = """
<blockquote><b>🔤 𝐑𝐚𝐧𝐝𝐨𝐦 𝐒𝐭𝐫𝐢𝐧𝐠</b>

 • <code>{0}randstr &lt;panjang></code> - Generate string random</blockquote>
"""

@PY.UBOT("randstr")
@PY.TOP_CMD
async def random_string(client, message):
    args = message.text.split()
    length = int(args[1]) if len(args) > 1 else 10
    chars = string.ascii_letters + string.digits
    result = ''.join(random.choice(chars) for _ in range(length))
    await message.reply(f"🔤 **Random String:** `{result}`")
