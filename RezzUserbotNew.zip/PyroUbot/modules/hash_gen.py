from PyroUbot import *
import hashlib

__MODULE__ = "𝐇𝐚𝐬𝐡𝐆𝐞𝐧"
__HELP__ = """
<blockquote><b>🔐 𝐇𝐚𝐬𝐡 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

 • <code>{0}md5 &lt;teks></code> - Hash MD5
 • <code>{0}sha1 &lt;teks></code> - Hash SHA1
 • <code>{0}sha256 &lt;teks></code> - Hash SHA256</blockquote>
"""

@PY.UBOT("md5")
@PY.TOP_CMD
async def md5_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .md5 <teks>")
    hasil = hashlib.md5(args[1].encode()).hexdigest()
    await message.reply(f"🔐 **MD5:** `{hasil}`")

@PY.UBOT("sha1")
@PY.TOP_CMD
async def sha1_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .sha1 <teks>")
    hasil = hashlib.sha1(args[1].encode()).hexdigest()
    await message.reply(f"🔐 **SHA1:** `{hasil}`")

@PY.UBOT("sha256")
@PY.TOP_CMD
async def sha256_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .sha256 <teks>")
    hasil = hashlib.sha256(args[1].encode()).hexdigest()
    await message.reply(f"🔐 **SHA256:** `{hasil}`")
