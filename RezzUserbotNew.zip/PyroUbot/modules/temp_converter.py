from PyroUbot import *

__MODULE__ = "𝐓𝐞𝐦𝐩𝐂𝐨𝐧𝐯"
__HELP__ = """
<blockquote><b>🌡️ 𝐓𝐞𝐦𝐩𝐞𝐫𝐚𝐭𝐮𝐫𝐞</b>

 • <code>{0}c_f &lt;c></code> - Celcius ke Fahrenheit
 • <code>{0}f_c &lt;f></code> - Fahrenheit ke Celcius
 • <code>{0}c_k &lt;c></code> - Celcius ke Kelvin</blockquote>
"""

@PY.UBOT("c_f")
@PY.TOP_CMD
async def c_to_f(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .c_f <celcius>")
    c = float(args[1])
    f = (c * 9/5) + 32
    await message.reply(f"🌡️ {c}°C = {f}°F")

@PY.UBOT("f_c")
@PY.TOP_CMD
async def f_to_c(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .f_c <fahrenheit>")
    f = float(args[1])
    c = (f - 32) * 5/9
    await message.reply(f"🌡️ {f}°F = {c:.1f}°C")

@PY.UBOT("c_k")
@PY.TOP_CMD
async def c_to_k(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .c_k <celcius>")
    c = float(args[1])
    k = c + 273.15
    await message.reply(f"🌡️ {c}°C = {k:.1f}K")
