from PyroUbot import *

__MODULE__ = "𝐂𝐚𝐥𝐜𝐒𝐢𝐦𝐩𝐥𝐞"
__HELP__ = """
<blockquote><b>🧮 𝐂𝐚𝐥𝐜𝐮𝐥𝐚𝐭𝐨𝐫</b>

 • <code>{0}calc &lt;a> &lt;+-> &lt;b></code> - Hitung</blockquote>
"""

@PY.UBOT("calc")
@PY.TOP_CMD
async def calculate(client, message):
    args = message.text.split()
    if len(args) < 4:
        return await message.reply("❌ .calc 10 + 5")
    try:
        a = float(args[1])
        op = args[2]
        b = float(args[3])
        if op == '+': hasil = a + b
        elif op == '-': hasil = a - b
        elif op == '*': hasil = a * b
        elif op == '/': hasil = a / b
        elif op == '^': hasil = a ** b
        else: return await message.reply("❌ Operator salah")
        await message.reply(f"📝 {a} {op} {b} = {hasil}")
    except:
        await message.reply("❌ Error")
