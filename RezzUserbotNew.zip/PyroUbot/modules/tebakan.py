from PyroUbot import *
import random

__MODULE__ = "𝐓𝐞𝐛𝐚𝐤𝐚𝐧"
__HELP__ = """
<blockquote><b>🤔 𝐓𝐞𝐛𝐚𝐤-𝐓𝐞𝐛𝐚𝐤𝐚𝐧</b>

 • <code>{0}tebak</code> - Tebak-tebakan random</blockquote>
"""

tebakan_list = [
    ("Apa yang bisa naik tapi tidak bisa turun?", "Umur"),
    ("Apa yang semakin diisi semakin ringan?", "Balon"),
    ("Apa yang punya banyak kunci tapi tidak bisa buka pintu?", "Piano"),
    ("Apa yang selalu di depanmu tapi tak pernah kau lihat?", "Masa depan"),
]

@PY.UBOT("tebak")
@PY.TOP_CMD
async def tebak_tebakan(client, message):
    soal, jawab = random.choice(tebakan_list)
    await message.reply(f"🤔 **Tebakan:**\n\n{soal}\n\nReply pesan ini untuk jawab!")
    
    def check(m):
        return m.from_user.id == message.from_user.id
    
    try:
        reply = await client.wait_for_message(check, timeout=30)
        if reply.text.lower() == jawab.lower():
            await message.reply(f"✅ **BENAR!** Jawabannya: {jawab}")
        else:
            await message.reply(f"❌ **SALAH!** Jawabannya: {jawab}")
    except:
        await message.reply(f"⏰ Waktu habis! Jawaban: {jawab}")
