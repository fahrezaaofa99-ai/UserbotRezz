from PyroUbot import *
import re

__MODULE__ = "𝐄𝐦𝐚𝐢𝐥𝐕𝐚𝐥"
__HELP__ = """
<blockquote><b>📧 𝐄𝐦𝐚𝐢𝐥 𝐕𝐚𝐥𝐢𝐝𝐚𝐭𝐨𝐫</b>

 • <code>{0}email &lt;email></code> - Validasi email</blockquote>
"""

@PY.UBOT("email")
@PY.TOP_CMD
async def email_validator(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .email <email>")
    regex = r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
    if re.match(regex, args[1]):
        await message.reply(f"✅ **{args[1]}** adalah email valid!")
    else:
        await message.reply(f"❌ **{args[1]}** email tidak valid!")
