from PyroUbot import *
import random

__MODULE__ = "𝐔𝐀𝐆𝐞𝐧"
__HELP__ = """
<blockquote><b>📱 𝐔𝐬𝐞𝐫 𝐀𝐠𝐞𝐧𝐭</b>

 • <code>{0}ua</code> - Random User Agent</blockquote>
"""

agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
]

@PY.UBOT("ua")
@PY.TOP_CMD
async def useragent_gen(client, message):
    ua = random.choice(agents)
    await message.reply(f"📱 **User Agent:**\n`{ua}`")
