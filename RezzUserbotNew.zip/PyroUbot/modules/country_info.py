from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐨𝐮𝐧𝐭𝐫𝐲"
__HELP__ = """
<blockquote><b>🌍 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 𝐈𝐧𝐟𝐨</b>

 • <code>{0}country &lt;nama></code> - Info negara</blockquote>
"""

@PY.UBOT("country")
@PY.TOP_CMD
async def country_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .country <nama negara>")
    msg = await message.reply("🌍 Mencari...")
    try:
        r = requests.get(f"https://restcountries.com/v3.1/name/{args[1]}")
        if r.status_code == 200:
            data = r.json()[0]
            text = f"""
╭──〔 🌍 INFO NEGARA 〕
│
│ 📌 {data.get('name', {}).get('common', 'N/A')}
│ 🏙️ Ibu Kota: {data.get('capital', ['N/A'])[0]}
│ 👥 Populasi: {data.get('population', 0):,}
│ 🌎 Benua: {data.get('continents', ['N/A'])[0]}
│ 🗣️ Bahasa: {', '.join(data.get('languages', {}).values())}
│ 💵 Mata Uang: {list(data.get('currencies', {}).keys())[0] if data.get('currencies') else 'N/A'}
│
╰── ✨ Country Info ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ Negara tidak ditemukan")
    except:
        await msg.edit("❌ Error")
