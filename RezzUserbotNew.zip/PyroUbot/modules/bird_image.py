from PyroUbot import *
import requests

__MODULE__ = "𝐁𝐢𝐫𝐝𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🐦 𝐁𝐢𝐫𝐝 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}bird</code> - Gambar burung random</blockquote>
"""

@PY.UBOT("bird")
@PY.TOP_CMD
async def bird_image(client, message):
    msg = await message.reply("🐦 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/bird")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
