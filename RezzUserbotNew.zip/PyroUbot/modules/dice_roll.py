from PyroUbot import *
import random

__MODULE__ = "𝐃𝐢𝐜𝐞"
__HELP__ = """
<blockquote><b>🎲 𝐃𝐢𝐜𝐞 𝐑𝐨𝐥𝐥</b>

 • <code>{0}dice</code> - Lempar dadu</blockquote>
"""

@PY.UBOT("dice")
@PY.TOP_CMD
async def dice_roll(client, message):
    hasil = random.randint(1, 6)
    dadu = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
    await message.reply(f"🎲 **Hasil dadu:** {hasil} {dadu[hasil-1]}")
