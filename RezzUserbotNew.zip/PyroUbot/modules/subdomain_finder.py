from PyroUbot import *
import requests

__MODULE__ = "𝐒𝐮𝐛𝐝𝐨𝐦𝐚𝐢𝐧"
__HELP__ = """
<blockquote><b>🔍 𝐒𝐮𝐛𝐝𝐨𝐦𝐚𝐢𝐧 𝐅𝐢𝐧𝐝𝐞𝐫</b>

 • <code>{0}subdomain &lt;domain></code> - Cari subdomain</blockquote>
"""

@PY.UBOT("subdomain")
@PY.TOP_CMD
async def subdomain_find(client, message):
    args = message.text.split(maxsplt=1)
    if len(args) < 2:
        return await message.reply("❌ .subdomain <domain>")
    msg = await message.reply("🔍 Mencari subdomain...")
    subdomains = ['www', 'mail', 'ftp', 'blog', 'webmail', 'smtp', 'pop', 'ns1', 'ns2', 'cpanel']
    found = []
    for sub in subdomains:
        try:
            r = requests.get(f"http://{sub}.{args[1]}", timeout=2)
            if r.status_code < 400:
                found.append(sub)
        except:
            pass
    if found:
        await msg.edit(f"🔍 **Subdomain ditemukan:**\n\n" + "\n".join(found))
    else:
        await msg.edit("❌ Tidak ada subdomain ditemukan")
