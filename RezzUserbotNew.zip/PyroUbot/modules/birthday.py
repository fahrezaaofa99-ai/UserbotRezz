from PyroUbot import *
from datetime import datetime

__MODULE__ = "𝐁𝐢𝐫𝐭𝐡𝐝𝐚𝐲"
__HELP__ = """
<blockquote><b>🎂 𝐁𝐢𝐫𝐭𝐡𝐝𝐚𝐲</b>

 • <code>{0}birthday &lt;DD-MM></code> - Cek hari ulang tahun</blockquote>
"""

@PY.UBOT("birthday")
@PY.TOP_CMD
async def birthday_check(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .birthday DD-MM")
    try:
        now = datetime.now()
        bday = datetime.strptime(f"{args[1]}-{now.year}", "%d-%m-%Y")
        if bday < now:
            bday = bday.replace(year=now.year + 1)
        selisih = (bday - now).days
        await message.reply(f"🎂 **Hari ulang tahun:** {selisih} hari lagi!")
    except:
        await message.reply("❌ Format salah! Contoh: .birthday 15-08")
