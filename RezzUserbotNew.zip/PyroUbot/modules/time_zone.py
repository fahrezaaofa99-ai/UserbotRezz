from PyroUbot import *
import requests
from datetime import datetime

__MODULE__ = "𝐓𝐢𝐦𝐞 𝐙𝐨𝐧𝐞"
__HELP__ = """
<blockquote><b>🕐 𝐓𝐢𝐦𝐞 𝐙𝐨𝐧𝐞</b>

 • <code>{0}time &lt;kota></code> - Waktu di kota
 • <code>{0}timezone</code> - Timezone populer</blockquote>
"""

@PY.UBOT("time")
@PY.TOP_CMD
async def time_city(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .time <kota>")
    msg = await message.reply("🕐 Mencari waktu...")
    try:
        r = requests.get(f"http://worldtimeapi.org/api/timezone/{args[1]}")
        if r.status_code == 200:
            data = r.json()
            dt = data['datetime'].split('T')
            waktu = dt[1].split('.')[0]
            await msg.edit(f"🕐 **Waktu di {args[1]}**\n\n📅 {dt[0]}\n⏰ {waktu}")
        else:
            await msg.edit("❌ Kota tidak ditemukan")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("timezone")
@PY.TOP_CMD
async def list_timezone(client, message):
    zones = [
        "Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura",
        "Asia/Tokyo", "Asia/Dubai", "Europe/London",
        "America/New_York", "America/Los_Angeles"
    ]
    text = "🕐 **TIMEZONE POPULER**\n\n" + "\n".join(zones)
    await message.reply(text)
