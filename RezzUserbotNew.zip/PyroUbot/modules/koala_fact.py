from PyroUbot import *
import requests

__MODULE__ = "𝐊𝐨𝐚𝐥𝐚 𝐅𝐚𝐜𝐭"
__HELP__ = """
<blockquote><b>🐨 𝐊𝐨𝐚𝐥𝐚 𝐅𝐚𝐜𝐭</b>

 • <code>{0}koalafact</code> - Fakta tentang koala
 • <code>{0}koalaimg</code> - Gambar koala random</blockquote>
"""

@PY.UBOT("koalafact")
@PY.TOP_CMD
async def koala_fact(client, message):
    try:
        r = requests.get("https://some-random-api.com/facts/koala")
        if r.status_code == 200:
            fact = r.json()['fact']
            await message.reply(f"🐨 **Koala Fact:**\n\n{fact}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("koalaimg")
@PY.TOP_CMD
async def koala_image(client, message):
    msg = await message.reply("🐨 Mencari gambar...")
    try:
        r = requests.get("https://some-random-api.com/img/koala")
        if r.status_code == 200:
            img_url = r.json()['link']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
