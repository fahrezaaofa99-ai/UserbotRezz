from PyroUbot import *

__MODULE__ = "𝐔𝐧𝐢𝐭𝐂𝐨𝐧𝐯"
__HELP__ = """
<blockquote><b>📏 𝐔𝐧𝐢𝐭 𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐞𝐫</b>

 • <code>{0}km_m &lt;km></code> - KM ke Meter
 • <code>{0}m_km &lt;m></code> - Meter ke KM
 • <code>{0}kg_g &lt;kg></code> - KG ke Gram
 • <code>{0}g_kg &lt;g></code> - Gram ke KG</blockquote>
"""

@PY.UBOT("km_m")
@PY.TOP_CMD
async def km_to_m(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .km_m <km>")
    km = float(args[1])
    m = km * 1000
    await message.reply(f"📏 {km} km = {m} meter")

@PY.UBOT("m_km")
@PY.TOP_CMD
async def m_to_km(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .m_km <meter>")
    m = float(args[1])
    km = m / 1000
    await message.reply(f"📏 {m} meter = {km} km")

@PY.UBOT("kg_g")
@PY.TOP_CMD
async def kg_to_g(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .kg_g <kg>")
    kg = float(args[1])
    g = kg * 1000
    await message.reply(f"⚖️ {kg} kg = {g} gram")

@PY.UBOT("g_kg")
@PY.TOP_CMD
async def g_to_kg(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .g_kg <gram>")
    g = float(args[1])
    kg = g / 1000
    await message.reply(f"⚖️ {g} gram = {kg} kg")
