from PyroUbot import *
import socket

__MODULE__ = "𝐏𝐨𝐫𝐭𝐒𝐜𝐚𝐧"
__HELP__ = """
<blockquote><b>🔍 𝐏𝐨𝐫𝐭 𝐒𝐜𝐚𝐧𝐧𝐞𝐫</b>

 • <code>{0}portscan &lt;ip> &lt;port></code> - Scan port</blockquote>
"""

@PY.UBOT("portscan")
@PY.TOP_CMD
async def port_scan(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .portscan <ip> <port>")
    msg = await message.reply(f"🔍 Scanning {args[1]}:{args[2]}...")
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex((args[1], int(args[2])))
        if result == 0:
            await msg.edit(f"✅ Port {args[2]} **TERBUKA**")
        else:
            await msg.edit(f"❌ Port {args[2]} **TERTUTUP**")
        sock.close()
    except:
        await msg.edit("❌ Error")
