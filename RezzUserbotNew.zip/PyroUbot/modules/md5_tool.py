from PyroUbot import *
import hashlib

__MODULE__ = "𝐌𝐃𝟓"
__HELP__ = """
<blockquote><b>🔐 𝐌𝐃𝟓</b>

 • <code>{0}md5 &lt;teks></code> - Hash MD5</blockquote>
"""

@PY.UBOT("md5")
@PY.TOP_CMD
async def md5_hash(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .md5 <teks>")
    hasil = hashlib.md5(args[1].encode()).hexdigest()
    await message.reply(f"🔐 **MD5:** `{hasil}`")
