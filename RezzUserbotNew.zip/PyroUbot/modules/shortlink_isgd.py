from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐬𝐆𝐃"
__HELP__ = """
<blockquote><b>🔗 𝐢𝐬.𝐠𝐝 𝐒𝐡𝐨𝐫𝐭𝐞𝐧𝐞𝐫</b>

 • <code>{0}isgd &lt;url></code> - Pendekin link dengan is.gd</blockquote>
"""

@PY.UBOT("isgd")
@PY.TOP_CMD
async def isgd_shortener(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .isgd <url>")
    msg = await message.reply("🔗 Memendekkan...")
    try:
        r = requests.get(f"https://is.gd/create.php?format=simple&url={args[1]}")
        if r.status_code == 200:
            await msg.edit(f"🔗 **Short URL:** {r.text}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
