from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐏 𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>🌐 𝐈𝐏 𝐈𝐧𝐟𝐨</b>

 • <code>{0}ip &lt;ip></code> - Cek info IP
 • <code>{0}myip</code> - IP sendiri</blockquote>
"""

@PY.UBOT("ip")
@PY.TOP_CMD
async def ip_info(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .ip <ip>")
    msg = await message.reply("🔍 Mencari info IP...")
    try:
        r = requests.get(f"http://ip-api.com/json/{args[1]}", timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data['status'] == 'success':
                text = f"""
╭──〔 🌐 INFO IP 〕
│
│ 📌 IP: {data['query']}
│ 🗺️ Negara: {data['country']}
│ 🏙️ Kota: {data['city']}
│ 📡 ISP: {data['isp']}
│
╰── ✨ IP Info ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ IP tidak valid")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("myip")
@PY.TOP_CMD
async def my_ip(client, message):
    msg = await message.reply("🔍 Mengambil IP...")
    try:
        r = requests.get("https://api.ipify.org?format=json", timeout=10)
        if r.status_code == 200:
            ip = r.json()['ip']
            await msg.edit(f"🌐 **IP Kamu:** `{ip}`")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
