from PyroUbot import *
import random

__MODULE__ = "𝐑𝐏𝐒"
__HELP__ = """
<blockquote><b>✊ 𝐑𝐨𝐜𝐤 𝐏𝐚𝐩𝐞𝐫 𝐒𝐜𝐢𝐬𝐬𝐨𝐫𝐬</b>

 • <code>{0}rps &lt;batu/kertas/gunting></code> - Main RPS</blockquote>
"""

@PY.UBOT("rps")
@PY.TOP_CMD
async def rps_game(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .rps <batu/kertas/gunting>")
    player = args[1].lower()
    if player not in ['batu', 'kertas', 'gunting']:
        return await message.reply("❌ Pilih: batu, kertas, gunting")
    bot = random.choice(['batu', 'kertas', 'gunting'])
    if player == bot:
        hasil = "DRAW 🤝"
    elif (player == 'batu' and bot == 'gunting') or (player == 'gunting' and bot == 'kertas') or (player == 'kertas' and bot == 'batu'):
        hasil = "KAMU MENANG! 🎉"
    else:
        hasil = "KAMU KALAH! 😢"
    await message.reply(f"✊ **RPS GAME**\n\nKamu: {player}\nBot: {bot}\n\n{hasil}")
