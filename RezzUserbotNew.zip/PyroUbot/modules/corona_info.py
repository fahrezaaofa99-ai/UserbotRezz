from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐨𝐫𝐨𝐧𝐚"
__HELP__ = """
<blockquote><b>🦠 𝐂𝐨𝐫𝐨𝐧𝐚 𝐈𝐧𝐟𝐨</b>

 • <code>{0}corona</code> - Data Corona Global
 • <code>{0}coronaid</code> - Data Corona Indonesia</blckquote>
"""

@PY.UBOT("corona")
@PY.TOP_CMD
async def corona_global(client, message):
    msg = await message.reply("🦠 Mengambil data global...")
    try:
        r = requests.get("https://disease.sh/v3/covid-19/all")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"🦠 **COVID-19 GLOBAL**\n\n🟢 Kasus: {data['cases']:,}\n🔴 Meninggal: {data['deaths']:,}\n✅ Sembuh: {data['recovered']:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("coronaid")
@PY.TOP_CMD
async def corona_indonesia(client, message):
    msg = await message.reply("🦠 Mengambil data Indonesia...")
    try:
        r = requests.get("https://disease.sh/v3/covid-19/countries/indonesia")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"🇮🇩 **COVID-19 INDONESIA**\n\n🟢 Kasus: {data['cases']:,}\n🔴 Meninggal: {data['deaths']:,}\n✅ Sembuh: {data['recovered']:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
