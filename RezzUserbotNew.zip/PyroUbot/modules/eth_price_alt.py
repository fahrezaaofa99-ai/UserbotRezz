from PyroUbot import *
import requests

__MODULE__ = "𝐄𝐓𝐇𝐏𝐫𝐢𝐜𝐞"
__HELP__ = """
<blockquote><b>💰 𝐄𝐭𝐡𝐞𝐫𝐞𝐮𝐦 𝐏𝐫𝐢𝐜𝐞</b>

 • <code>{0}eth</code> - Harga ETH terkini</blockquote>
"""

@PY.UBOT("eth")
@PY.TOP_CMD
async def eth_price_alt(client, message):
    msg = await message.reply("💰 Mengambil harga ETH...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd,idr")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"💰 **Ethereum (ETH)**\n\n💵 USD: ${data['ethereum']['usd']:,.0f}\n🇮🇩 IDR: Rp{data['ethereum']['idr']:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
