from PyroUbot import *
import time

__MODULE__ = "𝐏𝐢𝐧𝐠"
__HELP__ = """
<blockquote><b>🏓 𝐏𝐢𝐧𝐠</b>

 • <code>{0}ping</code> - Cek kecepatan bot</blockquote>
"""

@PY.UBOT("ping")
@PY.TOP_CMD
async def ping_bot(client, message):
    start = time.time()
    msg = await message.reply("🏓 Pong!")
    end = time.time()
    ping = (end - start) * 1000
    await msg.edit(f"🏓 **Pong!**\n📊 `{ping:.0f}ms`")
