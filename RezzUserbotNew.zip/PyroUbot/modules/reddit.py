from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐞𝐝𝐝𝐢𝐭"
__HELP__ = """
<blockquote><b>📱 𝐑𝐞𝐝𝐝𝐢𝐭</b>

 • <code>{0}subreddit &lt;nama></code> - Cari subreddit</blockquote>
"""

@PY.UBOT("subreddit")
@PY.TOP_CMD
async def subreddit_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .subreddit <nama>")
    msg = await message.reply("🔍 Mencari subreddit...")
    try:
        r = requests.get(f"https://www.reddit.com/r/{args[1]}/about.json", headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)
        if r.status_code == 200:
            data = r.json()
            sub = data['data']
            text = f"""
╭──〔 📱 SUBREDDIT 〕
│
│ 📌 r/{sub['display_name']}
│ 👥 Subscribers: {sub['subscribers']:,}
│ 📝 {sub['public_description'][:100]}
│
╰── ✨ Reddit ✨"""
            await msg.edit(text)
        else:
            await msg.edit("❌ Subreddit tidak ditemukan")
    except:
        await msg.edit("❌ Error")
