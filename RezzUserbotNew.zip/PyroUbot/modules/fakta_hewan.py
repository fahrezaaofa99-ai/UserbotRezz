from PyroUbot import *
import random

__MODULE__ = "𝐅𝐚𝐤𝐭𝐚𝐇𝐞𝐰𝐚𝐧"
__HELP__ = """
<blockquote><b>🐾 𝐅𝐚𝐤𝐭𝐚 𝐇𝐞𝐰𝐚𝐧</b>

 • <code>{0}faktahewan</code> - Fakta hewan random</blockquote>
"""

fakta_hewan_list = [
    "Lumba-lumba bisa tidur dengan satu mata terbuka",
    "Semut bisa mengangkat beban 50 kali berat badannya",
    "Siput bisa tidur selama 3 tahun",
    "Cumi-cumi punya 3 jantung"
]

@PY.UBOT("faktahewan")
@PY.TOP_CMD
async def fakta_hewan_func(client, message):
    await message.reply(f"🐾 **Fakta Hewan:**\n\n{random.choice(fakta_hewan_list)}")
