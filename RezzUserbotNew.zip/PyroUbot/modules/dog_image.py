from PyroUbot import *
import requests

__MODULE__ = "𝐃𝐨𝐠𝐈𝐦𝐚𝐠𝐞"
__HELP__ = """
<blockquote><b>🐕 𝐃𝐨𝐠 𝐈𝐦𝐚𝐠𝐞</b>

 • <code>{0}dog</code> - Gambar anjing random</blockquote>
"""

@PY.UBOT("dog")
@PY.TOP_CMD
async def dog_image(client, message):
    msg = await message.reply("🐕 Mencari gambar...")
    try:
        r = requests.get("https://dog.ceo/api/breeds/image/random")
        if r.status_code == 200:
            img_url = r.json()['message']
            await message.reply_photo(img_url)
            await msg.delete()
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
