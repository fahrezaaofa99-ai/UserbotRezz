from PyroUbot import *

__MODULE__ = "𝐊𝐢𝐜𝐤 𝐁𝐨𝐭"
__HELP__ = """
<blockquote><b>🤖 𝐊𝐢𝐜𝐤 𝐁𝐨𝐭</b>

 • <code>{0}kickbot</code> - Kick semua bot dari grup</blockquote>
"""

@PY.UBOT("kickbot")
@PY.TOP_CMD
async def kick_bot(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    msg = await message.reply("🔍 Mencari bot...")
    kicked = 0
    async for member in client.get_chat_members(message.chat.id):
        if member.user.is_bot:
            await message.chat.ban_member(member.user.id)
            kicked += 1
    await msg.edit(f"✅ {kicked} bot berhasil dikick!")
