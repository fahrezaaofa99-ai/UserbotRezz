from PyroUbot import *
import requests

__MODULE__ = "𝐓𝐢𝐧𝐲𝐔𝐑𝐋"
__HELP__ = """
<blockquote><b>🔗 𝐓𝐢𝐧𝐲𝐔𝐑𝐋</b>

 • <code>{0}tiny &lt;url></code> - Pendekin link dengan TinyURL</blockquote>
"""

@PY.UBOT("tiny")
@PY.TOP_CMD
async def tinyurl_shortener(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tiny <url>")
    msg = await message.reply("🔗 Memendekkan...")
    try:
        r = requests.get(f"https://tinyurl.com/api-create.php?url={args[1]}")
        if r.status_code == 200:
            await msg.edit(f"🔗 **Short URL:** {r.text}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
