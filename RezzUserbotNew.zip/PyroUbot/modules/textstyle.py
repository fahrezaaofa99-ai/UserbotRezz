# Nama file: /root/RezzUserbot/PyroUbot/modules/textstyle.py
# Fitur: Mengubah gaya teks

from PyroUbot import *

__MODULE__ = "ᴛᴇxᴛsᴛʏʟᴇ"
__HELP__ = """
<blockquote><b>🎨 TEXT STYLER</b>

• <code>{0}bold</code> [teks] - Tebal
• <code>{0}italic</code> [teks] - Miring
• <code>{0}underline</code> [teks] - Garis bawah
• <code>{0}strike</code> [teks] - Coret
• <code>{0}mono</code> [teks] - Monospace
• <code>{0}spoiler</code> [teks] - Spoiler
• <code>{0}superscript</code> [teks] - Pangkat atas
• <code>{0}subscript</code> [teks] - Pangkat bawah
• <code>{0}flip</code> [teks] - Balik teks (upside down)
• <code>{0}zalgo</code> [teks] - Text horror
• <code>{0}vapor</code> [teks] - Vaporwave style
• <code>{0}clown</code> [teks] - Clown style</blockquote>
"""

@PY.UBOT("bold")
@PY.TOP_CMD
async def bold_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>bold hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<b>{text}</b>")

@PY.UBOT("italic")
@PY.TOP_CMD
async def italic_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>italic hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<i>{text}</i>")

@PY.UBOT("underline")
@PY.TOP_CMD
async def underline_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>underline hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<u>{text}</u>")

@PY.UBOT("strike")
@PY.TOP_CMD
async def strike_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>strike hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<s>{text}</s>")

@PY.UBOT("mono")
@PY.TOP_CMD
async def mono_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>mono hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<code>{text}</code>")

@PY.UBOT("spoiler")
@PY.TOP_CMD
async def spoiler_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>spoiler hello</code>")
    text = message.text.split(None, 1)[1]
    await message.reply(f"<tg-spoiler>{text}</tg-spoiler>")

@PY.UBOT("flip")
@PY.TOP_CMD
async def flip_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>flip hello</code>")
    text = message.text.split(None, 1)[1]
    flipped = text[::-1]
    await message.reply(f"<b>🔄 FLIPPED</b>\n\n{flipped}")

@PY.UBOT("zalgo")
@PY.TOP_CMD
async def zalgo_text(client, message):
    if len(message.command) < 2:
        return await message.reply("Contoh: <code>zalgo hello</code>")
    text = message.text.split(None, 1)[1]
    zalgo_chars = ['̖', '̗', '̘', '̙', '̜', '̝', '̞', '̟', '̠', '̤', '̥', '̦', '̩', '̪', '̫', '̬', '̭', '̮', '̯', '̰', '̱', '̲', '̳', '̹', '̺', '̻', '̼', 'ͅ', '͇', '͈', '͉', '͍', '͎', '͓', '͔', '͕', '͖', '͙', '͚', '͜', '͝', '͞', '͟', '͠', '͡', '͢']
    result = ''.join(c + random.choice(zalgo_chars) for c in text)
    await message.reply(f"<b>👻 ZALGO</b>\n\n{result}")
