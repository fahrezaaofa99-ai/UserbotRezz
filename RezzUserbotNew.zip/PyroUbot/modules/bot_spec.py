from PyroUbot import *
import platform
import psutil

__MODULE__ = "𝐁𝐨𝐭𝐒𝐩𝐞𝐜"
__HELP__ = """
<blockquote><b>🖥️ 𝐁𝐨𝐭 𝐒𝐩𝐞𝐜𝐢𝐟𝐢𝐜𝐚𝐭𝐢𝐨𝐧</b>

 • <code>{0}spec</code> - Lihat spesifikasi bot</blockquote>
"""

@PY.UBOT("spec")
@PY.TOP_CMD
async def bot_specification(client, message):
    cpu = platform.processor()
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    text = f"""
╭──〔 🖥️ 𝐁𝐎𝐓 𝐒𝐏𝐄𝐂 〕
│
│ 💻 **CPU:** {cpu or 'Unknown'}
│ 🧠 **RAM:** {ram.total / (1024**3):.1f} GB
│ 📊 **RAM Used:** {ram.percent}%
│ 💾 **Disk:** {disk.total / (1024**3):.1f} GB
│ 📀 **Disk Used:** {disk.percent}%
│ 🐍 **Python:** {platform.python_version()}
│
╰── ✨ Bot Spec ✨"""
    await message.reply(text)
