from PyroUbot import *
import requests

__MODULE__ = "𝐈𝐏𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>🌐 𝐈𝐏 𝐈𝐧𝐟𝐨</b>

 • <code>{0}ip &lt;ip></code> - Info IP
 • <code>{0}myip</code> - IP sendiri</blockquote>
"""

@PY.UBOT("ip")
@PY.TOP_CMD
async def ip_info(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .ip <ip>")
    msg = await message.reply("🌐 Mencari...")
    try:
        r = requests.get(f"http://ip-api.com/json/{args[1]}")
        if r.status_code == 200:
            data = r.json()
            if data['status'] == 'success':
                await msg.edit(f"🌐 **IP:** {data['query']}\n📍 **Negara:** {data['country']}\n🏙️ **Kota:** {data['city']}")
            else:
                await msg.edit("❌ IP tidak valid")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("myip")
@PY.TOP_CMD
async def my_ip(client, message):
    msg = await message.reply("🌐 Mengambil IP...")
    try:
        r = requests.get("https://api.ipify.org?format=json")
        if r.status_code == 200:
            ip = r.json()['ip']
            await msg.edit(f"🌐 **IP Kamu:** `{ip}`")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
