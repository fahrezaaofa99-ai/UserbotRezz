from PyroUbot import *
import requests

__MODULE__ = "𝐁𝐓𝐂"
__HELP__ = """
<blockquote><b>💰 𝐁𝐢𝐭𝐜𝐨𝐢𝐧</b>

 • <code>{0}btc</code> - Harga Bitcoin</blockquote>
"""

@PY.UBOT("btc")
@PY.TOP_CMD
async def btc_price(client, message):
    msg = await message.reply("💰 Mengambil harga BTC...")
    try:
        r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,idr")
        if r.status_code == 200:
            data = r.json()
            usd = data['bitcoin']['usd']
            idr = data['bitcoin']['idr']
            await msg.edit(f"💰 **Bitcoin (BTC)**\n\n💵 USD: ${usd:,.0f}\n🇮🇩 IDR: Rp{idr:,.0f}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
