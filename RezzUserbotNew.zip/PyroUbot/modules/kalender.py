# Nama file: /root/RezzUserbot/PyroUbot/modules/kalender.py
# Fitur: Kalender dan perhitungan tanggal

from PyroUbot import *
from datetime import datetime, timedelta
import calendar

__MODULE__ = "ᴋᴀʟᴇɴᴅᴇʀ"
__HELP__ = """
<blockquote><b>📅 KALENDER & TANGGAL</b>

• <code>{0}kalender</code> [bulan] [tahun] - Tampilkan kalender
  Contoh: <code>{0}kalender 3 2026</code>

• <code>{0}hari</code> [tanggal] - Cek hari dari tanggal
  Contoh: <code>{0}hari 2026-03-19</code>

• <code>{0}selisih</code> [tanggal1] [tanggal2] - Selisih hari
  Contoh: <code>{0}selisih 2026-03-19 2026-12-31</code>

• <code>{0}ultah</code> [tanggal lahir] - Hitung ultah berikutnya
  Contoh: <code>{0}ultah 1990-01-01</code>

• <code>{0}umur</code> [tanggal lahir] - Hitung umur sekarang
• <code>{0}minggu</code> - Nomor minggu sekarang
• <code>{0}tahun</code> - Info tahun ini (kabisat? libur?)
• <code>{0}ramadhan</code> - Info Ramadhan 2026
• <code>{0}libur</code> - Libur nasional bulan ini
• <code>{0}waktu</code> [kota] - Waktu di berbagai kota</blockquote>
"""

@PY.UBOT("kalender")
@PY.TOP_CMD
async def show_calendar(client, message):
    if len(message.command) < 3:
        now = datetime.now()
        bulan = now.month
        tahun = now.year
    else:
        try:
            bulan = int(message.command[1])
            tahun = int(message.command[2])
            if bulan < 1 or bulan > 12:
                return await message.reply("Bulan harus 1-12")
        except:
            return await message.reply("Format: kalender [bulan] [tahun]")
    
    cal = calendar.month(tahun, bulan)
    nama_bulan = calendar.month_name[bulan]
    
    await message.reply(f"<b>📅 {nama_bulan} {tahun}</b>\n<pre>{cal}</pre>")

@PY.UBOT("hari")
@PY.TOP_CMD
async def cek_hari(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: hari YYYY-MM-DD")
    
    try:
        tgl = datetime.strptime(message.command[1], "%Y-%m-%d")
        hari = tgl.strftime("%A")
        
        hari_ind = {
            "Monday": "Senin", "Tuesday": "Selasa", "Wednesday": "Rabu",
            "Thursday": "Kamis", "Friday": "Jumat", "Saturday": "Sabtu",
            "Sunday": "Minggu"
        }
        
        await message.reply(
            f"<b>📅 CEK HARI</b>\n\n"
            f"Tanggal: {message.command[1]}\n"
            f"Hari: {hari_ind.get(hari, hari)}"
        )
    except:
        await message.reply("Format tanggal salah! Gunakan YYYY-MM-DD")

@PY.UBOT("selisih")
@PY.TOP_CMD
async def selisih_hari(client, message):
    if len(message.command) < 3:
        return await message.reply("Format: selisih YYYY-MM-DD YYYY-MM-DD")
    
    try:
        tgl1 = datetime.strptime(message.command[1], "%Y-%m-%d")
        tgl2 = datetime.strptime(message.command[2], "%Y-%m-%d")
        
        selisih = abs((tgl2 - tgl1).days)
        
        await message.reply(
            f"<b>📊 SELISIH HARI</b>\n\n"
            f"{message.command[1]} → {message.command[2]}\n"
            f"Selisih: {selisih} hari\n"
            f"≈ {selisih//7} minggu {selisih%7} hari\n"
            f"≈ {selisih/30:.1f} bulan"
        )
    except:
        await message.reply("Format tanggal salah! Gunakan YYYY-MM-DD")

@PY.UBOT("umur")
@PY.TOP_CMD
async def hitung_umur(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: umur YYYY-MM-DD")
    
    try:
        lahir = datetime.strptime(message.command[1], "%Y-%m-%d")
        sekarang = datetime.now()
        
        umur = sekarang.year - lahir.year
        if (sekarang.month, sekarang.day) < (lahir.month, lahir.day):
            umur -= 1
        
        ultah_berikutnya = lahir.replace(year=sekarang.year)
        if ultah_berikutnya < sekarang:
            ultah_berikutnya = ultah_berikutnya.replace(year=sekarang.year + 1)
        
        sisa = (ultah_berikutnya - sekarang).days
        
        await message.reply(
            f"<b>🎂 HITUNG UMUR</b>\n\n"
            f"Tanggal lahir: {message.command[1]}\n"
            f"Umur sekarang: {umur} tahun\n"
            f"Ultah berikutnya: {ultah_berikutnya.strftime('%d %B %Y')}\n"
            f"Sisa: {sisa} hari lagi"
        )
    except:
        await message.reply("Format tanggal salah! Gunakan YYYY-MM-DD")

@PY.UBOT("ultah")
@PY.TOP_CMD
async def ultah_berikutnya(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: ultah YYYY-MM-DD")
    
    try:
        lahir = datetime.strptime(message.command[1], "%Y-%m-%d")
        sekarang = datetime.now()
        
        ultah_berikutnya = lahir.replace(year=sekarang.year)
        if ultah_berikutnya < sekarang:
            ultah_berikutnya = ultah_berikutnya.replace(year=sekarang.year + 1)
        
        sisa = (ultah_berikutnya - sekarang).days
        hari = ultah_berikutnya.strftime("%A")
        
        hari_ind = {
            "Monday": "Senin", "Tuesday": "Selasa", "Wednesday": "Rabu",
            "Thursday": "Kamis", "Friday": "Jumat", "Saturday": "Sabtu",
            "Sunday": "Minggu"
        }
        
        await message.reply(
            f"<b>🎂 ULTAH BERIKUTNYA</b>\n\n"
            f"Ultah: {ultah_berikutnya.strftime('%d %B %Y')}\n"
            f"Hari: {hari_ind.get(hari, hari)}\n"
            f"Sisa: {sisa} hari lagi"
        )
    except:
        await message.reply("Format tanggal salah! Gunakan YYYY-MM-DD")

@PY.UBOT("minggu")
@PY.TOP_CMD
async def nomor_minggu(client, message):
    sekarang = datetime.now()
    minggu = sekarang.isocalendar()[1]
    
    await message.reply(
        f"<b>📅 INFO MINGGU</b>\n\n"
        f"Hari ini: {sekarang.strftime('%d %B %Y')}\n"
        f"Minggu ke-{minggu} dari 52 minggu"
    )

@PY.UBOT("tahun")
@PY.TOP_CMD
async def info_tahun(client, message):
    sekarang = datetime.now()
    tahun = sekarang.year
    
    kabisat = "✅ Ya" if calendar.isleap(tahun) else "❌ Bukan"
    
    libur_nasional = [
        "1 Jan - Tahun Baru",
        "29 Mar - Nyepi",
        "31 Mar - Wafat Isa Almasih",
        "1 Mei - Buruh",
        "14 Mei - Kenaikan Isa",
        "27 Mei - Waisak",
        "1 Jun - Pancasila",
        "27 Jun - Idul Adha",
        "18 Jul - Tahun Baru Islam",
        "17 Agu - Kemerdekaan",
        "26 Sep - Maulid Nabi",
        "25 Des - Natal"
    ]
    
    text = f"""
<b>📆 INFO TAHUN {tahun}</b>

📅 Tahun kabisat: {kabisat}
🗓️ Total minggu: 52
🌙 Ramadhan: Maret-April (estimasi)

📌 Libur nasional {tahun}:
"""
    for libur in libur_nasional[:5]:
        text += f"• {libur}\n"
    text += "...dan 7 lainnya"
    
    await message.reply(text)

@PY.UBOT("ramadhan")
@PY.TOP_CMD
async def info_ramadhan(client, message):
    await message.reply(
        "<b>🌙 INFO RAMADAN 2026</b>\n\n"
        "1 Ramadan 1447 H: estimasi 19 Maret 2026\n"
        "1 Syawal 1447 H: estimasi 18 April 2026\n\n"
        "📅 Puasa: 30 hari\n"
        "📍 Libur: Idul Fitri 18-19 April"
    )
