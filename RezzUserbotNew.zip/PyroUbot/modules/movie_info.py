from PyroUbot import *
import requests

__MODULE__ = "𝐌𝐨𝐯𝐢𝐞 𝐈𝐧𝐟𝐨"
__HELP__ = """
<blockquote><b>🎬 𝐌𝐨𝐯𝐢𝐞 𝐈𝐧𝐟𝐨</b>

 • <code>{0}movie &lt;judul></code> - Info film
 • <code>{0}tvshow &lt;judul></code> - Info TV series
 • <code>{0}upcoming</code> - Film coming soon
 • <code>{0}nowplaying</code> - Film di bioskop
 • <code>{0}toprated</code> - Film rating tertinggi
 • <code>{0}popular</code> - Film terpopuler</blockquote>
"""

API_KEY = "trilogy"

@PY.UBOT("movie")
@PY.TOP_CMD
async def movie_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .movie <judul>")
    msg = await message.reply("🎬 Mencari film...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?t={args[1]}&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = f"""
╭──〔 🎬 INFO FILM 〕
│
│ 📌 {data.get('Title', 'N/A')}
│ 📅 {data.get('Year', 'N/A')}
│ ⭐ {data.get('imdbRating', 'N/A')}/10
│ 🎭 {data.get('Genre', 'N/A')}
│ 🎬 Sutradara: {data.get('Director', 'N/A')}
│ 👤 Pemain: {data.get('Actors', 'N/A')}
│ 📝 {data.get('Plot', 'N/A')[:200]}...
│
╰── ✨ Movie Info ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Film tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("tvshow")
@PY.TOP_CMD
async def tv_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .tvshow <judul>")
    msg = await message.reply("📺 Mencari TV series...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?t={args[1]}&type=series&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = f"""
╭──〔 📺 INFO TV SERIES 〕
│
│ 📌 {data.get('Title', 'N/A')}
│ 📅 {data.get('Year', 'N/A')}
│ ⭐ {data.get('imdbRating', 'N/A')}/10
│ 🎭 {data.get('Genre', 'N/A')}
│ 📊 {data.get('totalSeasons', 'N/A')} Season
│
╰── ✨ TV Series ✨"""
                await msg.edit(text)
            else:
                await msg.edit("❌ Series tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("upcoming")
@PY.TOP_CMD
async def upcoming_movies(client, message):
    msg = await message.reply("🎬 Mengambil film coming soon...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?s=2025&type=movie&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = "🎬 **FILM COMING SOON**\n\n"
                for i, movie in enumerate(data.get('Search', [])[:5], 1):
                    text += f"{i}. {movie.get('Title', 'N/A')} ({movie.get('Year', 'N/A')})\n"
                await msg.edit(text)
            else:
                await msg.edit("❌ Gagal mengambil data")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("nowplaying")
@PY.TOP_CMD
async def now_playing(client, message):
    msg = await message.reply("🎬 Mengambil film di bioskop...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?s=2024&type=movie&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = "🎬 **FILM DI BIOSKOP**\n\n"
                for i, movie in enumerate(data.get('Search', [])[:5], 1):
                    text += f"{i}. {movie.get('Title', 'N/A')} ({movie.get('Year', 'N/A')})\n"
                await msg.edit(text)
            else:
                await msg.edit("❌ Gagal mengambil data")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("toprated")
@PY.TOP_CMD
async def top_rated(client, message):
    msg = await message.reply("🎬 Mengambil film rating tertinggi...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?s=top&type=movie&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = "🏆 **FILM RATING TERTINGGI**\n\n"
                for i, movie in enumerate(data.get('Search', [])[:5], 1):
                    text += f"{i}. {movie.get('Title', 'N/A')} ({movie.get('Year', 'N/A')})\n"
                await msg.edit(text)
            else:
                await msg.edit("❌ Gagal mengambil data")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

@PY.UBOT("popular")
@PY.TOP_CMD
async def popular_movies(client, message):
    msg = await message.reply("🎬 Mengambil film terpopuler...")
    try:
        r = requests.get(f"http://www.omdbapi.com/?s=popular&type=movie&apikey={API_KEY}")
        if r.status_code == 200:
            data = r.json()
            if data.get('Response') == 'True':
                text = "🔥 **FILM TERPOPULER**\n\n"
                for i, movie in enumerate(data.get('Search', [])[:5], 1):
                    text += f"{i}. {movie.get('Title', 'N/A')} ({movie.get('Year', 'N/A')})\n"
                await msg.edit(text)
            else:
                await msg.edit("❌ Gagal mengambil data")
        else:
            await msg.edit("❌ Gagal")
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)[:100]}")

