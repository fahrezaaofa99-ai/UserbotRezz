from PyroUbot import *
import requests

__MODULE__ = "𝐒𝐢𝐦𝐬𝐢𝐦𝐢"
__HELP__ = """
<blockquote><b>🤖 𝐒𝐢𝐦𝐬𝐢𝐦𝐢</b>

 • <code>{0}simi &lt;teks></code> - Chat dengan Simsimi</blockquote>
"""

@PY.UBOT("simi")
@PY.TOP_CMD
async def simsimi_chat(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .simi <teks>")
    msg = await message.reply("🤖 Berpikir...")
    try:
        r = requests.get(f"https://api.simsimi.net/v2/?text={args[1]}&lc=id")
        if r.status_code == 200:
            balasan = r.json().get('success', 'Maaf aku gak ngerti')
            await msg.edit(f"🤖 **Simsimi:** {balasan}")
        else:
            await msg.edit("❌ Error")
    except:
        await msg.edit("❌ Error")
