from PyroUbot import *
import requests

__MODULE__ = "𝐁𝐫𝐚𝐢𝐧𝐥𝐲"
__HELP__ = """
<blockquote><b>🧠 𝐁𝐫𝐚𝐢𝐧𝐥𝐲</b>

 • <code>{0}brainly &lt;pertanyaan></code> - Tanya ke Brainly</blockquote>
"""

@PY.UBOT("brainly")
@PY.TOP_CMD
async def brainly_search(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .brainly <pertanyaan>")
    msg = await message.reply("🧠 Mencari jawaban...")
    try:
        r = requests.get(f"https://brainly-api.vercel.app/api/question?q={args[1]}", timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get('answer'):
                await msg.edit(f"🧠 **Jawaban:**\n\n{data['answer'][:500]}")
            else:
                await msg.edit("❌ Tidak ditemukan")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
