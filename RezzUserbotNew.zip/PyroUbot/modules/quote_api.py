from PyroUbot import *
import requests

__MODULE__ = "𝐐𝐮𝐨𝐭𝐞 𝐀𝐏𝐈"
__HELP__ = """
<blockquote><b>💬 𝐐𝐮𝐨𝐭𝐞 𝐀𝐏𝐈</b>

 • <code>{0}inspire</code> - Quote inspiratif
 • <code>{0}quote</code> - Quote random
 • <code>{0}animequote</code> - Quote anime
 • <code>{0}motivate</code> - Quote motivasi</blockquote>
"""

@PY.UBOT("inspire")
@PY.TOP_CMD
async def inspire_quote(client, message):
    try:
        r = requests.get("https://inspirobot.me/api?generate=true")
        if r.status_code == 200:
            img_url = r.text
            await message.reply_photo(img_url)
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("quote")
@PY.TOP_CMD
async def random_quote(client, message):
    try:
        r = requests.get("https://api.quotable.io/random")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"💬 **{data['content']}**\n\n— {data['author']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("animequote")
@PY.TOP_CMD
async def anime_quote_api(client, message):
    try:
        r = requests.get("https://animechan.xyz/api/random")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"🎌 **{data['quote']}**\n\n— {data['character']} ({data['anime']})")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")

@PY.UBOT("motivate")
@PY.TOP_CMD
async def motivate_quote(client, message):
    try:
        r = requests.get("https://type.fit/api/quotes")
        if r.status_code == 200:
            quotes = r.json()
            import random
            q = random.choice(quotes)
            await message.reply(f"💪 **{q['text']}**\n\n— {q['author']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
