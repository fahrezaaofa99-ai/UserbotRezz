from PyroUbot import *
import requests

__MODULE__ = "𝐂𝐨𝐯𝐢𝐝𝐆𝐥𝐨𝐛𝐚𝐥"
__HELP__ = """
<blockquote><b>🦠 𝐂𝐨𝐯𝐢𝐝 𝐆𝐥𝐨𝐛𝐚𝐥</b>

 • <code>{0}covid</code> - Data Covid Global</blockquote>
"""

@PY.UBOT("covid")
@PY.TOP_CMD
async def covid_global(client, message):
    msg = await message.reply("🦠 Mengambil data...")
    try:
        r = requests.get("https://disease.sh/v3/covid-19/all")
        if r.status_code == 200:
            data = r.json()
            await msg.edit(f"🦠 **COVID-19 GLOBAL**\n\n🟢 Kasus: {data['cases']:,}\n🔴 Meninggal: {data['deaths']:,}\n✅ Sembuh: {data['recovered']:,}")
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")
