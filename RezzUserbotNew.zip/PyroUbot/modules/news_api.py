from PyroUbot import *
import requests

__MODULE__ = "𝐍𝐞𝐰𝐬 𝐀𝐏𝐈"
__HELP__ = """
<blockquote><b>📰 𝐍𝐞𝐰𝐬 𝐀𝐏𝐈</b>

 • <code>{0}topnews</code> - Headline Indonesia
 • <code>{0}technews</code> - Berita teknologi
 • <code>{0}sportsnews</code> - Berita olahraga</blockquote>
"""

@PY.UBOT("topnews")
@PY.TOP_CMD
async def top_news(client, message):
    msg = await message.reply("📰 Mengambil berita...")
    try:
        r = requests.get("https://gnews.io/api/v4/top-headlines?country=id&token=YOUR_API_KEY")
        if r.status_code == 200:
            text = "📰 **TOP HEADLINE INDONESIA**\n\n"
            for article in r.json().get('articles', [])[:5]:
                text += f"• {article['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ API Key tidak valid")
    except:
        await msg.edit("❌ Error")
