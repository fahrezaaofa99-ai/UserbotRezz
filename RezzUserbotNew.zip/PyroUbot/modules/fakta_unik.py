from PyroUbot import *
import random

__MODULE__ = "𝐅𝐚𝐤𝐭𝐚𝐔𝐧𝐢𝐤"
__HELP__ = """
<blockquote><b>📢 𝐅𝐚𝐤𝐭𝐚 𝐔𝐧𝐢𝐤</b>

 • <code>{0}faktaunik</code> - Fakta unik random</blockquote>
"""

fakta_unik_list = [
    "Kangguru tidak bisa jalan mundur",
    "Kuda nil susunya berwarna pink",
    "Burung unta punya mata lebih besar dari otaknya",
    "Gurita punya 3 jantung",
    "Kulit manusia berganti setiap 27 hari"
]

@PY.UBOT("faktaunik")
@PY.TOP_CMD
async def fakta_unik_func(client, message):
    await message.reply(f"📢 **Fakta Unik:**\n\n{random.choice(fakta_unik_list)}")
