import asyncio
from pyrogram import Client, filters

# Informasi modul
__MODULE__ = "info bot"
__HELP__ = """
<b>𝚁𝙴𝚉𝚉 𝚄𝚂𝙴𝚁𝙱𝙾𝚃

⎆ adalah user bot rezz yang digunakan untuk memudahkan pengguna dalam pekerjaan mereka seperti broadcast otomatis ke semua grup , convert gambar menjadi link , serta banyak lagi kegunaan nya
"""
