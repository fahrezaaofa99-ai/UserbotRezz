from PyroUbot import *
import random
import json
import os
import asyncio

__MODULE__ = "𝐐𝐮𝐢𝐳 𝐆𝐚𝐦𝐞"
__HELP__ = """
<blockquote><b>🎮 𝐐𝐮𝐢𝐳 𝐆𝐚𝐦𝐞</b>

 • <code>{0}quiz</code> - Mulai quiz
 • <code>{0}quizmath</code> - Quiz matematika
 • <code>{0}quizindo</code> - Quiz pengetahuan umum
 • <code>{0}quizrandom</code> - Quiz random
 • <code>{0}quizscore</code> - Lihat skor
 • <code>{0}quizreset</code> - Reset skor</blockquote>
"""

QUIZ_FILE = "quiz_scores.json"
ACTIVE_QUIZ = {}

def load_scores():
    if os.path.exists(QUIZ_FILE):
        with open(QUIZ_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_scores(scores):
    with open(QUIZ_FILE, 'w') as f:
        json.dump(scores, f, indent=2)

quiz_data = {
    "umum": [
        {"soal": "Ibu kota Indonesia adalah?", "jawaban": "jakarta"},
        {"soal": "Presiden pertama Indonesia?", "jawaban": "soekarno"},
        {"soal": "Tanggal kemerdekaan Indonesia?", "jawaban": "17 agustus"},
        {"soal": "Bahasa resmi Indonesia?", "jawaban": "indonesia"},
        {"soal": "Pulau terbesar di Indonesia?", "jawaban": "kalimantan"}
    ],
    "math": [
        {"soal": "1 + 1 = ?", "jawaban": "2"},
        {"soal": "5 x 5 = ?", "jawaban": "25"},
        {"soal": "10 - 7 = ?", "jawaban": "3"},
        {"soal": "20 / 4 = ?", "jawaban": "5"},
        {"soal": "Akar dari 64 adalah?", "jawaban": "8"}
    ]
}

@PY.UBOT("quiz")
@PY.TOP_CMD
async def quiz_game(client, message):
    chat_id = message.chat.id
    if chat_id in ACTIVE_QUIZ:
        return await message.reply("❌ Masih ada quiz aktif!")
    
    soal = random.choice(quiz_data["umum"])
    msg = await message.reply(f"🎯 **QUIZ!**\n\n📝 {soal['soal']}\n\n⏱️ Reply pesan ini (20 detik)")
    ACTIVE_QUIZ[chat_id] = {"jawaban": soal["jawaban"], "msg_id": msg.id}
    
    await asyncio.sleep(20)
    if chat_id in ACTIVE_QUIZ:
        del ACTIVE_QUIZ[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {soal['jawaban']}")

@PY.UBOT("quizmath")
@PY.TOP_CMD
async def quiz_math(client, message):
    chat_id = message.chat.id
    if chat_id in ACTIVE_QUIZ:
        return await message.reply("❌ Masih ada quiz aktif!")
    
    soal = random.choice(quiz_data["math"])
    msg = await message.reply(f"🧮 **QUIZ MATEMATIKA!**\n\n📝 {soal['soal']}\n\n⏱️ Reply pesan ini (15 detik)")
    ACTIVE_QUIZ[chat_id] = {"jawaban": soal["jawaban"], "msg_id": msg.id}
    
    await asyncio.sleep(15)
    if chat_id in ACTIVE_QUIZ:
        del ACTIVE_QUIZ[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {soal['jawaban']}")

@PY.UBOT("quizrandom")
@PY.TOP_CMD
async def quiz_random(client, message):
    chat_id = message.chat.id
    if chat_id in ACTIVE_QUIZ:
        return await message.reply("❌ Masih ada quiz aktif!")
    
    kategori = random.choice(["umum", "math"])
    soal = random.choice(quiz_data[kategori])
    msg = await message.reply(f"🎲 **QUIZ RANDOM!**\n\n📝 {soal['soal']}\n\n⏱️ Reply pesan ini (20 detik)")
    ACTIVE_QUIZ[chat_id] = {"jawaban": soal["jawaban"], "msg_id": msg.id}
    
    await asyncio.sleep(20)
    if chat_id in ACTIVE_QUIZ:
        del ACTIVE_QUIZ[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {soal['jawaban']}")

@PY.UBOT("quizscore")
@PY.TOP_CMD
async def quiz_score(client, message):
    scores = load_scores()
    user_id = str(message.from_user.id)
    score = scores.get(user_id, 0)
    await message.reply(f"🏆 **SKOR QUIZ KAMU:** {score} poin")

@PY.UBOT("quizreset")
@PY.TOP_CMD
async def quiz_reset(client, message):
    save_scores({})
    await message.reply("✅ Semua skor quiz direset!")

@PY.INLINE
async def quiz_answer(client, inline_query):
    message = inline_query.message
    if not message or not message.reply_to_message:
        return
    
    chat_id = message.chat.id
    quiz = ACTIVE_QUIZ.get(chat_id)
    if not quiz or message.reply_to_message.id != quiz["msg_id"]:
        return
    
    if message.text.lower().strip() == quiz["jawaban"]:
        scores = load_scores()
        user_id = str(message.from_user.id)
        scores[user_id] = scores.get(user_id, 0) + 1
        save_scores(scores)
        await message.reply(f"✅ **BENAR!** +1 poin\n📊 Skor kamu: {scores[user_id]}")
        del ACTIVE_QUIZ[chat_id]
    else:
        await message.reply("❌ **SALAH!** Coba lagi")

