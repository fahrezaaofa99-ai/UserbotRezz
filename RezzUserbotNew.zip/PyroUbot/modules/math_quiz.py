from PyroUbot import *
import random

__MODULE__ = "𝐌𝐚𝐭𝐡𝐐𝐮𝐢𝐳"
__HELP__ = """
<blockquote><b>🧮 𝐌𝐚𝐭𝐡 𝐐𝐮𝐢𝐳</b>

 • <code>{0}mathquiz</code> - Quiz matematika</blockquote>
"""

MATH_GAMES = {}

@PY.UBOT("mathquiz")
@PY.TOP_CMD
async def math_quiz(client, message):
    chat_id = message.chat.id
    if chat_id in MATH_GAMES:
        return await message.reply("❌ Quiz sedang berjalan!")
    a = random.randint(1, 20)
    b = random.randint(1, 20)
    op = random.choice(['+', '-', '*'])
    if op == '+': result = a + b
    elif op == '-': result = a - b
    else: result = a * b
    msg = await message.reply(f"🧮 **Math Quiz!**\n\n{a} {op} {b} = ?\nReply jawaban (20 detik)")
    MATH_GAMES[chat_id] = {"result": result, "msg_id": msg.id}
    await asyncio.sleep(20)
    if chat_id in MATH_GAMES:
        del MATH_GAMES[chat_id]
        await msg.reply(f"⏰ Waktu habis! Jawaban: {result}")

@PY.INLINE
async def check_math(client, message):
    chat_id = message.chat.id
    if chat_id not in MATH_GAMES:
        return
    if message.text and message.text.isdigit() and int(message.text) == MATH_GAMES[chat_id]["result"]:
        await message.reply(f"✅ **BENAR!** Jawabannya {MATH_GAMES[chat_id]['result']}")
        del MATH_GAMES[chat_id]
    else:
        await message.reply("❌ **SALAH!** Coba lagi")
