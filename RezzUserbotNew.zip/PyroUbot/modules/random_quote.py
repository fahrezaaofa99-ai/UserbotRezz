from PyroUbot import *
import requests

__MODULE__ = "𝐑𝐚𝐧𝐝𝐨𝐦𝐐𝐮𝐨𝐭𝐞"
__HELP__ = """
<blockquote><b>💬 𝐑𝐚𝐧𝐝𝐨𝐦 𝐐𝐮𝐨𝐭𝐞</b>

 • <code>{0}quote</code> - Quote random inspiratif</blockquote>
"""

@PY.UBOT("quote")
@PY.TOP_CMD
async def random_quote(client, message):
    try:
        r = requests.get("https://api.quotable.io/random")
        if r.status_code == 200:
            data = r.json()
            await message.reply(f"💬 **{data['content']}**\n\n— {data['author']}")
        else:
            await message.reply("❌ Gagal")
    except:
        await message.reply("❌ Error")
