# Nama file: /root/RezzUserbot/PyroUbot/modules/converter.py
# Fitur: Converter unit dan mata uang

from PyroUbot import *
import requests

__MODULE__ = "ᴄᴏɴᴠᴇʀᴛᴇʀ"
__HELP__ = """
<blockquote>Bantuan Untuk Converter

perintah : <code>{0}currency</code> [jumlah] [dari] [ke]
   contoh: <code>{0}currency 100 usd idr</code>

perintah : <code>{0}convert</code> [nilai] [dari] [ke]
   contoh: <code>{0}convert 100 cm m</code>
   support: cm, m, km, inch, foot, yard, mile

perintah : <code>{0}bitcoin</code>
   untuk cek harga bitcoin terkini</blockquote>
"""

@PY.UBOT("currency")
@PY.TOP_CMD
async def currency_convert(client, message):
    if len(message.command) < 4:
        return await message.reply("Format: <code>{0}currency 100 usd idr</code>")
    
    try:
        jumlah = float(message.command[1])
        dari = message.command[2].upper()
        ke = message.command[3].upper()
        
        # Pake API gratis
        url = f"https://api.exchangerate-api.com/v4/latest/{dari}"
        response = requests.get(url)
        
        if response.status_code != 200:
            return await message.reply("Gagal ambil data kurs")
            
        data = response.json()
        if ke not in data['rates']:
            return await message.reply(f"Mata uang {ke} tidak ditemukan")
            
        hasil = jumlah * data['rates'][ke]
        
        await message.reply(f"💱 <b>Konversi Mata Uang</b>\n\n"
                           f"{jumlah:,.2f} {dari} = {hasil:,.2f} {ke}\n\n"
                           f"Kurs: 1 {dari} = {data['rates'][ke]:,.4f} {ke}")
                           
    except Exception as e:
        await message.reply(f"Error: {str(e)}")

@PY.UBOT("convert")
@PY.TOP_CMD
async def unit_convert(client, message):
    if len(message.command) < 4:
        return await message.reply("Format: <code>{0}convert 100 cm m</code>")
    
    try:
        nilai = float(message.command[1])
        dari = message.command[2].lower()
        ke = message.command[3].lower()
        
        # Unit converter sederhana
        units = {
            'cm': 0.01, 'm': 1, 'km': 1000,
            'inch': 0.0254, 'foot': 0.3048, 'yard': 0.9144,
            'mile': 1609.34
        }
        
        if dari not in units or ke not in units:
            return await message.reply("Unit tidak support. Pake: cm, m, km, inch, foot, yard, mile")
            
        # Konversi ke meter dulu, baru ke unit tujuan
        in_meters = nilai * units[dari]
        hasil = in_meters / units[ke]
        
        await message.reply(f"📏 <b>Konversi Unit</b>\n\n"
                           f"{nilai} {dari} = {hasil:.4f} {ke}")
                           
    except Exception as e:
        await message.reply(f"Error: {str(e)}")

@PY.UBOT("bitcoin")
@PY.TOP_CMD
async def bitcoin_price(client, message):
    try:
        # Ambil harga bitcoin
        url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,idr&include_24hr_change=true"
        response = requests.get(url)
        
        if response.status_code != 200:
            return await message.reply("Gagal ambil data bitcoin")
            
        data = response.json()['bitcoin']
        
        await message.reply(f"₿ <b>Bitcoin Price</b>\n\n"
                           f"💰 USD: ${data['usd']:,.2f}\n"
                           f"💰 IDR: Rp{data['idr']:,.0f}\n"
                           f"📊 24h Change: {data['usd_24h_change']:+.2f}%")
                           
    except Exception as e:
        await message.reply(f"Error: {str(e)}")

# Fitur tambahan: Text to Speech
@PY.UBOT("tts")
@PY.TOP_CMD
async def text_to_speech(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>{0}text Hello World</code>")
    
    try:
        text = message.text.split(None, 1)[1]
        
        # Pake API TTS gratis
        url = f"https://api.streamelements.com/kappa/v2/speech?voice=Brian&text={text}"
        
        await message.reply("🔊 <b>Membuat audio...</b>")
        
        # Kirim sebagai voice message
        await client.send_voice(
            chat_id=message.chat.id,
            voice=url,
            reply_to_message_id=message.id
        )
        
    except Exception as e:
        await message.reply(f"Error: {str(e)}")

# Fitur: QR Code Generator
@PY.UBOT("qr")
@PY.TOP_CMD
async def qr_generator(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: <code>{0}qr text/link disini</code>")
    
    try:
        text = message.text.split(None, 1)[1]
        
        # Generate QR code
        url = f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={text}"
        
        await message.reply("📱 <b>Membuat QR Code...</b>")
        
        # Kirim sebagai foto
        await client.send_photo(
            chat_id=message.chat.id,
            photo=url,
            caption=f"QR Code untuk: {text[:50]}..."
        )
        
    except Exception as e:
        await message.reply(f"Error: {str(e)}")
