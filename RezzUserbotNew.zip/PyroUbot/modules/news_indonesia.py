from PyroUbot import *
import requests

__MODULE__ = "𝐍𝐞𝐰𝐬 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚"
__HELP__ = """
<blockquote><b>📰 𝐍𝐞𝐰𝐬 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚</b>

 • <code>{0}cnn</code> - Berita CNN Indonesia
 • <code>{0}kompas</code> - Berita Kompas
 • <code>{0}tribun</code> - Berita Tribun
 • <code>{0}liputan6</code> - Berita Liputan6
 • <code>{0}tempo</code> - Berita Tempo
 • <code>{0}newsall</code> - Semua berita</blockquote>
"""

@PY.UBOT("cnn")
@PY.TOP_CMD
async def cnn_news(client, message):
    msg = await message.reply("📰 Mengambil berita CNN...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/cnn/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **CNN INDONESIA TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("kompas")
@PY.TOP_CMD
async def kompas_news(client, message):
    msg = await message.reply("📰 Mengambil berita Kompas...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/kompas/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **KOMPAS TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("tribun")
@PY.TOP_CMD
async def tribun_news(client, message):
    msg = await message.reply("📰 Mengambil berita Tribun...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/tribun/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **TRIBUN TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("liputan6")
@PY.TOP_CMD
async def liputan6_news(client, message):
    msg = await message.reply("📰 Mengambil berita Liputan6...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/liputan6/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **LIPUTAN6 TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("tempo")
@PY.TOP_CMD
async def tempo_news(client, message):
    msg = await message.reply("📰 Mengambil berita Tempo...")
    try:
        r = requests.get("https://api-berita-indonesia.vercel.app/tempo/terbaru/")
        if r.status_code == 200:
            data = r.json()
            text = "📰 **TEMPO TERBARU**\n\n"
            for i, item in enumerate(data['data'][:5], 1):
                text += f"{i}. {item['title']}\n"
            await msg.edit(text)
        else:
            await msg.edit("❌ Gagal")
    except:
        await msg.edit("❌ Error")

@PY.UBOT("newsall")
@PY.TOP_CMD
async def all_news(client, message):
    msg = await message.reply("📰 Mengambil semua berita...")
    try:
        sources = ['cnn', 'kompas', 'tribun', 'liputan6', 'tempo']
        text = "📰 **RINGKASAN BERITA INDONESIA**\n\n"
        for source in sources:
            r = requests.get(f"https://api-berita-indonesia.vercel.app/{source}/terbaru/")
            if r.status_code == 200:
                data = r.json()
                if data['data']:
                    text += f"**{source.upper()}:** {data['data'][0]['title'][:50]}...\n\n"
        await msg.edit(text)
    except:
        await msg.edit("❌ Error")
