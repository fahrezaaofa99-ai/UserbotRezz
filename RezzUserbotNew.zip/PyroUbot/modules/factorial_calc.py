from PyroUbot import *
import math

__MODULE__ = "𝐅𝐚𝐜𝐭𝐨𝐫𝐢𝐚𝐥"
__HELP__ = """
<blockquote><b>🔢 𝐅𝐚𝐜𝐭𝐨𝐫𝐢𝐚𝐥</b>

 • <code>{0}faktorial &lt;angka></code> - Hitung faktorial</blockquote>
"""

@PY.UBOT("faktorial")
@PY.TOP_CMD
async def faktorial_calc(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .faktorial <angka>")
    try:
        n = int(args[1])
        hasil = math.factorial(n)
        await message.reply(f"🔢 {n}! = {hasil}")
    except:
        await message.reply("❌ Error")
