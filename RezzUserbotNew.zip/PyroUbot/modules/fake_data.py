from PyroUbot import *
import random
import string
from faker import Faker
import requests
import json

__MODULE__ = "𝐅𝐚𝐤𝐞 𝐃𝐚𝐭𝐚 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫"
__HELP__ = """
<blockquote><b>🎭 𝐅𝐚𝐤𝐞 𝐃𝐚𝐭𝐚 𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐨𝐫</b>

<b>👤 𝐏𝐑𝐎𝐅𝐈𝐋</b>
 • <code>{0}fakename</code> - Nama lengkap random
 • <code>{0}fakeusername</code> - Username random
 • <code>{0}fakeprofile</code> - Profil lengkap (nama, umur, alamat)

<b>📧 𝐊𝐎𝐍𝐓𝐀𝐊</b>
 • <code>{0}fakeemail</code> - Email random
 • <code>{0}fakephone</code> - Nomor HP random
 • <code>{0}fakecontact</code> - Kontak lengkap

<b>🏠 𝐀𝐋𝐀𝐌𝐀𝐓</b>
 • <code>{0}fakeaddress</code> - Alamat random
 • <code>{0}fakecity</code> - Kota random
 • <code>{0}fakepostal</code> - Kode pos random

<b>💳 𝐊𝐄𝐔𝐀𝐍𝐆𝐀𝐍</b>
 • <code>{0}fakecard</code> - Kartu kredit random
 • <code>{0}fakebank</code> - Info bank random
 • <code>{0}fakecrypto</code> - Wallet crypto random

<b>🆔 𝐈𝐃𝐄𝐍𝐓𝐈𝐓𝐀𝐒</b>
 • <code>{0}fakepid</code> - KTP/PASSPORT
 • <code>{0}fakepassport</code> - Passport random
 • <code>{0}fakessn</code> - SSN/NIK random

<b>🌐 𝐎𝐍𝐋𝐈𝐍𝐄</b>
 • <code>{0}fakeip</code> - IP address random
 • <code>{0}fakeuseragent</code> - User agent random
 • <code>{0}fakemac</code> - MAC address random

<b>🎲 𝐋𝐀𝐈𝐍𝐍𝐘𝐀</b>
 • <code>{0}fakecolor</code> - Warna random
 • <code>{0}fakejob</code> - Pekerjaan random
 • <code>{0}fakevehicle</code> - Kendaraan random
 • <code>{0}fakeall</code> - Generate semua data</blockquote>
"""

fake = Faker('id_ID')

@PY.UBOT("fakename")
@PY.TOP_CMD
async def fake_name(client, message):
    nama = fake.name()
    await message.reply(f"╭──〔 👤 **NAMA RANDOM** 〕\n│\n│ 📌 {nama}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakeusername")
@PY.TOP_CMD
async def fake_username(client, message):
    username = fake.user_name()
    await message.reply(f"╭──〔 @ **USERNAME RANDOM** 〕\n│\n│ 📌 @{username}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakeprofile")
@PY.TOP_CMD
async def fake_profile(client, message):
    nama = fake.name()
    umur = random.randint(18, 70)
    alamat = fake.address()
    pekerjaan = fake.job()
    email = fake.email()
    text = f"""
╭──〔 👤 **PROFIL LENGKAP** 〕
│
│ 📛 **Nama:** {nama}
│ 🎂 **Umur:** {umur} tahun
│ 💼 **Pekerjaan:** {pekerjaan}
│ 📧 **Email:** {email}
│ 🏠 **Alamat:** {alamat}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakeemail")
@PY.TOP_CMD
async def fake_email(client, message):
    email = fake.email()
    await message.reply(f"╭──〔 📧 **EMAIL RANDOM** 〕\n│\n│ 📌 {email}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakephone")
@PY.TOP_CMD
async def fake_phone(client, message):
    phone = fake.phone_number()
    await message.reply(f"╭──〔 📞 **NOMOR HP** 〕\n│\n│ 📌 {phone}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakecontact")
@PY.TOP_CMD
async def fake_contact(client, message):
    nama = fake.name()
    email = fake.email()
    phone = fake.phone_number()
    text = f"""
╭──〔 📇 **KONTAK LENGKAP** 〕
│
│ 👤 **Nama:** {nama}
│ 📧 **Email:** {email}
│ 📞 **Telepon:** {phone}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakeaddress")
@PY.TOP_CMD
async def fake_address(client, message):
    alamat = fake.address()
    await message.reply(f"╭──〔 🏠 **ALAMAT RANDOM** 〕\n│\n│ 📌 {alamat}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakecity")
@PY.TOP_CMD
async def fake_city(client, message):
    kota = fake.city()
    await message.reply(f"╭──〔 🏙️ **KOTA RANDOM** 〕\n│\n│ 📌 {kota}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakepostal")
@PY.TOP_CMD
async def fake_postal(client, message):
    postal = fake.postcode()
    await message.reply(f"╭──〔 📮 **KODE POS** 〕\n│\n│ 📌 {postal}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakecard")
@PY.TOP_CMD
async def fake_card(client, message):
    card_num = fake.credit_card_number()
    card_exp = fake.credit_card_expire()
    card_cvv = fake.credit_card_security_code()
    card_type = random.choice(['Visa', 'Mastercard', 'Amex', 'Discover'])
    text = f"""
╭──〔 💳 **KARTU KREDIT** 〕
│
│ 💳 **Tipe:** {card_type}
│ 🔢 **Nomor:** {card_num}
│ 📅 **Expired:** {card_exp}
│ 🔒 **CVV:** {card_cvv}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakebank")
@PY.TOP_CMD
async def fake_bank(client, message):
    bank = random.choice(['BCA', 'Mandiri', 'BNI', 'BRI', 'CIMB', 'Danamon'])
    account = ''.join([str(random.randint(0,9)) for _ in range(12)])
    name = fake.name()
    text = f"""
╭──〔 🏦 **INFO BANK** 〕
│
│ 🏦 **Bank:** {bank}
│ 👤 **Nama:** {name}
│ 🔢 **No Rekening:** {account}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakecrypto")
@PY.TOP_CMD
async def fake_crypto(client, message):
    btc = ''.join([random.choice(string.ascii_letters + string.digits) for _ in range(34)])
    eth = '0x' + ''.join([random.choice(string.hexdigits.lower()) for _ in range(40)])
    text = f"""
╭──〔 ₿ **CRYPTO WALLET** 〕
│
│ ₿ **BTC:** {btc}
│ Ξ **ETH:** {eth}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakepid")
@PY.TOP_CMD
async def fake_pid(client, message):
    nik = ''.join([str(random.randint(0,9)) for _ in range(16)])
    nama = fake.name()
    ttl = f"{fake.city()}, {fake.date_of_birth()}"
    alamat = fake.address()
    text = f"""
╭──〔 🆔 **KTP/IDENTITAS** 〕
│
│ 🆔 **NIK:** {nik}
│ 👤 **Nama:** {nama}
│ 📅 **TTL:** {ttl}
│ 🏠 **Alamat:** {alamat}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakepassport")
@PY.TOP_CMD
async def fake_passport(client, message):
    passport = ''.join([random.choice(string.ascii_uppercase) for _ in range(2)]) + ''.join([str(random.randint(0,9)) for _ in range(7)])
    nama = fake.name()
    negara = fake.country()
    text = f"""
╭──〔 🛂 **PASSPORT** 〕
│
│ 📘 **No Passport:** {passport}
│ 👤 **Nama:** {nama}
│ 🌍 **Negara:** {negara}
│
╰── ✨ *Fake Data* ✨"""
    await message.reply(text)

@PY.UBOT("fakessn")
@PY.TOP_CMD
async def fake_ssn(client, message):
    ssn = '-'.join([str(random.randint(100,999)), str(random.randint(10,99)), str(random.randint(1000,9999))])
    await message.reply(f"╭──〔 🆔 **SSN/NIK** 〕\n│\n│ 📌 {ssn}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakeip")
@PY.TOP_CMD
async def fake_ip(client, message):
    ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,255)}"
    await message.reply(f"╭──〔 🌐 **IP ADDRESS** 〕\n│\n│ 📌 {ip}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakeuseragent")
@PY.TOP_CMD
async def fake_useragent(client, message):
    ua = fake.user_agent()
    await message.reply(f"╭──〔 📱 **USER AGENT** 〕\n│\n│ 📌 {ua[:100]}...\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakemac")
@PY.TOP_CMD
async def fake_mac(client, message):
    mac = ':'.join(['{:02x}'.format(random.randint(0,255)) for _ in range(6)])
    await message.reply(f"╭──〔 🔌 **MAC ADDRESS** 〕\n│\n│ 📌 {mac.upper()}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakecolor")
@PY.TOP_CMD
async def fake_color(client, message):
    warna = fake.color_name()
    hex_color = fake.hex_color()
    await message.reply(f"╭──〔 🎨 **WARNA RANDOM** 〕\n│\n│ 🎨 {warna}\n│ 🔢 Hex: {hex_color}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakejob")
@PY.TOP_CMD
async def fake_job(client, message):
    job = fake.job()
    await message.reply(f"╭──〔 💼 **PEKERJAAN** 〕\n│\n│ 📌 {job}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakevehicle")
@PY.TOP_CMD
async def fake_vehicle(client, message):
    vehicle = fake.license_plate()
    brand = fake.company()
    await message.reply(f"╭──〔 🚗 **KENDRARAAN** 〕\n│\n│ 🚘 **Plat:** {vehicle}\n│ 🏭 **Merk:** {brand}\n│\n╰── ✨ *Fake Data* ✨")

@PY.UBOT("fakeall")
@PY.TOP_CMD
async def fake_all(client, message):
    nama = fake.name()
    email = fake.email()
    phone = fake.phone_number()
    alamat = fake.address()
    pekerjaan = fake.job()
    bank = random.choice(['BCA', 'Mandiri', 'BNI', 'BRI'])
    rek = ''.join([str(random.randint(0,9)) for _ in range(12)])
    ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,255)}"
    
    text = f"""
╭──〔 🎭 **FAKE DATA COMPLETE** 〕
│
│ 👤 **Nama:** {nama}
│ 📧 **Email:** {email}
│ 📞 **Telepon:** {phone}
│ 🏠 **Alamat:** {alamat}
│ 💼 **Pekerjaan:** {pekerjaan}
│ 🏦 **Bank:** {bank} - {rek}
│ 🌐 **IP:** {ip}
│
╰── ✨ *Generated by Fake Data Generator* ✨"""
    await message.reply(text)

