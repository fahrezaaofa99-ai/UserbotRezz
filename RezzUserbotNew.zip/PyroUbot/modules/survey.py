# Nama file: /root/RezzUserbot/PyroUbot/modules/survey.py
# Fitur: Buat survey dan polling

from PyroUbot import *

__MODULE__ = "sᴜʀᴠᴇʏ"
__HELP__ = """
<blockquote><b>📊 SURVEY & POLLING</b>

• <code>{0}poll</code> [pertanyaan] | [opsi1] | [opsi2] | ...
  Contoh: <code>{0}poll Makan apa? | Bakso | Mie | Sate</code>

• <code>{0}quickpoll</code> [pertanyaan] - Poll cepat (ya/tidak)
  Contoh: <code>{0}quickpoll Apakah hari ini hujan?</code>

• <code>{0}vote</code> [opsi1] [opsi2] ... - Vote sederhana
• <code>{0}pilih</code> [opsi1] [opsi2] ... - Minta orang pilih
• <code>{0}pendapat</code> [topik] - Minta pendapat</blockquote>
"""

@PY.UBOT("poll")
@PY.TOP_CMD
async def buat_poll(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: poll pertanyaan | opsi1 | opsi2 | ...")
    
    text = message.text.split(None, 1)[1]
    parts = [p.strip() for p in text.split('|')]
    
    if len(parts) < 3:
        return await message.reply("Minimal 1 pertanyaan dan 2 opsi")
    
    pertanyaan = parts[0]
    opsi = parts[1:]
    
    if len(opsi) > 10:
        return await message.reply("Maksimal 10 opsi")
    
    try:
        await client.send_poll(
            chat_id=message.chat.id,
            question=pertanyaan,
            options=opsi,
            is_anonymous=False
        )
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("quickpoll")
@PY.TOP_CMD
async def quick_poll(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: quickpoll pertanyaan")
    
    pertanyaan = message.text.split(None, 1)[1]
    
    try:
        await client.send_poll(
            chat_id=message.chat.id,
            question=pertanyaan,
            options=['Ya', 'Tidak'],
            is_anonymous=False
        )
    except Exception as e:
        await message.reply(f"❌ Error: {str(e)}")

@PY.UBOT("vote")
@PY.TOP_CMD
async def vote_sederhana(client, message):
    if len(message.command) < 3:
        return await message.reply("Format: vote opsi1 opsi2 ...")
    
    opsi = message.command[1:]
    
    text = "<b>🗳️ VOTE SEDERHANA</b>\n\n"
    for i, o in enumerate(opsi, 1):
        text += f"{i}. {o}\n"
    
    text += "\nBalas dengan nomor pilihanmu"
    
    await message.reply(text)

@PY.UBOT("pendapat")
@PY.TOP_CMD
async def minta_pendapat(client, message):
    if len(message.command) < 2:
        return await message.reply("Format: pendapat topik")
    
    topik = message.text.split(None, 1)[1]
    
    await message.reply(
        f"<b>💭 MINTA PENDAPAT</b>\n\n"
        f"Topik: {topik}\n\n"
        f"Silakan berikan pendapat kalian di bawah ini 👇"
    )
