from PyroUbot import *

__MODULE__ = "𝐀𝐧𝐚𝐠𝐫𝐚𝐦"
__HELP__ = """
<blockquote><b>🔄 𝐀𝐧𝐚𝐠𝐫𝐚𝐦 𝐂𝐡𝐞𝐜𝐤𝐞𝐫</b>

 • <code>{0}anagram &lt;kata1> &lt;kata2></code> - Cek anagram</blockquote>
"""

@PY.UBOT("anagram")
@PY.TOP_CMD
async def anagram_check(client, message):
    args = message.text.split()
    if len(args) < 3:
        return await message.reply("❌ .anagram <kata1> <kata2>")
    kata1 = ''.join(sorted(args[1].lower()))
    kata2 = ''.join(sorted(args[2].lower()))
    if kata1 == kata2:
        await message.reply(f"✅ '{args[1]}' dan '{args[2]}' adalah anagram!")
    else:
        await message.reply(f"❌ '{args[1]}' dan '{args[2]}' BUKAN anagram")
