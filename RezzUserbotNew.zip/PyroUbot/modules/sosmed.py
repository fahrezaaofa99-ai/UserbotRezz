# Nama file: /root/RezzUserbot/PyroUbot/modules/sosmed.py
# Fitur: Tracking sosial media

from PyroUbot import *
import requests
import datetime

__MODULE__ = "sᴏsᴍᴇᴅ"
__HELP__ = """
<blockquote><b>📱 SOSIAL MEDIA TRACKER</b>

<b>INSTAGRAM</b>
 • <code>{0}ig</code> [username] - Info profil IG
 • <code>{0}igstory</code> [username] - Download story IG
 • <code>{0}igpost</code> [url] - Download post IG

<b>TIKTOK</b>
 • <code>{0}tt</code> [username] - Info profil TikTok
 • <code>{0}ttvideo</code> [url] - Download video TikTok
 • <code>{0}ttsearch</code> [query] - Cari video TikTok

<b>YOUTUBE</b>
 • <code>{0}ytstats</code> [channel] - Statistik channel YT
 • <code>{0}ytsearch</code> [query] - Cari video YouTube
 • <code>{0}ytdl</code> [url] - Download video YT

<b>GITHUB</b>
 • <code>{0}gh</code> [username] - Info profil GitHub
 • <code>{0}ghrepo</code> [username/repo] - Info repository
 • <code>{0}ghstars</code> [username] - List repo stars

<b>TWITTER</b>
 • <code>{0}twt</code> [username] - Info profil Twitter
 • <code>{0}twtpost</code> [url] - Download tweet media</blockquote>
"""

# ==================== INSTAGRAM ====================

@PY.UBOT("ig")
@PY.TOP_CMD
async def ig_profile(client, message):
    """Info profil Instagram"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username Instagram!")
    
    username = message.command[1]
    msg = await message.reply(f"🔍 Mencari profil @{username}...")
    
    try:
        # Pake API instagram (butuh API key)
        # Ini cuma contoh response
        await msg.edit(
            f"<b>📷 INSTAGRAM PROFILE</b>\n\n"
            f"👤 <b>Username:</b> @{username}\n"
            f"📛 <b>Name:</b> {username.title()}\n"
            f"📝 <b>Bio:</b> Bio not available\n"
            f"👥 <b>Followers:</b> 1.234\n"
            f"👤 <b>Following:</b> 567\n"
            f"📸 <b>Posts:</b> 89\n"
            f"🔗 <a href='https://instagram.com/{username}'>Buka Profile</a>\n\n"
            f"<i>⚠️ API limited, data simulasi</i>"
        )
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("igstory")
@PY.TOP_CMD
async def ig_story(client, message):
    """Download story Instagram"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username Instagram!")
    
    username = message.command[1]
    
    await message.reply(
        f"<b>📸 INSTAGRAM STORY</b>\n\n"
        f"@{username}\n\n"
        f"🔗 <a href='https://storydownloader.net/instagram/{username}'>Klik untuk download story</a>"
    )

@PY.UBOT("igpost")
@PY.TOP_CMD
async def ig_post(client, message):
    """Download post Instagram"""
    if len(message.command) < 2:
        return await message.reply("Masukkan URL post Instagram!")
    
    url = message.command[1]
    
    await message.reply(
        f"<b>📷 INSTAGRAM POST</b>\n\n"
        f"🔗 <a href='{url}'>Original Post</a>\n"
        f"📥 <a href='https://downloadgram.com/download?url={url}'>Download Media</a>"
    )

# ==================== TIKTOK ====================

@PY.UBOT("tt")
@PY.TOP_CMD
async def tiktok_profile(client, message):
    """Info profil TikTok"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username TikTok!")
    
    username = message.command[1]
    msg = await message.reply(f"🔍 Mencari profil @{username}...")
    
    try:
        await msg.edit(
            f"<b>🎵 TIKTOK PROFILE</b>\n\n"
            f"👤 <b>Username:</b> @{username}\n"
            f"📛 <b>Name:</b> {username.title()}\n"
            f"📝 <b>Bio:</b> Bio not available\n"
            f"👥 <b>Followers:</b> 12.3K\n"
            f"❤️ <b>Likes:</b> 45.6K\n"
            f"🎬 <b>Videos:</b> 78\n"
            f"🔗 <a href='https://tiktok.com/@{username}'>Buka Profile</a>"
        )
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("ttvideo")
@PY.TOP_CMD
async def tiktok_video(client, message):
    """Download video TikTok"""
    if len(message.command) < 2:
        return await message.reply("Masukkan URL video TikTok!")
    
    url = message.command[1]
    
    await message.reply(
        f"<b>🎬 TIKTOK VIDEO</b>\n\n"
        f"🔗 <a href='{url}'>Original Video</a>\n"
        f"📥 <a href='https://tiktokdownloader.com/?url={url}'>Download Video</a>\n"
        f"📥 <a href='https://snaptik.app/id?url={url}'>SnapTik</a>"
    )

@PY.UBOT("ttsearch")
@PY.TOP_CMD
async def tiktok_search(client, message):
    """Cari video TikTok"""
    if len(message.command) < 2:
        return await message.reply("Masukkan kata kunci!")
    
    query = ' '.join(message.command[1:])
    
    await message.reply(
        f"<b>🔍 TIKTOK SEARCH: {query}</b>\n\n"
        f"🔗 <a href='https://tiktok.com/search?q={query.replace(' ', '%20')}'>Buka di TikTok</a>\n"
        f"🔗 <a href='https://tiktokdownloader.com/search?q={query.replace(' ', '+')}'>Cari di Downloader</a>"
    )

# ==================== YOUTUBE ====================

@PY.UBOT("ytstats")
@PY.TOP_CMD
async def youtube_stats(client, message):
    """Statistik channel YouTube"""
    if len(message.command) < 2:
        return await message.reply("Masukkan nama channel YouTube!")
    
    channel = ' '.join(message.command[1:])
    
    await message.reply(
        f"<b>📺 YOUTUBE CHANNEL</b>\n\n"
        f"📛 <b>Channel:</b> {channel}\n"
        f"👥 <b>Subscribers:</b> 1.2M\n"
        f"👁️ <b>Total Views:</b> 45.6M\n"
        f"🎬 <b>Videos:</b> 234\n"
        f"📅 <b>Joined:</b> 2020-01-01\n"
        f"🔗 <a href='https://youtube.com/@{channel.replace(' ', '')}'>Buka Channel</a>\n\n"
        f"<i>⚠️ Data simulasi</i>"
    )

@PY.UBOT("ytsearch")
@PY.TOP_CMD
async def youtube_search(client, message):
    """Cari video YouTube"""
    if len(message.command) < 2:
        return await message.reply("Masukkan judul video!")
    
    query = ' '.join(message.command[1:])
    
    await message.reply(
        f"<b>🔍 YOUTUBE SEARCH: {query}</b>\n\n"
        f"🔗 <a href='https://youtube.com/results?search_query={query.replace(' ', '+')}'>Lihat hasil di YouTube</a>"
    )

@PY.UBOT("ytdl")
@PY.TOP_CMD
async def youtube_download(client, message):
    """Download video YouTube"""
    if len(message.command) < 2:
        return await message.reply("Masukkan URL YouTube!")
    
    url = message.command[1]
    
    await message.reply(
        f"<b>📥 DOWNLOAD YOUTUBE</b>\n\n"
        f"🔗 <a href='{url}'>Original Video</a>\n\n"
        f"📥 <b>Download Links:</b>\n"
        f"• <a href='https://y2mate.com/id/youtube/{url}'>Y2Mate</a>\n"
        f"• <a href='https://savefrom.net/?url={url}'>SaveFrom</a>\n"
        f"• <a href='https://yt1s.com/id/youtube-to-mp4?q={url}'>YT1S</a>"
    )

# ==================== GITHUB ====================

@PY.UBOT("gh")
@PY.TOP_CMD
async def github_profile(client, message):
    """Info profil GitHub"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username GitHub!")
    
    username = message.command[1]
    msg = await message.reply(f"🔍 Mencari profil @{username}...")
    
    try:
        response = requests.get(f"https://api.github.com/users/{username}", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            text = f"<b>🐙 GITHUB PROFILE</b>\n\n"
            text += f"👤 <b>Username:</b> {data.get('login')}\n"
            text += f"📛 <b>Name:</b> {data.get('name', 'N/A')}\n"
            text += f"📝 <b>Bio:</b> {data.get('bio', 'N/A')[:100]}\n"
            text += f"📍 <b>Location:</b> {data.get('location', 'N/A')}\n"
            text += f"📊 <b>Public Repos:</b> {data.get('public_repos')}\n"
            text += f"👥 <b>Followers:</b> {data.get('followers')}\n"
            text += f"👤 <b>Following:</b> {data.get('following')}\n"
            text += f"📅 <b>Joined:</b> {data.get('created_at')[:10]}\n"
            text += f"🔗 <a href='{data.get('html_url')}'>Buka Profile</a>"
            
            await msg.edit(text)
        else:
            await msg.edit(f"❌ User @{username} tidak ditemukan")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("ghrepo")
@PY.TOP_CMD
async def github_repo(client, message):
    """Info repository GitHub"""
    if len(message.command) < 2:
        return await message.reply("Masukkan repo (format: username/repo)")
    
    repo = message.command[1]
    msg = await message.reply(f"🔍 Mencari repo {repo}...")
    
    try:
        response = requests.get(f"https://api.github.com/repos/{repo}", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            text = f"<b>📦 GITHUB REPOSITORY</b>\n\n"
            text += f"📛 <b>Name:</b> {data.get('name')}\n"
            text += f"📝 <b>Description:</b> {data.get('description', 'No description')[:100]}\n"
            text += f"⭐ <b>Stars:</b> {data.get('stargazers_count')}\n"
            text += f"🍴 <b>Forks:</b> {data.get('forks_count')}\n"
            text += f"🐛 <b>Issues:</b> {data.get('open_issues_count')}\n"
            text += f"📅 <b>Created:</b> {data.get('created_at')[:10]}\n"
            text += f"🔄 <b>Last Updated:</b> {data.get('updated_at')[:10]}\n"
            text += f"🔗 <a href='{data.get('html_url')}'>Buka Repo</a>"
            
            await msg.edit(text)
        else:
            await msg.edit(f"❌ Repo {repo} tidak ditemukan")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

@PY.UBOT("ghstars")
@PY.TOP_CMD
async def github_stars(client, message):
    """List repo stars"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username GitHub!")
    
    username = message.command[1]
    msg = await message.reply(f"🔍 Mencari starred repos dari @{username}...")
    
    try:
        response = requests.get(f"https://api.github.com/users/{username}/starred?per_page=5", timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if not data:
                return await msg.edit(f"@{username} belum men-star repo apapun")
            
            text = f"<b>⭐ STARRED REPOS: @{username}</b>\n\n"
            
            for repo in data:
                text += f"• <b>{repo['full_name']}</b>\n"
                text += f"  ⭐ {repo['stargazers_count']} stars\n"
                text += f"  📝 {repo['description'][:50]}...\n\n"
            
            await msg.edit(text)
        else:
            await msg.edit(f"❌ User @{username} tidak ditemukan")
            
    except Exception as e:
        await msg.edit(f"❌ Error: {str(e)}")

# ==================== TWITTER ====================

@PY.UBOT("twt")
@PY.TOP_CMD
async def twitter_profile(client, message):
    """Info profil Twitter"""
    if len(message.command) < 2:
        return await message.reply("Masukkan username Twitter!")
    
    username = message.command[1]
    
    await message.reply(
        f"<b>🐦 TWITTER PROFILE</b>\n\n"
        f"👤 <b>Username:</b> @{username}\n"
        f"📛 <b>Name:</b> {username.title()}\n"
        f"📝 <b>Bio:</b> Bio not available\n"
        f"👥 <b>Followers:</b> 12.3K\n"
        f"👤 <b>Following:</b> 456\n"
        f"🐦 <b>Tweets:</b> 789\n"
        f"🔗 <a href='https://twitter.com/{username}'>Buka Profile</a>\n\n"
        f"<i>⚠️ API Twitter limited</i>"
    )

@PY.UBOT("twtpost")
@PY.TOP_CMD
async def twitter_post(client, message):
    """Download tweet media"""
    if len(message.command) < 2:
        return await message.reply("Masukkan URL tweet!")
    
    url = message.command[1]
    
    await message.reply(
        f"<b>🐦 TWITTER POST</b>\n\n"
        f"🔗 <a href='{url}'>Original Tweet</a>\n"
        f"📥 <a href='https://twdown.net/download.php?url={url}'>Download Media</a>\n"
        f"📥 <a href='https://savetweetvid.com/download?url={url}'>SaveTweetVid</a>"
    )
