from PyroUbot import *
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import os

__MODULE__ = "𝐖𝐞𝐛 𝐒𝐜𝐫𝐞𝐞𝐧𝐬𝐡𝐨𝐭"
__HELP__ = """
<blockquote><b>📸 𝐖𝐞𝐛 𝐒𝐜𝐫𝐞𝐞𝐧𝐬𝐡𝐨𝐭</b>

 • <code>{0}ss &lt;url></code> - Screenshot website</blockquote>
"""

@PY.UBOT("ss")
@PY.TOP_CMD
async def web_screenshot(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .ss <url>")
    msg = await message.reply("📸 Mengambil screenshot...")
    try:
        options = Options()
        options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        driver = webdriver.Chrome(options=options)
        driver.get(args[1])
        driver.save_screenshot(f"ss_{message.id}.png")
        driver.quit()
        await message.reply_photo(f"ss_{message.id}.png")
        os.remove(f"ss_{message.id}.png")
        await msg.delete()
    except:
        await msg.edit("❌ Install selenium dulu: pip install selenium")
