from PyroUbot import *

__MODULE__ = "𝐏𝐢𝐧"
__HELP__ = """
<blockquote><b>📌 𝐏𝐢𝐧</b>

 • <code>{0}pin</code> - Pin pesan yang di-reply
 • <code>{0}unpin</code> - Unpin pesan</blockquote>
"""

@PY.UBOT("pin")
@PY.TOP_CMD
async def pin_msg(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    if not message.reply_to_message:
        return await message.reply("❌ Balas ke pesan!")
    await client.pin_chat_message(message.chat.id, message.reply_to_message.id)
    await message.reply("✅ Pesan dipin!")

@PY.UBOT("unpin")
@PY.TOP_CMD
async def unpin_msg(client, message):
    if not message.chat.admin_rights:
        return await message.reply("❌ Hanya admin!")
    await client.unpin_all_chat_messages(message.chat.id)
    await message.reply("✅ Pesan unpin!")
