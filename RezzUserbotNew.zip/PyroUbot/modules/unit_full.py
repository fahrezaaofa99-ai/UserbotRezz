from PyroUbot import *

__MODULE__ = "𝐔𝐧𝐢𝐭𝐅𝐮𝐥𝐥"
__HELP__ = """
<blockquote><b>📏 𝐔𝐧𝐢𝐭 𝐂𝐨𝐧𝐯𝐞𝐫𝐭𝐞𝐫</b>

 • <code>{0}km_m &lt;km></code> - KM ke Meter
 • <code>{0}m_km &lt;m></code> - Meter ke KM
 • <code>{0}kg_g &lt;kg></code> - KG ke Gram
 • <code>{0}g_kg &lt;g></code> - Gram ke KG
 • <code>{0}c_f &lt;c></code> - Celcius ke F
 • <code>{0}f_c &lt;f></code> - F ke Celcius</blockquote>
"""

@PY.UBOT("km_m")
@PY.TOP_CMD
async def km_to_meter(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .km_m <km>")
    await message.reply(f"📏 {args[1]} km = {float(args[1]) * 1000} meter")

@PY.UBOT("m_km")
@PY.TOP_CMD
async def meter_to_km(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .m_km <meter>")
    await message.reply(f"📏 {args[1]} meter = {float(args[1]) / 1000} km")

@PY.UBOT("kg_g")
@PY.TOP_CMD
async def kg_to_gram(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .kg_g <kg>")
    await message.reply(f"⚖️ {args[1]} kg = {float(args[1]) * 1000} gram")

@PY.UBOT("g_kg")
@PY.TOP_CMD
async def gram_to_kg(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .g_kg <gram>")
    await message.reply(f"⚖️ {args[1]} gram = {float(args[1]) / 1000} kg")

@PY.UBOT("c_f")
@PY.TOP_CMD
async def celcius_to_fahrenheit(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .c_f <celcius>")
    c = float(args[1])
    await message.reply(f"🌡️ {c}°C = {(c * 9/5) + 32}°F")

@PY.UBOT("f_c")
@PY.TOP_CMD
async def fahrenheit_to_celcius(client, message):
    args = message.text.split()
    if len(args) < 2:
        return await message.reply("❌ .f_c <fahrenheit>")
    f = float(args[1])
    await message.reply(f"🌡️ {f}°F = {(f - 32) * 5/9:.1f}°C")
