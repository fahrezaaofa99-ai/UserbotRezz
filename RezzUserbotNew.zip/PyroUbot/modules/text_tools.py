from PyroUbot import *
import re

__MODULE__ = "𝐓𝐞𝐱𝐭 𝐓𝐨𝐨𝐥𝐬"
__HELP__ = """
<blockquote><b>📝 𝐓𝐞𝐱𝐭 𝐓𝐨𝐨𝐥𝐬</b>

 • <code>{0}upper &lt;text></code> - HURUF BESAR
 • <code>{0}lower &lt;text></code> - huruf kecil
 • <code>{0}capital &lt;text></code> - Kapital Setiap Kata
 • <code>{0}reverse &lt;text></code> - esreveR
 • <code>{0}count &lt;text></code> - Hitung karakter
 • <code>{0}find &lt;text> &lt;kata></code> - Cari kata</blockquote>
"""

@PY.UBOT("upper")
@PY.TOP_CMD
async def upper_text(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .upper <text>")
    await message.reply(args[1].upper())

@PY.UBOT("lower")
@PY.TOP_CMD
async def lower_text(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .lower <text>")
    await message.reply(args[1].lower())

@PY.UBOT("capital")
@PY.TOP_CMD
async def capital_text(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .capital <text>")
    await message.reply(args[1].title())

@PY.UBOT("reverse")
@PY.TOP_CMD
async def reverse_text(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .reverse <text>")
    await message.reply(args[1][::-1])

@PY.UBOT("count")
@PY.TOP_CMD
async def count_text(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .count <text>")
    t = args[1]
    await message.reply(f"📊 Karakter: {len(t)}\n📖 Kata: {len(t.split())}")

@PY.UBOT("find")
@PY.TOP_CMD
async def find_word(client, message):
    args = message.text.split(maxsplit=2)
    if len(args) < 3:
        return await message.reply("❌ .find <text> <kata>")
    if args[2] in args[1]:
        await message.reply(f"✅ Ditemukan! Jumlah: {args[1].count(args[2])}")
    else:
        await message.reply("❌ Tidak ditemukan!")
