from PyroUbot import *

__MODULE__ = "𝐒𝐞𝐭 𝐒𝐭𝐢𝐜𝐤𝐞𝐫"
__HELP__ = """
<blockquote><b>🎨 𝐒𝐞𝐭 𝐒𝐭𝐢𝐜𝐤𝐞𝐫</b>

 • <code>{0}setsticker &lt;nama_pack></code> - Set stiker ke pack</blockquote>
"""

@PY.UBOT("setsticker")
@PY.TOP_CMD
async def set_sticker_pack(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply("❌ .setsticker <nama_pack>")
    if not message.reply_to_message or not message.reply_to_message.sticker:
        return await message.reply("❌ Balas ke stiker!")
    pack_name = args[1]
    file = await message.reply_to_message.download()
    await client.send_document("me", file)
    os.remove(file)
    await message.reply(f"✅ Stiker disimpan ke pack {pack_name}")
